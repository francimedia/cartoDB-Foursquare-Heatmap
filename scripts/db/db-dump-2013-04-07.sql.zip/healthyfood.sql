-- phpMyAdmin SQL Dump
-- version 3.3.9.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 07, 2013 at 11:20 AM
-- Server version: 5.5.9
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `healthyfood`
--

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `group`
--


-- --------------------------------------------------------

--
-- Table structure for table `group_object`
--

CREATE TABLE `group_object` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `group_id` int(6) NOT NULL,
  `object_id` int(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `group_object`
--


-- --------------------------------------------------------

--
-- Table structure for table `interaction`
--

CREATE TABLE `interaction` (
  `id` int(12) NOT NULL,
  `time_created` timestamp NULL DEFAULT NULL,
  `venue_id` int(12) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `interaction_type` enum('picture','comment','like') NOT NULL,
  `source` enum('instagram','foursquare') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `location_id` (`venue_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interaction`
--


-- --------------------------------------------------------

--
-- Table structure for table `interaction_meta_common`
--

CREATE TABLE `interaction_meta_common` (
  `id` int(12) NOT NULL,
  `lat` decimal(13,10) DEFAULT NULL,
  `lng` decimal(13,10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interaction_meta_common`
--


-- --------------------------------------------------------

--
-- Table structure for table `interaction_meta_foursquare`
--

CREATE TABLE `interaction_meta_foursquare` (
  `id` int(12) NOT NULL,
  `foursquare_user_id` int(12) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interaction_meta_foursquare`
--


-- --------------------------------------------------------

--
-- Table structure for table `interaction_meta_instagram`
--

CREATE TABLE `interaction_meta_instagram` (
  `id` int(12) NOT NULL,
  `interaction_instagram_id` varchar(48) NOT NULL,
  `instagram_user_id` int(12) NOT NULL,
  `username` varchar(255) NOT NULL,
  `image_1` varchar(1000) DEFAULT NULL,
  `image_2` varchar(1000) DEFAULT NULL,
  `image_3` varchar(1000) DEFAULT NULL,
  `link` varchar(255) NOT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `likes` int(12) NOT NULL DEFAULT '0',
  `comments` int(12) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interaction_meta_instagram`
--


-- --------------------------------------------------------

--
-- Table structure for table `interaction_meta_twitter`
--

CREATE TABLE `interaction_meta_twitter` (
  `id` int(12) NOT NULL,
  `mentions` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `interaction_meta_twitter`
--


-- --------------------------------------------------------

--
-- Table structure for table `keyword`
--

CREATE TABLE `keyword` (
  `id` bigint(20) NOT NULL,
  `value` varchar(48) NOT NULL,
  `count` int(12) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `value` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `keyword`
--


-- --------------------------------------------------------

--
-- Table structure for table `keyword_venue`
--

CREATE TABLE `keyword_venue` (
  `id` bigint(20) NOT NULL,
  `venue_id` bigint(20) NOT NULL,
  `keyword_id` bigint(20) NOT NULL,
  `count` int(12) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `venue_keyword_id` (`venue_id`,`keyword_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `keyword_venue`
--


-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `object_id` int(12) NOT NULL,
  `property` enum('singleton','checkin','checkin-unique','like','comment','review','rating','photos','specials','herenow','mayor','keyword') NOT NULL,
  `value` int(12) NOT NULL,
  `datatype` enum('absolute','relative') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `property` (`property`),
  KEY `object_id` (`object_id`),
  KEY `datatype` (`datatype`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1836 ;

--
-- Dumping data for table `record`
--

INSERT INTO `record` VALUES(1, '2013-04-06 17:57:18', 1, 'checkin', 3846, 'absolute');
INSERT INTO `record` VALUES(2, '2013-04-06 17:57:18', 1, 'checkin-unique', 720, 'absolute');
INSERT INTO `record` VALUES(3, '2013-04-06 17:57:18', 1, 'review', 21, 'absolute');
INSERT INTO `record` VALUES(4, '2013-04-06 17:57:18', 1, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(5, '2013-04-06 17:57:18', 1, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(6, '2013-04-06 17:57:18', 2, 'checkin', 288, 'absolute');
INSERT INTO `record` VALUES(7, '2013-04-06 17:57:18', 2, 'checkin-unique', 76, 'absolute');
INSERT INTO `record` VALUES(8, '2013-04-06 17:57:18', 2, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(9, '2013-04-06 17:57:18', 2, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(10, '2013-04-06 17:57:18', 2, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(11, '2013-04-06 17:57:18', 3, 'checkin', 415, 'absolute');
INSERT INTO `record` VALUES(12, '2013-04-06 17:57:18', 3, 'checkin-unique', 55, 'absolute');
INSERT INTO `record` VALUES(13, '2013-04-06 17:57:18', 3, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(14, '2013-04-06 17:57:18', 3, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(15, '2013-04-06 17:57:18', 3, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(16, '2013-04-06 17:57:18', 4, 'checkin', 22, 'absolute');
INSERT INTO `record` VALUES(17, '2013-04-06 17:57:18', 4, 'checkin-unique', 7, 'absolute');
INSERT INTO `record` VALUES(18, '2013-04-06 17:57:18', 4, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(19, '2013-04-06 17:57:18', 4, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(20, '2013-04-06 17:57:18', 4, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(21, '2013-04-06 17:57:18', 5, 'checkin', 24, 'absolute');
INSERT INTO `record` VALUES(22, '2013-04-06 17:57:18', 5, 'checkin-unique', 13, 'absolute');
INSERT INTO `record` VALUES(23, '2013-04-06 17:57:18', 5, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(24, '2013-04-06 17:57:18', 5, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(25, '2013-04-06 17:57:18', 5, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(26, '2013-04-06 17:57:18', 6, 'checkin', 568, 'absolute');
INSERT INTO `record` VALUES(27, '2013-04-06 17:57:18', 6, 'checkin-unique', 126, 'absolute');
INSERT INTO `record` VALUES(28, '2013-04-06 17:57:18', 6, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(29, '2013-04-06 17:57:18', 6, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(30, '2013-04-06 17:57:18', 6, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(31, '2013-04-06 17:57:18', 7, 'checkin', 33, 'absolute');
INSERT INTO `record` VALUES(32, '2013-04-06 17:57:18', 7, 'checkin-unique', 13, 'absolute');
INSERT INTO `record` VALUES(33, '2013-04-06 17:57:18', 7, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(34, '2013-04-06 17:57:18', 7, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(35, '2013-04-06 17:57:18', 7, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(36, '2013-04-06 17:57:18', 8, 'checkin', 5, 'absolute');
INSERT INTO `record` VALUES(37, '2013-04-06 17:57:18', 8, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(38, '2013-04-06 17:57:18', 8, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(39, '2013-04-06 17:57:18', 8, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(40, '2013-04-06 17:57:18', 8, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(41, '2013-04-06 17:57:18', 9, 'checkin', 8, 'absolute');
INSERT INTO `record` VALUES(42, '2013-04-06 17:57:18', 9, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(43, '2013-04-06 17:57:18', 9, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(44, '2013-04-06 17:57:18', 9, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(45, '2013-04-06 17:57:18', 9, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(46, '2013-04-06 17:57:18', 10, 'checkin', 89, 'absolute');
INSERT INTO `record` VALUES(47, '2013-04-06 17:57:18', 10, 'checkin-unique', 42, 'absolute');
INSERT INTO `record` VALUES(48, '2013-04-06 17:57:18', 10, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(49, '2013-04-06 17:57:18', 10, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(50, '2013-04-06 17:57:18', 10, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(51, '2013-04-06 17:57:18', 11, 'checkin', 350, 'absolute');
INSERT INTO `record` VALUES(52, '2013-04-06 17:57:18', 11, 'checkin-unique', 53, 'absolute');
INSERT INTO `record` VALUES(53, '2013-04-06 17:57:18', 11, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(54, '2013-04-06 17:57:18', 11, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(55, '2013-04-06 17:57:18', 11, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(56, '2013-04-06 17:57:18', 12, 'checkin', 1257, 'absolute');
INSERT INTO `record` VALUES(57, '2013-04-06 17:57:18', 12, 'checkin-unique', 412, 'absolute');
INSERT INTO `record` VALUES(58, '2013-04-06 17:57:18', 12, 'review', 13, 'absolute');
INSERT INTO `record` VALUES(59, '2013-04-06 17:57:18', 12, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(60, '2013-04-06 17:57:18', 12, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(61, '2013-04-06 17:57:18', 13, 'checkin', 33, 'absolute');
INSERT INTO `record` VALUES(62, '2013-04-06 17:57:18', 13, 'checkin-unique', 28, 'absolute');
INSERT INTO `record` VALUES(63, '2013-04-06 17:57:18', 13, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(64, '2013-04-06 17:57:18', 13, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(65, '2013-04-06 17:57:18', 13, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(66, '2013-04-06 17:57:18', 14, 'checkin', 2345, 'absolute');
INSERT INTO `record` VALUES(67, '2013-04-06 17:57:18', 14, 'checkin-unique', 583, 'absolute');
INSERT INTO `record` VALUES(68, '2013-04-06 17:57:18', 14, 'review', 12, 'absolute');
INSERT INTO `record` VALUES(69, '2013-04-06 17:57:18', 14, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(70, '2013-04-06 17:57:18', 14, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(71, '2013-04-06 17:57:18', 15, 'checkin', 2, 'absolute');
INSERT INTO `record` VALUES(72, '2013-04-06 17:57:18', 15, 'checkin-unique', 2, 'absolute');
INSERT INTO `record` VALUES(73, '2013-04-06 17:57:18', 15, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(74, '2013-04-06 17:57:18', 15, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(75, '2013-04-06 17:57:18', 15, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(76, '2013-04-06 17:57:18', 16, 'checkin', 29, 'absolute');
INSERT INTO `record` VALUES(77, '2013-04-06 17:57:18', 16, 'checkin-unique', 15, 'absolute');
INSERT INTO `record` VALUES(78, '2013-04-06 17:57:18', 16, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(79, '2013-04-06 17:57:18', 16, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(80, '2013-04-06 17:57:18', 16, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(81, '2013-04-06 17:57:18', 17, 'checkin', 383, 'absolute');
INSERT INTO `record` VALUES(82, '2013-04-06 17:57:18', 17, 'checkin-unique', 47, 'absolute');
INSERT INTO `record` VALUES(83, '2013-04-06 17:57:18', 17, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(84, '2013-04-06 17:57:18', 17, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(85, '2013-04-06 17:57:18', 17, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(86, '2013-04-06 17:57:18', 18, 'checkin', 9, 'absolute');
INSERT INTO `record` VALUES(87, '2013-04-06 17:57:18', 18, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(88, '2013-04-06 17:57:18', 18, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(89, '2013-04-06 17:57:18', 18, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(90, '2013-04-06 17:57:18', 18, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(91, '2013-04-06 17:57:18', 19, 'checkin', 475, 'absolute');
INSERT INTO `record` VALUES(92, '2013-04-06 17:57:18', 19, 'checkin-unique', 117, 'absolute');
INSERT INTO `record` VALUES(93, '2013-04-06 17:57:18', 19, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(94, '2013-04-06 17:57:18', 19, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(95, '2013-04-06 17:57:18', 19, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(96, '2013-04-06 17:57:18', 20, 'checkin', 3, 'absolute');
INSERT INTO `record` VALUES(97, '2013-04-06 17:57:18', 20, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(98, '2013-04-06 17:57:18', 20, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(99, '2013-04-06 17:57:18', 20, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(100, '2013-04-06 17:57:18', 20, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(101, '2013-04-06 17:57:18', 21, 'checkin', 5, 'absolute');
INSERT INTO `record` VALUES(102, '2013-04-06 17:57:18', 21, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(103, '2013-04-06 17:57:18', 21, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(104, '2013-04-06 17:57:18', 21, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(105, '2013-04-06 17:57:18', 21, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(106, '2013-04-06 17:57:18', 22, 'checkin', 29, 'absolute');
INSERT INTO `record` VALUES(107, '2013-04-06 17:57:18', 22, 'checkin-unique', 12, 'absolute');
INSERT INTO `record` VALUES(108, '2013-04-06 17:57:18', 22, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(109, '2013-04-06 17:57:18', 22, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(110, '2013-04-06 17:57:18', 22, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(111, '2013-04-06 17:57:18', 23, 'checkin', 8, 'absolute');
INSERT INTO `record` VALUES(112, '2013-04-06 17:57:18', 23, 'checkin-unique', 6, 'absolute');
INSERT INTO `record` VALUES(113, '2013-04-06 17:57:18', 23, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(114, '2013-04-06 17:57:18', 23, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(115, '2013-04-06 17:57:18', 23, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(116, '2013-04-06 17:57:18', 24, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(117, '2013-04-06 17:57:18', 24, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(118, '2013-04-06 17:57:18', 24, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(119, '2013-04-06 17:57:18', 24, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(120, '2013-04-06 17:57:18', 24, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(121, '2013-04-06 17:57:18', 25, 'checkin', 786, 'absolute');
INSERT INTO `record` VALUES(122, '2013-04-06 17:57:18', 25, 'checkin-unique', 152, 'absolute');
INSERT INTO `record` VALUES(123, '2013-04-06 17:57:18', 25, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(124, '2013-04-06 17:57:18', 25, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(125, '2013-04-06 17:57:18', 25, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(126, '2013-04-06 17:57:18', 26, 'checkin', 22, 'absolute');
INSERT INTO `record` VALUES(127, '2013-04-06 17:57:18', 26, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(128, '2013-04-06 17:57:18', 26, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(129, '2013-04-06 17:57:18', 26, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(130, '2013-04-06 17:57:18', 26, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(131, '2013-04-06 17:57:18', 27, 'checkin', 118, 'absolute');
INSERT INTO `record` VALUES(132, '2013-04-06 17:57:18', 27, 'checkin-unique', 25, 'absolute');
INSERT INTO `record` VALUES(133, '2013-04-06 17:57:18', 27, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(134, '2013-04-06 17:57:18', 27, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(135, '2013-04-06 17:57:18', 27, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(136, '2013-04-06 17:57:19', 28, 'checkin', 427, 'absolute');
INSERT INTO `record` VALUES(137, '2013-04-06 17:57:19', 28, 'checkin-unique', 119, 'absolute');
INSERT INTO `record` VALUES(138, '2013-04-06 17:57:19', 28, 'review', 10, 'absolute');
INSERT INTO `record` VALUES(139, '2013-04-06 17:57:19', 28, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(140, '2013-04-06 17:57:19', 28, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(141, '2013-04-06 17:57:19', 29, 'checkin', 8255, 'absolute');
INSERT INTO `record` VALUES(142, '2013-04-06 17:57:19', 29, 'checkin-unique', 1276, 'absolute');
INSERT INTO `record` VALUES(143, '2013-04-06 17:57:19', 29, 'review', 83, 'absolute');
INSERT INTO `record` VALUES(144, '2013-04-06 17:57:19', 29, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(145, '2013-04-06 17:57:19', 29, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(146, '2013-04-06 17:57:19', 30, 'checkin', 284, 'absolute');
INSERT INTO `record` VALUES(147, '2013-04-06 17:57:19', 30, 'checkin-unique', 77, 'absolute');
INSERT INTO `record` VALUES(148, '2013-04-06 17:57:19', 30, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(149, '2013-04-06 17:57:19', 30, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(150, '2013-04-06 17:57:19', 30, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(151, '2013-04-06 17:57:19', 31, 'checkin', 5, 'absolute');
INSERT INTO `record` VALUES(152, '2013-04-06 17:57:19', 31, 'checkin-unique', 5, 'absolute');
INSERT INTO `record` VALUES(153, '2013-04-06 17:57:19', 31, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(154, '2013-04-06 17:57:19', 31, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(155, '2013-04-06 17:57:19', 31, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(156, '2013-04-06 17:57:19', 32, 'checkin', 390, 'absolute');
INSERT INTO `record` VALUES(157, '2013-04-06 17:57:19', 32, 'checkin-unique', 133, 'absolute');
INSERT INTO `record` VALUES(158, '2013-04-06 17:57:19', 32, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(159, '2013-04-06 17:57:19', 32, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(160, '2013-04-06 17:57:19', 32, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(161, '2013-04-06 17:57:19', 33, 'checkin', 92, 'absolute');
INSERT INTO `record` VALUES(162, '2013-04-06 17:57:19', 33, 'checkin-unique', 32, 'absolute');
INSERT INTO `record` VALUES(163, '2013-04-06 17:57:19', 33, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(164, '2013-04-06 17:57:19', 33, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(165, '2013-04-06 17:57:19', 33, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(166, '2013-04-06 17:57:19', 34, 'checkin', 0, 'absolute');
INSERT INTO `record` VALUES(167, '2013-04-06 17:57:19', 34, 'checkin-unique', 0, 'absolute');
INSERT INTO `record` VALUES(168, '2013-04-06 17:57:19', 34, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(169, '2013-04-06 17:57:19', 34, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(170, '2013-04-06 17:57:19', 34, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(171, '2013-04-06 17:57:19', 35, 'checkin', 501, 'absolute');
INSERT INTO `record` VALUES(172, '2013-04-06 17:57:19', 35, 'checkin-unique', 128, 'absolute');
INSERT INTO `record` VALUES(173, '2013-04-06 17:57:19', 35, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(174, '2013-04-06 17:57:19', 35, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(175, '2013-04-06 17:57:19', 35, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(176, '2013-04-06 17:57:19', 36, 'checkin', 8, 'absolute');
INSERT INTO `record` VALUES(177, '2013-04-06 17:57:19', 36, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(178, '2013-04-06 17:57:19', 36, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(179, '2013-04-06 17:57:19', 36, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(180, '2013-04-06 17:57:19', 36, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(181, '2013-04-06 17:57:19', 37, 'checkin', 17, 'absolute');
INSERT INTO `record` VALUES(182, '2013-04-06 17:57:19', 37, 'checkin-unique', 10, 'absolute');
INSERT INTO `record` VALUES(183, '2013-04-06 17:57:19', 37, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(184, '2013-04-06 17:57:19', 37, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(185, '2013-04-06 17:57:19', 37, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(186, '2013-04-06 17:57:19', 38, 'checkin', 29, 'absolute');
INSERT INTO `record` VALUES(187, '2013-04-06 17:57:19', 38, 'checkin-unique', 16, 'absolute');
INSERT INTO `record` VALUES(188, '2013-04-06 17:57:19', 38, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(189, '2013-04-06 17:57:19', 38, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(190, '2013-04-06 17:57:19', 38, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(191, '2013-04-06 17:57:19', 39, 'checkin', 310, 'absolute');
INSERT INTO `record` VALUES(192, '2013-04-06 17:57:19', 39, 'checkin-unique', 104, 'absolute');
INSERT INTO `record` VALUES(193, '2013-04-06 17:57:19', 39, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(194, '2013-04-06 17:57:19', 39, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(195, '2013-04-06 17:57:19', 39, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(196, '2013-04-06 17:57:19', 40, 'checkin', 7, 'absolute');
INSERT INTO `record` VALUES(197, '2013-04-06 17:57:19', 40, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(198, '2013-04-06 17:57:19', 40, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(199, '2013-04-06 17:57:19', 40, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(200, '2013-04-06 17:57:19', 40, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(201, '2013-04-06 17:57:19', 41, 'checkin', 27, 'absolute');
INSERT INTO `record` VALUES(202, '2013-04-06 17:57:19', 41, 'checkin-unique', 16, 'absolute');
INSERT INTO `record` VALUES(203, '2013-04-06 17:57:19', 41, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(204, '2013-04-06 17:57:19', 41, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(205, '2013-04-06 17:57:19', 41, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(206, '2013-04-06 17:57:19', 42, 'checkin', 861, 'absolute');
INSERT INTO `record` VALUES(207, '2013-04-06 17:57:19', 42, 'checkin-unique', 218, 'absolute');
INSERT INTO `record` VALUES(208, '2013-04-06 17:57:19', 42, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(209, '2013-04-06 17:57:19', 42, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(210, '2013-04-06 17:57:19', 42, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(211, '2013-04-06 17:57:19', 43, 'checkin', 687, 'absolute');
INSERT INTO `record` VALUES(212, '2013-04-06 17:57:19', 43, 'checkin-unique', 155, 'absolute');
INSERT INTO `record` VALUES(213, '2013-04-06 17:57:19', 43, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(214, '2013-04-06 17:57:19', 43, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(215, '2013-04-06 17:57:19', 43, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(216, '2013-04-06 17:57:19', 44, 'checkin', 82, 'absolute');
INSERT INTO `record` VALUES(217, '2013-04-06 17:57:19', 44, 'checkin-unique', 14, 'absolute');
INSERT INTO `record` VALUES(218, '2013-04-06 17:57:19', 44, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(219, '2013-04-06 17:57:19', 44, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(220, '2013-04-06 17:57:19', 44, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(221, '2013-04-06 17:57:19', 45, 'checkin', 95, 'absolute');
INSERT INTO `record` VALUES(222, '2013-04-06 17:57:19', 45, 'checkin-unique', 30, 'absolute');
INSERT INTO `record` VALUES(223, '2013-04-06 17:57:19', 45, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(224, '2013-04-06 17:57:19', 45, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(225, '2013-04-06 17:57:19', 45, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(226, '2013-04-06 17:57:19', 46, 'checkin', 895, 'absolute');
INSERT INTO `record` VALUES(227, '2013-04-06 17:57:19', 46, 'checkin-unique', 177, 'absolute');
INSERT INTO `record` VALUES(228, '2013-04-06 17:57:19', 46, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(229, '2013-04-06 17:57:19', 46, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(230, '2013-04-06 17:57:19', 46, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(231, '2013-04-06 17:57:19', 47, 'checkin', 208, 'absolute');
INSERT INTO `record` VALUES(232, '2013-04-06 17:57:19', 47, 'checkin-unique', 79, 'absolute');
INSERT INTO `record` VALUES(233, '2013-04-06 17:57:19', 47, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(234, '2013-04-06 17:57:19', 47, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(235, '2013-04-06 17:57:19', 47, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(236, '2013-04-06 17:57:19', 48, 'checkin', 77, 'absolute');
INSERT INTO `record` VALUES(237, '2013-04-06 17:57:19', 48, 'checkin-unique', 33, 'absolute');
INSERT INTO `record` VALUES(238, '2013-04-06 17:57:19', 48, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(239, '2013-04-06 17:57:19', 48, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(240, '2013-04-06 17:57:19', 48, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(241, '2013-04-06 17:57:19', 49, 'checkin', 95, 'absolute');
INSERT INTO `record` VALUES(242, '2013-04-06 17:57:19', 49, 'checkin-unique', 18, 'absolute');
INSERT INTO `record` VALUES(243, '2013-04-06 17:57:19', 49, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(244, '2013-04-06 17:57:19', 49, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(245, '2013-04-06 17:57:19', 49, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(246, '2013-04-06 17:57:19', 50, 'checkin', 75, 'absolute');
INSERT INTO `record` VALUES(247, '2013-04-06 17:57:19', 50, 'checkin-unique', 17, 'absolute');
INSERT INTO `record` VALUES(248, '2013-04-06 17:57:19', 50, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(249, '2013-04-06 17:57:19', 50, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(250, '2013-04-06 17:57:19', 50, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(251, '2013-04-06 17:57:19', 51, 'checkin', 5, 'absolute');
INSERT INTO `record` VALUES(252, '2013-04-06 17:57:19', 51, 'checkin-unique', 5, 'absolute');
INSERT INTO `record` VALUES(253, '2013-04-06 17:57:19', 51, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(254, '2013-04-06 17:57:19', 51, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(255, '2013-04-06 17:57:19', 51, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(256, '2013-04-06 17:57:19', 52, 'checkin', 491, 'absolute');
INSERT INTO `record` VALUES(257, '2013-04-06 17:57:19', 52, 'checkin-unique', 146, 'absolute');
INSERT INTO `record` VALUES(258, '2013-04-06 17:57:19', 52, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(259, '2013-04-06 17:57:19', 52, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(260, '2013-04-06 17:57:19', 52, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(261, '2013-04-06 17:57:19', 53, 'checkin', 15, 'absolute');
INSERT INTO `record` VALUES(262, '2013-04-06 17:57:19', 53, 'checkin-unique', 6, 'absolute');
INSERT INTO `record` VALUES(263, '2013-04-06 17:57:19', 53, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(264, '2013-04-06 17:57:19', 53, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(265, '2013-04-06 17:57:19', 53, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(266, '2013-04-06 17:57:19', 54, 'checkin', 8, 'absolute');
INSERT INTO `record` VALUES(267, '2013-04-06 17:57:19', 54, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(268, '2013-04-06 17:57:19', 54, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(269, '2013-04-06 17:57:19', 54, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(270, '2013-04-06 17:57:19', 54, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(271, '2013-04-06 17:57:20', 55, 'checkin', 19, 'absolute');
INSERT INTO `record` VALUES(272, '2013-04-06 17:57:20', 55, 'checkin-unique', 6, 'absolute');
INSERT INTO `record` VALUES(273, '2013-04-06 17:57:20', 55, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(274, '2013-04-06 17:57:20', 55, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(275, '2013-04-06 17:57:20', 55, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(276, '2013-04-06 17:57:20', 56, 'checkin', 549, 'absolute');
INSERT INTO `record` VALUES(277, '2013-04-06 17:57:20', 56, 'checkin-unique', 160, 'absolute');
INSERT INTO `record` VALUES(278, '2013-04-06 17:57:20', 56, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(279, '2013-04-06 17:57:20', 56, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(280, '2013-04-06 17:57:20', 56, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(281, '2013-04-06 17:57:20', 57, 'checkin', 25, 'absolute');
INSERT INTO `record` VALUES(282, '2013-04-06 17:57:20', 57, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(283, '2013-04-06 17:57:20', 57, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(284, '2013-04-06 17:57:20', 57, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(285, '2013-04-06 17:57:20', 57, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(286, '2013-04-06 17:57:20', 58, 'checkin', 1826, 'absolute');
INSERT INTO `record` VALUES(287, '2013-04-06 17:57:20', 58, 'checkin-unique', 500, 'absolute');
INSERT INTO `record` VALUES(288, '2013-04-06 17:57:20', 58, 'review', 13, 'absolute');
INSERT INTO `record` VALUES(289, '2013-04-06 17:57:20', 58, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(290, '2013-04-06 17:57:20', 58, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(291, '2013-04-06 17:57:20', 59, 'checkin', 42, 'absolute');
INSERT INTO `record` VALUES(292, '2013-04-06 17:57:20', 59, 'checkin-unique', 24, 'absolute');
INSERT INTO `record` VALUES(293, '2013-04-06 17:57:20', 59, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(294, '2013-04-06 17:57:20', 59, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(295, '2013-04-06 17:57:20', 59, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(296, '2013-04-06 17:57:20', 60, 'checkin', 4, 'absolute');
INSERT INTO `record` VALUES(297, '2013-04-06 17:57:20', 60, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(298, '2013-04-06 17:57:20', 60, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(299, '2013-04-06 17:57:20', 60, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(300, '2013-04-06 17:57:20', 60, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(301, '2013-04-06 17:57:20', 61, 'checkin', 31, 'absolute');
INSERT INTO `record` VALUES(302, '2013-04-06 17:57:20', 61, 'checkin-unique', 10, 'absolute');
INSERT INTO `record` VALUES(303, '2013-04-06 17:57:20', 61, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(304, '2013-04-06 17:57:20', 61, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(305, '2013-04-06 17:57:20', 61, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(306, '2013-04-06 17:57:20', 62, 'checkin', 44, 'absolute');
INSERT INTO `record` VALUES(307, '2013-04-06 17:57:20', 62, 'checkin-unique', 14, 'absolute');
INSERT INTO `record` VALUES(308, '2013-04-06 17:57:20', 62, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(309, '2013-04-06 17:57:20', 62, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(310, '2013-04-06 17:57:20', 62, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(311, '2013-04-06 17:57:20', 63, 'checkin', 409, 'absolute');
INSERT INTO `record` VALUES(312, '2013-04-06 17:57:20', 63, 'checkin-unique', 152, 'absolute');
INSERT INTO `record` VALUES(313, '2013-04-06 17:57:20', 63, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(314, '2013-04-06 17:57:20', 63, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(315, '2013-04-06 17:57:20', 63, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(316, '2013-04-06 17:57:20', 64, 'checkin', 145, 'absolute');
INSERT INTO `record` VALUES(317, '2013-04-06 17:57:20', 64, 'checkin-unique', 58, 'absolute');
INSERT INTO `record` VALUES(318, '2013-04-06 17:57:20', 64, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(319, '2013-04-06 17:57:20', 64, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(320, '2013-04-06 17:57:20', 64, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(321, '2013-04-06 17:57:20', 65, 'checkin', 693, 'absolute');
INSERT INTO `record` VALUES(322, '2013-04-06 17:57:20', 65, 'checkin-unique', 144, 'absolute');
INSERT INTO `record` VALUES(323, '2013-04-06 17:57:20', 65, 'review', 10, 'absolute');
INSERT INTO `record` VALUES(324, '2013-04-06 17:57:20', 65, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(325, '2013-04-06 17:57:20', 65, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(326, '2013-04-06 17:57:20', 66, 'checkin', 3090, 'absolute');
INSERT INTO `record` VALUES(327, '2013-04-06 17:57:20', 66, 'checkin-unique', 1128, 'absolute');
INSERT INTO `record` VALUES(328, '2013-04-06 17:57:20', 66, 'review', 43, 'absolute');
INSERT INTO `record` VALUES(329, '2013-04-06 17:57:20', 66, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(330, '2013-04-06 17:57:20', 66, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(331, '2013-04-06 17:57:20', 67, 'checkin', 23, 'absolute');
INSERT INTO `record` VALUES(332, '2013-04-06 17:57:20', 67, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(333, '2013-04-06 17:57:20', 67, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(334, '2013-04-06 17:57:20', 67, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(335, '2013-04-06 17:57:20', 67, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(336, '2013-04-06 17:57:20', 68, 'checkin', 5, 'absolute');
INSERT INTO `record` VALUES(337, '2013-04-06 17:57:20', 68, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(338, '2013-04-06 17:57:20', 68, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(339, '2013-04-06 17:57:20', 68, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(340, '2013-04-06 17:57:20', 68, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(341, '2013-04-06 17:57:20', 69, 'checkin', 366, 'absolute');
INSERT INTO `record` VALUES(342, '2013-04-06 17:57:20', 69, 'checkin-unique', 79, 'absolute');
INSERT INTO `record` VALUES(343, '2013-04-06 17:57:20', 69, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(344, '2013-04-06 17:57:20', 69, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(345, '2013-04-06 17:57:20', 69, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(346, '2013-04-06 17:57:21', 70, 'checkin', 346, 'absolute');
INSERT INTO `record` VALUES(347, '2013-04-06 17:57:21', 70, 'checkin-unique', 160, 'absolute');
INSERT INTO `record` VALUES(348, '2013-04-06 17:57:21', 70, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(349, '2013-04-06 17:57:21', 70, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(350, '2013-04-06 17:57:21', 70, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(351, '2013-04-06 17:57:21', 71, 'checkin', 10062, 'absolute');
INSERT INTO `record` VALUES(352, '2013-04-06 17:57:21', 71, 'checkin-unique', 3629, 'absolute');
INSERT INTO `record` VALUES(353, '2013-04-06 17:57:21', 71, 'review', 63, 'absolute');
INSERT INTO `record` VALUES(354, '2013-04-06 17:57:21', 71, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(355, '2013-04-06 17:57:21', 71, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(356, '2013-04-06 17:57:21', 72, 'checkin', 125, 'absolute');
INSERT INTO `record` VALUES(357, '2013-04-06 17:57:21', 72, 'checkin-unique', 36, 'absolute');
INSERT INTO `record` VALUES(358, '2013-04-06 17:57:21', 72, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(359, '2013-04-06 17:57:21', 72, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(360, '2013-04-06 17:57:21', 72, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(361, '2013-04-06 17:57:21', 73, 'checkin', 2, 'absolute');
INSERT INTO `record` VALUES(362, '2013-04-06 17:57:21', 73, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(363, '2013-04-06 17:57:21', 73, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(364, '2013-04-06 17:57:21', 73, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(365, '2013-04-06 17:57:21', 73, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(366, '2013-04-06 17:57:21', 74, 'checkin', 239, 'absolute');
INSERT INTO `record` VALUES(367, '2013-04-06 17:57:21', 74, 'checkin-unique', 81, 'absolute');
INSERT INTO `record` VALUES(368, '2013-04-06 17:57:21', 74, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(369, '2013-04-06 17:57:21', 74, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(370, '2013-04-06 17:57:21', 74, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(371, '2013-04-06 17:57:21', 75, 'checkin', 543, 'absolute');
INSERT INTO `record` VALUES(372, '2013-04-06 17:57:21', 75, 'checkin-unique', 307, 'absolute');
INSERT INTO `record` VALUES(373, '2013-04-06 17:57:21', 75, 'review', 9, 'absolute');
INSERT INTO `record` VALUES(374, '2013-04-06 17:57:21', 75, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(375, '2013-04-06 17:57:21', 75, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(376, '2013-04-06 17:57:21', 76, 'checkin', 1181, 'absolute');
INSERT INTO `record` VALUES(377, '2013-04-06 17:57:21', 76, 'checkin-unique', 289, 'absolute');
INSERT INTO `record` VALUES(378, '2013-04-06 17:57:21', 76, 'review', 17, 'absolute');
INSERT INTO `record` VALUES(379, '2013-04-06 17:57:21', 76, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(380, '2013-04-06 17:57:21', 76, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(381, '2013-04-06 17:57:21', 77, 'checkin', 1732, 'absolute');
INSERT INTO `record` VALUES(382, '2013-04-06 17:57:21', 77, 'checkin-unique', 360, 'absolute');
INSERT INTO `record` VALUES(383, '2013-04-06 17:57:21', 77, 'review', 14, 'absolute');
INSERT INTO `record` VALUES(384, '2013-04-06 17:57:21', 77, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(385, '2013-04-06 17:57:21', 77, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(386, '2013-04-06 17:57:21', 78, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(387, '2013-04-06 17:57:21', 78, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(388, '2013-04-06 17:57:21', 78, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(389, '2013-04-06 17:57:21', 78, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(390, '2013-04-06 17:57:21', 78, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(391, '2013-04-06 17:57:21', 79, 'checkin', 494, 'absolute');
INSERT INTO `record` VALUES(392, '2013-04-06 17:57:21', 79, 'checkin-unique', 139, 'absolute');
INSERT INTO `record` VALUES(393, '2013-04-06 17:57:21', 79, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(394, '2013-04-06 17:57:21', 79, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(395, '2013-04-06 17:57:21', 79, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(396, '2013-04-06 17:57:21', 80, 'checkin', 55, 'absolute');
INSERT INTO `record` VALUES(397, '2013-04-06 17:57:21', 80, 'checkin-unique', 8, 'absolute');
INSERT INTO `record` VALUES(398, '2013-04-06 17:57:21', 80, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(399, '2013-04-06 17:57:21', 80, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(400, '2013-04-06 17:57:21', 80, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(401, '2013-04-06 17:57:21', 81, 'checkin', 256, 'absolute');
INSERT INTO `record` VALUES(402, '2013-04-06 17:57:21', 81, 'checkin-unique', 68, 'absolute');
INSERT INTO `record` VALUES(403, '2013-04-06 17:57:21', 81, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(404, '2013-04-06 17:57:21', 81, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(405, '2013-04-06 17:57:21', 81, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(406, '2013-04-06 17:57:21', 82, 'checkin', 12, 'absolute');
INSERT INTO `record` VALUES(407, '2013-04-06 17:57:21', 82, 'checkin-unique', 6, 'absolute');
INSERT INTO `record` VALUES(408, '2013-04-06 17:57:21', 82, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(409, '2013-04-06 17:57:21', 82, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(410, '2013-04-06 17:57:21', 82, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(411, '2013-04-06 17:57:22', 83, 'checkin', 3890, 'absolute');
INSERT INTO `record` VALUES(412, '2013-04-06 17:57:22', 83, 'checkin-unique', 1057, 'absolute');
INSERT INTO `record` VALUES(413, '2013-04-06 17:57:22', 83, 'review', 29, 'absolute');
INSERT INTO `record` VALUES(414, '2013-04-06 17:57:22', 83, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(415, '2013-04-06 17:57:22', 83, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(416, '2013-04-06 17:57:23', 84, 'checkin', 67, 'absolute');
INSERT INTO `record` VALUES(417, '2013-04-06 17:57:23', 84, 'checkin-unique', 17, 'absolute');
INSERT INTO `record` VALUES(418, '2013-04-06 17:57:23', 84, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(419, '2013-04-06 17:57:23', 84, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(420, '2013-04-06 17:57:23', 84, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(421, '2013-04-06 17:57:23', 85, 'checkin', 111, 'absolute');
INSERT INTO `record` VALUES(422, '2013-04-06 17:57:23', 85, 'checkin-unique', 51, 'absolute');
INSERT INTO `record` VALUES(423, '2013-04-06 17:57:23', 85, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(424, '2013-04-06 17:57:23', 85, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(425, '2013-04-06 17:57:23', 85, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(426, '2013-04-06 17:57:24', 86, 'checkin', 138, 'absolute');
INSERT INTO `record` VALUES(427, '2013-04-06 17:57:24', 86, 'checkin-unique', 61, 'absolute');
INSERT INTO `record` VALUES(428, '2013-04-06 17:57:24', 86, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(429, '2013-04-06 17:57:24', 86, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(430, '2013-04-06 17:57:24', 86, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(431, '2013-04-06 17:57:24', 87, 'checkin', 217, 'absolute');
INSERT INTO `record` VALUES(432, '2013-04-06 17:57:24', 87, 'checkin-unique', 68, 'absolute');
INSERT INTO `record` VALUES(433, '2013-04-06 17:57:24', 87, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(434, '2013-04-06 17:57:24', 87, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(435, '2013-04-06 17:57:24', 87, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(436, '2013-04-06 17:57:24', 88, 'checkin', 76, 'absolute');
INSERT INTO `record` VALUES(437, '2013-04-06 17:57:24', 88, 'checkin-unique', 49, 'absolute');
INSERT INTO `record` VALUES(438, '2013-04-06 17:57:24', 88, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(439, '2013-04-06 17:57:24', 88, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(440, '2013-04-06 17:57:24', 88, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(441, '2013-04-06 17:57:24', 89, 'checkin', 13, 'absolute');
INSERT INTO `record` VALUES(442, '2013-04-06 17:57:24', 89, 'checkin-unique', 5, 'absolute');
INSERT INTO `record` VALUES(443, '2013-04-06 17:57:24', 89, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(444, '2013-04-06 17:57:24', 89, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(445, '2013-04-06 17:57:24', 89, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(446, '2013-04-06 17:57:25', 90, 'checkin', 15042, 'absolute');
INSERT INTO `record` VALUES(447, '2013-04-06 17:57:25', 90, 'checkin-unique', 6172, 'absolute');
INSERT INTO `record` VALUES(448, '2013-04-06 17:57:25', 90, 'review', 48, 'absolute');
INSERT INTO `record` VALUES(449, '2013-04-06 17:57:25', 90, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(450, '2013-04-06 17:57:25', 90, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(451, '2013-04-06 17:57:27', 91, 'checkin', 48, 'absolute');
INSERT INTO `record` VALUES(452, '2013-04-06 17:57:27', 91, 'checkin-unique', 13, 'absolute');
INSERT INTO `record` VALUES(453, '2013-04-06 17:57:27', 91, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(454, '2013-04-06 17:57:27', 91, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(455, '2013-04-06 17:57:27', 91, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(456, '2013-04-06 17:57:27', 92, 'checkin', 39, 'absolute');
INSERT INTO `record` VALUES(457, '2013-04-06 17:57:27', 92, 'checkin-unique', 18, 'absolute');
INSERT INTO `record` VALUES(458, '2013-04-06 17:57:27', 92, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(459, '2013-04-06 17:57:27', 92, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(460, '2013-04-06 17:57:27', 92, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(461, '2013-04-06 17:57:28', 93, 'checkin', 50, 'absolute');
INSERT INTO `record` VALUES(462, '2013-04-06 17:57:28', 93, 'checkin-unique', 27, 'absolute');
INSERT INTO `record` VALUES(463, '2013-04-06 17:57:28', 93, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(464, '2013-04-06 17:57:28', 93, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(465, '2013-04-06 17:57:28', 93, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(466, '2013-04-06 17:57:28', 94, 'checkin', 15, 'absolute');
INSERT INTO `record` VALUES(467, '2013-04-06 17:57:28', 94, 'checkin-unique', 7, 'absolute');
INSERT INTO `record` VALUES(468, '2013-04-06 17:57:28', 94, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(469, '2013-04-06 17:57:28', 94, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(470, '2013-04-06 17:57:28', 94, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(471, '2013-04-06 17:57:28', 95, 'checkin', 387, 'absolute');
INSERT INTO `record` VALUES(472, '2013-04-06 17:57:28', 95, 'checkin-unique', 74, 'absolute');
INSERT INTO `record` VALUES(473, '2013-04-06 17:57:28', 95, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(474, '2013-04-06 17:57:28', 95, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(475, '2013-04-06 17:57:28', 95, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(476, '2013-04-06 17:57:33', 96, 'checkin', 262, 'absolute');
INSERT INTO `record` VALUES(477, '2013-04-06 17:57:33', 96, 'checkin-unique', 42, 'absolute');
INSERT INTO `record` VALUES(478, '2013-04-06 17:57:33', 96, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(479, '2013-04-06 17:57:33', 96, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(480, '2013-04-06 17:57:33', 96, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(481, '2013-04-06 17:57:33', 97, 'checkin', 13, 'absolute');
INSERT INTO `record` VALUES(482, '2013-04-06 17:57:33', 97, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(483, '2013-04-06 17:57:33', 97, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(484, '2013-04-06 17:57:33', 97, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(485, '2013-04-06 17:57:33', 97, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(486, '2013-04-06 17:57:34', 98, 'checkin', 933, 'absolute');
INSERT INTO `record` VALUES(487, '2013-04-06 17:57:34', 98, 'checkin-unique', 205, 'absolute');
INSERT INTO `record` VALUES(488, '2013-04-06 17:57:34', 98, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(489, '2013-04-06 17:57:34', 98, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(490, '2013-04-06 17:57:34', 98, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(491, '2013-04-06 17:57:34', 99, 'checkin', 445, 'absolute');
INSERT INTO `record` VALUES(492, '2013-04-06 17:57:34', 99, 'checkin-unique', 28, 'absolute');
INSERT INTO `record` VALUES(493, '2013-04-06 17:57:34', 99, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(494, '2013-04-06 17:57:34', 99, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(495, '2013-04-06 17:57:34', 99, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(496, '2013-04-06 17:57:35', 100, 'checkin', 516, 'absolute');
INSERT INTO `record` VALUES(497, '2013-04-06 17:57:35', 100, 'checkin-unique', 93, 'absolute');
INSERT INTO `record` VALUES(498, '2013-04-06 17:57:35', 100, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(499, '2013-04-06 17:57:35', 100, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(500, '2013-04-06 17:57:35', 100, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(501, '2013-04-06 17:57:35', 101, 'checkin', 229, 'absolute');
INSERT INTO `record` VALUES(502, '2013-04-06 17:57:35', 101, 'checkin-unique', 6, 'absolute');
INSERT INTO `record` VALUES(503, '2013-04-06 17:57:35', 101, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(504, '2013-04-06 17:57:35', 101, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(505, '2013-04-06 17:57:35', 101, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(506, '2013-04-06 17:57:35', 102, 'checkin', 1003, 'absolute');
INSERT INTO `record` VALUES(507, '2013-04-06 17:57:35', 102, 'checkin-unique', 421, 'absolute');
INSERT INTO `record` VALUES(508, '2013-04-06 17:57:35', 102, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(509, '2013-04-06 17:57:35', 102, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(510, '2013-04-06 17:57:35', 102, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(511, '2013-04-06 17:57:35', 103, 'checkin', 69, 'absolute');
INSERT INTO `record` VALUES(512, '2013-04-06 17:57:35', 103, 'checkin-unique', 27, 'absolute');
INSERT INTO `record` VALUES(513, '2013-04-06 17:57:35', 103, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(514, '2013-04-06 17:57:35', 103, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(515, '2013-04-06 17:57:35', 103, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(516, '2013-04-06 17:57:36', 104, 'checkin', 4, 'absolute');
INSERT INTO `record` VALUES(517, '2013-04-06 17:57:36', 104, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(518, '2013-04-06 17:57:36', 104, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(519, '2013-04-06 17:57:36', 104, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(520, '2013-04-06 17:57:36', 104, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(521, '2013-04-06 17:57:36', 105, 'checkin', 641, 'absolute');
INSERT INTO `record` VALUES(522, '2013-04-06 17:57:36', 105, 'checkin-unique', 142, 'absolute');
INSERT INTO `record` VALUES(523, '2013-04-06 17:57:36', 105, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(524, '2013-04-06 17:57:36', 105, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(525, '2013-04-06 17:57:36', 105, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(526, '2013-04-06 17:57:36', 106, 'checkin', 68, 'absolute');
INSERT INTO `record` VALUES(527, '2013-04-06 17:57:36', 106, 'checkin-unique', 14, 'absolute');
INSERT INTO `record` VALUES(528, '2013-04-06 17:57:36', 106, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(529, '2013-04-06 17:57:36', 106, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(530, '2013-04-06 17:57:36', 106, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(531, '2013-04-06 17:57:36', 107, 'checkin', 165, 'absolute');
INSERT INTO `record` VALUES(532, '2013-04-06 17:57:36', 107, 'checkin-unique', 31, 'absolute');
INSERT INTO `record` VALUES(533, '2013-04-06 17:57:36', 107, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(534, '2013-04-06 17:57:36', 107, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(535, '2013-04-06 17:57:36', 107, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(536, '2013-04-06 17:57:36', 108, 'checkin', 55, 'absolute');
INSERT INTO `record` VALUES(537, '2013-04-06 17:57:36', 108, 'checkin-unique', 14, 'absolute');
INSERT INTO `record` VALUES(538, '2013-04-06 17:57:36', 108, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(539, '2013-04-06 17:57:36', 108, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(540, '2013-04-06 17:57:36', 108, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(541, '2013-04-06 17:57:36', 109, 'checkin', 159, 'absolute');
INSERT INTO `record` VALUES(542, '2013-04-06 17:57:36', 109, 'checkin-unique', 35, 'absolute');
INSERT INTO `record` VALUES(543, '2013-04-06 17:57:36', 109, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(544, '2013-04-06 17:57:36', 109, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(545, '2013-04-06 17:57:36', 109, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(546, '2013-04-06 17:57:36', 110, 'checkin', 5, 'absolute');
INSERT INTO `record` VALUES(547, '2013-04-06 17:57:36', 110, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(548, '2013-04-06 17:57:36', 110, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(549, '2013-04-06 17:57:36', 110, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(550, '2013-04-06 17:57:36', 110, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(551, '2013-04-06 17:57:36', 111, 'checkin', 14, 'absolute');
INSERT INTO `record` VALUES(552, '2013-04-06 17:57:36', 111, 'checkin-unique', 5, 'absolute');
INSERT INTO `record` VALUES(553, '2013-04-06 17:57:36', 111, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(554, '2013-04-06 17:57:36', 111, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(555, '2013-04-06 17:57:36', 111, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(556, '2013-04-06 17:57:37', 112, 'checkin', 752, 'absolute');
INSERT INTO `record` VALUES(557, '2013-04-06 17:57:37', 112, 'checkin-unique', 148, 'absolute');
INSERT INTO `record` VALUES(558, '2013-04-06 17:57:37', 112, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(559, '2013-04-06 17:57:37', 112, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(560, '2013-04-06 17:57:37', 112, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(561, '2013-04-06 17:57:37', 113, 'checkin', 1848, 'absolute');
INSERT INTO `record` VALUES(562, '2013-04-06 17:57:37', 113, 'checkin-unique', 366, 'absolute');
INSERT INTO `record` VALUES(563, '2013-04-06 17:57:37', 113, 'review', 11, 'absolute');
INSERT INTO `record` VALUES(564, '2013-04-06 17:57:37', 113, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(565, '2013-04-06 17:57:37', 113, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(566, '2013-04-06 17:57:37', 114, 'checkin', 107, 'absolute');
INSERT INTO `record` VALUES(567, '2013-04-06 17:57:37', 114, 'checkin-unique', 35, 'absolute');
INSERT INTO `record` VALUES(568, '2013-04-06 17:57:37', 114, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(569, '2013-04-06 17:57:37', 114, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(570, '2013-04-06 17:57:37', 114, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(571, '2013-04-06 17:58:03', 115, 'checkin', 1097, 'absolute');
INSERT INTO `record` VALUES(572, '2013-04-06 17:58:03', 115, 'checkin-unique', 303, 'absolute');
INSERT INTO `record` VALUES(573, '2013-04-06 17:58:03', 115, 'review', 10, 'absolute');
INSERT INTO `record` VALUES(574, '2013-04-06 17:58:03', 115, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(575, '2013-04-06 17:58:03', 115, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(576, '2013-04-06 17:58:03', 116, 'checkin', 16, 'absolute');
INSERT INTO `record` VALUES(577, '2013-04-06 17:58:03', 116, 'checkin-unique', 9, 'absolute');
INSERT INTO `record` VALUES(578, '2013-04-06 17:58:03', 116, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(579, '2013-04-06 17:58:03', 116, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(580, '2013-04-06 17:58:03', 116, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(581, '2013-04-06 17:58:03', 117, 'checkin', 184, 'absolute');
INSERT INTO `record` VALUES(582, '2013-04-06 17:58:03', 117, 'checkin-unique', 32, 'absolute');
INSERT INTO `record` VALUES(583, '2013-04-06 17:58:03', 117, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(584, '2013-04-06 17:58:03', 117, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(585, '2013-04-06 17:58:03', 117, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(586, '2013-04-06 17:58:03', 118, 'checkin', 2, 'absolute');
INSERT INTO `record` VALUES(587, '2013-04-06 17:58:03', 118, 'checkin-unique', 2, 'absolute');
INSERT INTO `record` VALUES(588, '2013-04-06 17:58:03', 118, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(589, '2013-04-06 17:58:03', 118, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(590, '2013-04-06 17:58:03', 118, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(591, '2013-04-06 17:58:03', 119, 'checkin', 2135, 'absolute');
INSERT INTO `record` VALUES(592, '2013-04-06 17:58:03', 119, 'checkin-unique', 390, 'absolute');
INSERT INTO `record` VALUES(593, '2013-04-06 17:58:03', 119, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(594, '2013-04-06 17:58:03', 119, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(595, '2013-04-06 17:58:03', 119, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(596, '2013-04-06 17:58:03', 120, 'checkin', 666, 'absolute');
INSERT INTO `record` VALUES(597, '2013-04-06 17:58:03', 120, 'checkin-unique', 167, 'absolute');
INSERT INTO `record` VALUES(598, '2013-04-06 17:58:03', 120, 'review', 9, 'absolute');
INSERT INTO `record` VALUES(599, '2013-04-06 17:58:03', 120, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(600, '2013-04-06 17:58:03', 120, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(601, '2013-04-06 17:58:03', 121, 'checkin', 2618, 'absolute');
INSERT INTO `record` VALUES(602, '2013-04-06 17:58:03', 121, 'checkin-unique', 539, 'absolute');
INSERT INTO `record` VALUES(603, '2013-04-06 17:58:03', 121, 'review', 12, 'absolute');
INSERT INTO `record` VALUES(604, '2013-04-06 17:58:03', 121, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(605, '2013-04-06 17:58:03', 121, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(606, '2013-04-06 17:58:03', 122, 'checkin', 658, 'absolute');
INSERT INTO `record` VALUES(607, '2013-04-06 17:58:03', 122, 'checkin-unique', 196, 'absolute');
INSERT INTO `record` VALUES(608, '2013-04-06 17:58:03', 122, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(609, '2013-04-06 17:58:03', 122, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(610, '2013-04-06 17:58:03', 122, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(611, '2013-04-06 17:58:03', 123, 'checkin', 373, 'absolute');
INSERT INTO `record` VALUES(612, '2013-04-06 17:58:03', 123, 'checkin-unique', 128, 'absolute');
INSERT INTO `record` VALUES(613, '2013-04-06 17:58:03', 123, 'review', 11, 'absolute');
INSERT INTO `record` VALUES(614, '2013-04-06 17:58:03', 123, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(615, '2013-04-06 17:58:03', 123, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(616, '2013-04-06 17:58:03', 124, 'checkin', 6, 'absolute');
INSERT INTO `record` VALUES(617, '2013-04-06 17:58:03', 124, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(618, '2013-04-06 17:58:03', 124, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(619, '2013-04-06 17:58:03', 124, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(620, '2013-04-06 17:58:03', 124, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(621, '2013-04-06 17:58:03', 125, 'checkin', 117, 'absolute');
INSERT INTO `record` VALUES(622, '2013-04-06 17:58:03', 125, 'checkin-unique', 63, 'absolute');
INSERT INTO `record` VALUES(623, '2013-04-06 17:58:03', 125, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(624, '2013-04-06 17:58:03', 125, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(625, '2013-04-06 17:58:03', 125, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(626, '2013-04-06 17:58:04', 126, 'checkin', 0, 'absolute');
INSERT INTO `record` VALUES(627, '2013-04-06 17:58:04', 126, 'checkin-unique', 0, 'absolute');
INSERT INTO `record` VALUES(628, '2013-04-06 17:58:04', 126, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(629, '2013-04-06 17:58:04', 126, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(630, '2013-04-06 17:58:04', 126, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(631, '2013-04-06 17:58:04', 127, 'checkin', 1264, 'absolute');
INSERT INTO `record` VALUES(632, '2013-04-06 17:58:04', 127, 'checkin-unique', 609, 'absolute');
INSERT INTO `record` VALUES(633, '2013-04-06 17:58:04', 127, 'review', 8, 'absolute');
INSERT INTO `record` VALUES(634, '2013-04-06 17:58:04', 127, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(635, '2013-04-06 17:58:04', 127, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(636, '2013-04-06 17:58:04', 128, 'checkin', 652, 'absolute');
INSERT INTO `record` VALUES(637, '2013-04-06 17:58:04', 128, 'checkin-unique', 184, 'absolute');
INSERT INTO `record` VALUES(638, '2013-04-06 17:58:04', 128, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(639, '2013-04-06 17:58:04', 128, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(640, '2013-04-06 17:58:04', 128, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(641, '2013-04-06 17:58:04', 129, 'checkin', 173, 'absolute');
INSERT INTO `record` VALUES(642, '2013-04-06 17:58:04', 129, 'checkin-unique', 107, 'absolute');
INSERT INTO `record` VALUES(643, '2013-04-06 17:58:04', 129, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(644, '2013-04-06 17:58:04', 129, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(645, '2013-04-06 17:58:04', 129, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(646, '2013-04-06 17:58:04', 130, 'checkin', 12, 'absolute');
INSERT INTO `record` VALUES(647, '2013-04-06 17:58:04', 130, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(648, '2013-04-06 17:58:04', 130, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(649, '2013-04-06 17:58:04', 130, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(650, '2013-04-06 17:58:04', 130, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(651, '2013-04-06 17:58:04', 131, 'checkin', 2366, 'absolute');
INSERT INTO `record` VALUES(652, '2013-04-06 17:58:04', 131, 'checkin-unique', 542, 'absolute');
INSERT INTO `record` VALUES(653, '2013-04-06 17:58:04', 131, 'review', 12, 'absolute');
INSERT INTO `record` VALUES(654, '2013-04-06 17:58:04', 131, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(655, '2013-04-06 17:58:04', 131, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(656, '2013-04-06 17:58:04', 132, 'checkin', 34, 'absolute');
INSERT INTO `record` VALUES(657, '2013-04-06 17:58:04', 132, 'checkin-unique', 17, 'absolute');
INSERT INTO `record` VALUES(658, '2013-04-06 17:58:04', 132, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(659, '2013-04-06 17:58:04', 132, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(660, '2013-04-06 17:58:04', 132, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(661, '2013-04-06 17:58:04', 133, 'checkin', 19, 'absolute');
INSERT INTO `record` VALUES(662, '2013-04-06 17:58:04', 133, 'checkin-unique', 7, 'absolute');
INSERT INTO `record` VALUES(663, '2013-04-06 17:58:04', 133, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(664, '2013-04-06 17:58:04', 133, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(665, '2013-04-06 17:58:04', 133, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(666, '2013-04-06 17:58:04', 134, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(667, '2013-04-06 17:58:04', 134, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(668, '2013-04-06 17:58:04', 134, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(669, '2013-04-06 17:58:04', 134, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(670, '2013-04-06 17:58:04', 134, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(671, '2013-04-06 17:58:04', 135, 'checkin', 1411, 'absolute');
INSERT INTO `record` VALUES(672, '2013-04-06 17:58:04', 135, 'checkin-unique', 342, 'absolute');
INSERT INTO `record` VALUES(673, '2013-04-06 17:58:04', 135, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(674, '2013-04-06 17:58:04', 135, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(675, '2013-04-06 17:58:04', 135, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(676, '2013-04-06 17:58:04', 136, 'checkin', 779, 'absolute');
INSERT INTO `record` VALUES(677, '2013-04-06 17:58:04', 136, 'checkin-unique', 138, 'absolute');
INSERT INTO `record` VALUES(678, '2013-04-06 17:58:04', 136, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(679, '2013-04-06 17:58:04', 136, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(680, '2013-04-06 17:58:04', 136, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(681, '2013-04-06 17:58:04', 137, 'checkin', 25, 'absolute');
INSERT INTO `record` VALUES(682, '2013-04-06 17:58:04', 137, 'checkin-unique', 9, 'absolute');
INSERT INTO `record` VALUES(683, '2013-04-06 17:58:04', 137, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(684, '2013-04-06 17:58:04', 137, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(685, '2013-04-06 17:58:04', 137, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(686, '2013-04-06 17:58:04', 138, 'checkin', 3865, 'absolute');
INSERT INTO `record` VALUES(687, '2013-04-06 17:58:04', 138, 'checkin-unique', 1447, 'absolute');
INSERT INTO `record` VALUES(688, '2013-04-06 17:58:04', 138, 'review', 21, 'absolute');
INSERT INTO `record` VALUES(689, '2013-04-06 17:58:04', 138, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(690, '2013-04-06 17:58:04', 138, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(691, '2013-04-06 17:58:04', 139, 'checkin', 5, 'absolute');
INSERT INTO `record` VALUES(692, '2013-04-06 17:58:04', 139, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(693, '2013-04-06 17:58:04', 139, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(694, '2013-04-06 17:58:04', 139, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(695, '2013-04-06 17:58:04', 139, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(696, '2013-04-06 17:58:04', 140, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(697, '2013-04-06 17:58:04', 140, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(698, '2013-04-06 17:58:04', 140, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(699, '2013-04-06 17:58:04', 140, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(700, '2013-04-06 17:58:04', 140, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(701, '2013-04-06 17:58:04', 141, 'checkin', 1036, 'absolute');
INSERT INTO `record` VALUES(702, '2013-04-06 17:58:04', 141, 'checkin-unique', 328, 'absolute');
INSERT INTO `record` VALUES(703, '2013-04-06 17:58:04', 141, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(704, '2013-04-06 17:58:04', 141, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(705, '2013-04-06 17:58:04', 141, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(706, '2013-04-06 17:58:04', 142, 'checkin', 334, 'absolute');
INSERT INTO `record` VALUES(707, '2013-04-06 17:58:04', 142, 'checkin-unique', 113, 'absolute');
INSERT INTO `record` VALUES(708, '2013-04-06 17:58:04', 142, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(709, '2013-04-06 17:58:04', 142, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(710, '2013-04-06 17:58:04', 142, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(711, '2013-04-06 17:58:04', 143, 'checkin', 183, 'absolute');
INSERT INTO `record` VALUES(712, '2013-04-06 17:58:04', 143, 'checkin-unique', 67, 'absolute');
INSERT INTO `record` VALUES(713, '2013-04-06 17:58:04', 143, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(714, '2013-04-06 17:58:04', 143, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(715, '2013-04-06 17:58:04', 143, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(716, '2013-04-06 17:58:04', 144, 'checkin', 334, 'absolute');
INSERT INTO `record` VALUES(717, '2013-04-06 17:58:04', 144, 'checkin-unique', 117, 'absolute');
INSERT INTO `record` VALUES(718, '2013-04-06 17:58:04', 144, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(719, '2013-04-06 17:58:04', 144, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(720, '2013-04-06 17:58:04', 144, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(721, '2013-04-06 17:58:04', 145, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(722, '2013-04-06 17:58:04', 145, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(723, '2013-04-06 17:58:04', 145, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(724, '2013-04-06 17:58:04', 145, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(725, '2013-04-06 17:58:04', 145, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(726, '2013-04-06 17:58:04', 146, 'checkin', 111, 'absolute');
INSERT INTO `record` VALUES(727, '2013-04-06 17:58:04', 146, 'checkin-unique', 47, 'absolute');
INSERT INTO `record` VALUES(728, '2013-04-06 17:58:04', 146, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(729, '2013-04-06 17:58:04', 146, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(730, '2013-04-06 17:58:04', 146, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(731, '2013-04-06 17:58:04', 147, 'checkin', 4, 'absolute');
INSERT INTO `record` VALUES(732, '2013-04-06 17:58:04', 147, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(733, '2013-04-06 17:58:04', 147, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(734, '2013-04-06 17:58:04', 147, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(735, '2013-04-06 17:58:04', 147, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(736, '2013-04-06 17:58:04', 148, 'checkin', 69, 'absolute');
INSERT INTO `record` VALUES(737, '2013-04-06 17:58:04', 148, 'checkin-unique', 27, 'absolute');
INSERT INTO `record` VALUES(738, '2013-04-06 17:58:04', 148, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(739, '2013-04-06 17:58:04', 148, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(740, '2013-04-06 17:58:04', 148, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(741, '2013-04-06 17:58:04', 149, 'checkin', 504, 'absolute');
INSERT INTO `record` VALUES(742, '2013-04-06 17:58:04', 149, 'checkin-unique', 190, 'absolute');
INSERT INTO `record` VALUES(743, '2013-04-06 17:58:04', 149, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(744, '2013-04-06 17:58:04', 149, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(745, '2013-04-06 17:58:04', 149, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(746, '2013-04-06 17:58:04', 150, 'checkin', 875, 'absolute');
INSERT INTO `record` VALUES(747, '2013-04-06 17:58:04', 150, 'checkin-unique', 351, 'absolute');
INSERT INTO `record` VALUES(748, '2013-04-06 17:58:04', 150, 'review', 9, 'absolute');
INSERT INTO `record` VALUES(749, '2013-04-06 17:58:04', 150, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(750, '2013-04-06 17:58:04', 150, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(751, '2013-04-06 17:58:04', 151, 'checkin', 2135, 'absolute');
INSERT INTO `record` VALUES(752, '2013-04-06 17:58:04', 151, 'checkin-unique', 672, 'absolute');
INSERT INTO `record` VALUES(753, '2013-04-06 17:58:04', 151, 'review', 27, 'absolute');
INSERT INTO `record` VALUES(754, '2013-04-06 17:58:04', 151, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(755, '2013-04-06 17:58:04', 151, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(756, '2013-04-06 17:58:04', 152, 'checkin', 17461, 'absolute');
INSERT INTO `record` VALUES(757, '2013-04-06 17:58:04', 152, 'checkin-unique', 4234, 'absolute');
INSERT INTO `record` VALUES(758, '2013-04-06 17:58:04', 152, 'review', 96, 'absolute');
INSERT INTO `record` VALUES(759, '2013-04-06 17:58:04', 152, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(760, '2013-04-06 17:58:04', 152, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(761, '2013-04-06 17:58:04', 153, 'checkin', 1555, 'absolute');
INSERT INTO `record` VALUES(762, '2013-04-06 17:58:04', 153, 'checkin-unique', 467, 'absolute');
INSERT INTO `record` VALUES(763, '2013-04-06 17:58:04', 153, 'review', 9, 'absolute');
INSERT INTO `record` VALUES(764, '2013-04-06 17:58:04', 153, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(765, '2013-04-06 17:58:04', 153, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(766, '2013-04-06 17:58:04', 154, 'checkin', 157, 'absolute');
INSERT INTO `record` VALUES(767, '2013-04-06 17:58:04', 154, 'checkin-unique', 98, 'absolute');
INSERT INTO `record` VALUES(768, '2013-04-06 17:58:04', 154, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(769, '2013-04-06 17:58:04', 154, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(770, '2013-04-06 17:58:04', 154, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(771, '2013-04-06 17:58:04', 155, 'checkin', 197, 'absolute');
INSERT INTO `record` VALUES(772, '2013-04-06 17:58:04', 155, 'checkin-unique', 88, 'absolute');
INSERT INTO `record` VALUES(773, '2013-04-06 17:58:04', 155, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(774, '2013-04-06 17:58:04', 155, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(775, '2013-04-06 17:58:04', 155, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(776, '2013-04-06 17:58:04', 156, 'checkin', 1625, 'absolute');
INSERT INTO `record` VALUES(777, '2013-04-06 17:58:04', 156, 'checkin-unique', 387, 'absolute');
INSERT INTO `record` VALUES(778, '2013-04-06 17:58:04', 156, 'review', 14, 'absolute');
INSERT INTO `record` VALUES(779, '2013-04-06 17:58:04', 156, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(780, '2013-04-06 17:58:04', 156, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(781, '2013-04-06 17:58:05', 157, 'checkin', 2581, 'absolute');
INSERT INTO `record` VALUES(782, '2013-04-06 17:58:05', 157, 'checkin-unique', 619, 'absolute');
INSERT INTO `record` VALUES(783, '2013-04-06 17:58:05', 157, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(784, '2013-04-06 17:58:05', 157, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(785, '2013-04-06 17:58:05', 157, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(786, '2013-04-06 17:58:05', 158, 'checkin', 1339, 'absolute');
INSERT INTO `record` VALUES(787, '2013-04-06 17:58:05', 158, 'checkin-unique', 353, 'absolute');
INSERT INTO `record` VALUES(788, '2013-04-06 17:58:05', 158, 'review', 10, 'absolute');
INSERT INTO `record` VALUES(789, '2013-04-06 17:58:05', 158, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(790, '2013-04-06 17:58:05', 158, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(791, '2013-04-06 17:58:05', 159, 'checkin', 61, 'absolute');
INSERT INTO `record` VALUES(792, '2013-04-06 17:58:05', 159, 'checkin-unique', 23, 'absolute');
INSERT INTO `record` VALUES(793, '2013-04-06 17:58:05', 159, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(794, '2013-04-06 17:58:05', 159, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(795, '2013-04-06 17:58:05', 159, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(796, '2013-04-06 17:58:05', 160, 'checkin', 6224, 'absolute');
INSERT INTO `record` VALUES(797, '2013-04-06 17:58:05', 160, 'checkin-unique', 2160, 'absolute');
INSERT INTO `record` VALUES(798, '2013-04-06 17:58:05', 160, 'review', 33, 'absolute');
INSERT INTO `record` VALUES(799, '2013-04-06 17:58:05', 160, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(800, '2013-04-06 17:58:05', 160, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(801, '2013-04-06 17:58:05', 161, 'checkin', 1447, 'absolute');
INSERT INTO `record` VALUES(802, '2013-04-06 17:58:05', 161, 'checkin-unique', 542, 'absolute');
INSERT INTO `record` VALUES(803, '2013-04-06 17:58:05', 161, 'review', 10, 'absolute');
INSERT INTO `record` VALUES(804, '2013-04-06 17:58:05', 161, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(805, '2013-04-06 17:58:05', 161, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(806, '2013-04-06 17:58:05', 162, 'checkin', 91, 'absolute');
INSERT INTO `record` VALUES(807, '2013-04-06 17:58:05', 162, 'checkin-unique', 37, 'absolute');
INSERT INTO `record` VALUES(808, '2013-04-06 17:58:05', 162, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(809, '2013-04-06 17:58:05', 162, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(810, '2013-04-06 17:58:05', 162, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(811, '2013-04-06 17:58:05', 163, 'checkin', 1691, 'absolute');
INSERT INTO `record` VALUES(812, '2013-04-06 17:58:05', 163, 'checkin-unique', 582, 'absolute');
INSERT INTO `record` VALUES(813, '2013-04-06 17:58:05', 163, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(814, '2013-04-06 17:58:05', 163, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(815, '2013-04-06 17:58:05', 163, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(816, '2013-04-06 17:58:05', 164, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(817, '2013-04-06 17:58:05', 164, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(818, '2013-04-06 17:58:05', 164, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(819, '2013-04-06 17:58:05', 164, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(820, '2013-04-06 17:58:05', 164, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(821, '2013-04-06 17:58:05', 165, 'checkin', 2524, 'absolute');
INSERT INTO `record` VALUES(822, '2013-04-06 17:58:05', 165, 'checkin-unique', 847, 'absolute');
INSERT INTO `record` VALUES(823, '2013-04-06 17:58:05', 165, 'review', 18, 'absolute');
INSERT INTO `record` VALUES(824, '2013-04-06 17:58:05', 165, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(825, '2013-04-06 17:58:05', 165, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(826, '2013-04-06 17:58:05', 166, 'checkin', 2789, 'absolute');
INSERT INTO `record` VALUES(827, '2013-04-06 17:58:05', 166, 'checkin-unique', 751, 'absolute');
INSERT INTO `record` VALUES(828, '2013-04-06 17:58:05', 166, 'review', 16, 'absolute');
INSERT INTO `record` VALUES(829, '2013-04-06 17:58:05', 166, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(830, '2013-04-06 17:58:05', 166, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(831, '2013-04-06 17:58:05', 167, 'checkin', 2754, 'absolute');
INSERT INTO `record` VALUES(832, '2013-04-06 17:58:05', 167, 'checkin-unique', 794, 'absolute');
INSERT INTO `record` VALUES(833, '2013-04-06 17:58:05', 167, 'review', 15, 'absolute');
INSERT INTO `record` VALUES(834, '2013-04-06 17:58:05', 167, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(835, '2013-04-06 17:58:05', 167, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(836, '2013-04-06 17:58:05', 168, 'checkin', 48, 'absolute');
INSERT INTO `record` VALUES(837, '2013-04-06 17:58:05', 168, 'checkin-unique', 20, 'absolute');
INSERT INTO `record` VALUES(838, '2013-04-06 17:58:05', 168, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(839, '2013-04-06 17:58:05', 168, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(840, '2013-04-06 17:58:05', 168, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(841, '2013-04-06 17:58:05', 169, 'checkin', 97, 'absolute');
INSERT INTO `record` VALUES(842, '2013-04-06 17:58:05', 169, 'checkin-unique', 56, 'absolute');
INSERT INTO `record` VALUES(843, '2013-04-06 17:58:05', 169, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(844, '2013-04-06 17:58:05', 169, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(845, '2013-04-06 17:58:05', 169, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(846, '2013-04-06 17:58:05', 170, 'checkin', 9, 'absolute');
INSERT INTO `record` VALUES(847, '2013-04-06 17:58:05', 170, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(848, '2013-04-06 17:58:05', 170, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(849, '2013-04-06 17:58:05', 170, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(850, '2013-04-06 17:58:05', 170, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(851, '2013-04-06 17:58:05', 171, 'checkin', 160, 'absolute');
INSERT INTO `record` VALUES(852, '2013-04-06 17:58:05', 171, 'checkin-unique', 96, 'absolute');
INSERT INTO `record` VALUES(853, '2013-04-06 17:58:05', 171, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(854, '2013-04-06 17:58:05', 171, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(855, '2013-04-06 17:58:05', 171, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(856, '2013-04-06 17:58:05', 172, 'checkin', 274, 'absolute');
INSERT INTO `record` VALUES(857, '2013-04-06 17:58:05', 172, 'checkin-unique', 96, 'absolute');
INSERT INTO `record` VALUES(858, '2013-04-06 17:58:05', 172, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(859, '2013-04-06 17:58:05', 172, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(860, '2013-04-06 17:58:05', 172, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(861, '2013-04-06 17:58:05', 173, 'checkin', 1262, 'absolute');
INSERT INTO `record` VALUES(862, '2013-04-06 17:58:05', 173, 'checkin-unique', 416, 'absolute');
INSERT INTO `record` VALUES(863, '2013-04-06 17:58:05', 173, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(864, '2013-04-06 17:58:05', 173, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(865, '2013-04-06 17:58:05', 173, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(866, '2013-04-06 17:58:05', 174, 'checkin', 2864, 'absolute');
INSERT INTO `record` VALUES(867, '2013-04-06 17:58:05', 174, 'checkin-unique', 1152, 'absolute');
INSERT INTO `record` VALUES(868, '2013-04-06 17:58:05', 174, 'review', 13, 'absolute');
INSERT INTO `record` VALUES(869, '2013-04-06 17:58:05', 174, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(870, '2013-04-06 17:58:05', 174, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(871, '2013-04-06 17:58:05', 175, 'checkin', 1300, 'absolute');
INSERT INTO `record` VALUES(872, '2013-04-06 17:58:05', 175, 'checkin-unique', 388, 'absolute');
INSERT INTO `record` VALUES(873, '2013-04-06 17:58:05', 175, 'review', 10, 'absolute');
INSERT INTO `record` VALUES(874, '2013-04-06 17:58:05', 175, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(875, '2013-04-06 17:58:05', 175, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(876, '2013-04-06 17:58:05', 176, 'checkin', 278, 'absolute');
INSERT INTO `record` VALUES(877, '2013-04-06 17:58:05', 176, 'checkin-unique', 58, 'absolute');
INSERT INTO `record` VALUES(878, '2013-04-06 17:58:05', 176, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(879, '2013-04-06 17:58:05', 176, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(880, '2013-04-06 17:58:05', 176, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(881, '2013-04-06 17:58:05', 177, 'checkin', 36, 'absolute');
INSERT INTO `record` VALUES(882, '2013-04-06 17:58:05', 177, 'checkin-unique', 14, 'absolute');
INSERT INTO `record` VALUES(883, '2013-04-06 17:58:05', 177, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(884, '2013-04-06 17:58:05', 177, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(885, '2013-04-06 17:58:05', 177, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(886, '2013-04-06 17:58:05', 178, 'checkin', 6, 'absolute');
INSERT INTO `record` VALUES(887, '2013-04-06 17:58:05', 178, 'checkin-unique', 6, 'absolute');
INSERT INTO `record` VALUES(888, '2013-04-06 17:58:05', 178, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(889, '2013-04-06 17:58:05', 178, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(890, '2013-04-06 17:58:05', 178, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(891, '2013-04-06 17:58:05', 179, 'checkin', 804, 'absolute');
INSERT INTO `record` VALUES(892, '2013-04-06 17:58:05', 179, 'checkin-unique', 294, 'absolute');
INSERT INTO `record` VALUES(893, '2013-04-06 17:58:05', 179, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(894, '2013-04-06 17:58:05', 179, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(895, '2013-04-06 17:58:05', 179, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(896, '2013-04-06 17:58:05', 180, 'checkin', 1662, 'absolute');
INSERT INTO `record` VALUES(897, '2013-04-06 17:58:05', 180, 'checkin-unique', 794, 'absolute');
INSERT INTO `record` VALUES(898, '2013-04-06 17:58:05', 180, 'review', 20, 'absolute');
INSERT INTO `record` VALUES(899, '2013-04-06 17:58:05', 180, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(900, '2013-04-06 17:58:05', 180, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(901, '2013-04-06 17:58:05', 181, 'checkin', 522, 'absolute');
INSERT INTO `record` VALUES(902, '2013-04-06 17:58:05', 181, 'checkin-unique', 247, 'absolute');
INSERT INTO `record` VALUES(903, '2013-04-06 17:58:05', 181, 'review', 8, 'absolute');
INSERT INTO `record` VALUES(904, '2013-04-06 17:58:05', 181, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(905, '2013-04-06 17:58:05', 181, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(906, '2013-04-06 17:58:05', 182, 'checkin', 451, 'absolute');
INSERT INTO `record` VALUES(907, '2013-04-06 17:58:05', 182, 'checkin-unique', 91, 'absolute');
INSERT INTO `record` VALUES(908, '2013-04-06 17:58:05', 182, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(909, '2013-04-06 17:58:05', 182, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(910, '2013-04-06 17:58:05', 182, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(911, '2013-04-06 17:58:05', 183, 'checkin', 1100, 'absolute');
INSERT INTO `record` VALUES(912, '2013-04-06 17:58:05', 183, 'checkin-unique', 364, 'absolute');
INSERT INTO `record` VALUES(913, '2013-04-06 17:58:05', 183, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(914, '2013-04-06 17:58:05', 183, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(915, '2013-04-06 17:58:05', 183, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(916, '2013-04-06 17:58:05', 184, 'checkin', 1889, 'absolute');
INSERT INTO `record` VALUES(917, '2013-04-06 17:58:05', 184, 'checkin-unique', 413, 'absolute');
INSERT INTO `record` VALUES(918, '2013-04-06 17:58:05', 184, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(919, '2013-04-06 17:58:05', 184, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(920, '2013-04-06 17:58:05', 184, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(921, '2013-04-06 17:58:05', 185, 'checkin', 2111, 'absolute');
INSERT INTO `record` VALUES(922, '2013-04-06 17:58:05', 185, 'checkin-unique', 940, 'absolute');
INSERT INTO `record` VALUES(923, '2013-04-06 17:58:05', 185, 'review', 21, 'absolute');
INSERT INTO `record` VALUES(924, '2013-04-06 17:58:05', 185, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(925, '2013-04-06 17:58:05', 185, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(926, '2013-04-06 17:58:05', 186, 'checkin', 409, 'absolute');
INSERT INTO `record` VALUES(927, '2013-04-06 17:58:05', 186, 'checkin-unique', 123, 'absolute');
INSERT INTO `record` VALUES(928, '2013-04-06 17:58:05', 186, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(929, '2013-04-06 17:58:05', 186, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(930, '2013-04-06 17:58:05', 186, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(931, '2013-04-06 17:58:05', 187, 'checkin', 39, 'absolute');
INSERT INTO `record` VALUES(932, '2013-04-06 17:58:05', 187, 'checkin-unique', 22, 'absolute');
INSERT INTO `record` VALUES(933, '2013-04-06 17:58:05', 187, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(934, '2013-04-06 17:58:05', 187, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(935, '2013-04-06 17:58:05', 187, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(936, '2013-04-07 10:58:34', 188, 'checkin', 1017, 'absolute');
INSERT INTO `record` VALUES(937, '2013-04-07 10:58:34', 188, 'checkin-unique', 184, 'absolute');
INSERT INTO `record` VALUES(938, '2013-04-07 10:58:34', 188, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(939, '2013-04-07 10:58:34', 188, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(940, '2013-04-07 10:58:34', 188, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(941, '2013-04-07 10:58:34', 189, 'checkin', 8, 'absolute');
INSERT INTO `record` VALUES(942, '2013-04-07 10:58:34', 189, 'checkin-unique', 6, 'absolute');
INSERT INTO `record` VALUES(943, '2013-04-07 10:58:34', 189, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(944, '2013-04-07 10:58:34', 189, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(945, '2013-04-07 10:58:34', 189, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(946, '2013-04-07 10:58:35', 190, 'checkin', 173, 'absolute');
INSERT INTO `record` VALUES(947, '2013-04-07 10:58:35', 190, 'checkin-unique', 103, 'absolute');
INSERT INTO `record` VALUES(948, '2013-04-07 10:58:35', 190, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(949, '2013-04-07 10:58:35', 190, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(950, '2013-04-07 10:58:35', 190, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(951, '2013-04-07 10:58:35', 191, 'checkin', 8, 'absolute');
INSERT INTO `record` VALUES(952, '2013-04-07 10:58:35', 191, 'checkin-unique', 8, 'absolute');
INSERT INTO `record` VALUES(953, '2013-04-07 10:58:35', 191, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(954, '2013-04-07 10:58:35', 191, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(955, '2013-04-07 10:58:35', 191, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(956, '2013-04-07 10:58:35', 192, 'checkin', 170, 'absolute');
INSERT INTO `record` VALUES(957, '2013-04-07 10:58:35', 192, 'checkin-unique', 123, 'absolute');
INSERT INTO `record` VALUES(958, '2013-04-07 10:58:35', 192, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(959, '2013-04-07 10:58:35', 192, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(960, '2013-04-07 10:58:35', 192, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(961, '2013-04-07 10:58:36', 193, 'checkin', 1046, 'absolute');
INSERT INTO `record` VALUES(962, '2013-04-07 10:58:36', 193, 'checkin-unique', 431, 'absolute');
INSERT INTO `record` VALUES(963, '2013-04-07 10:58:36', 193, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(964, '2013-04-07 10:58:36', 193, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(965, '2013-04-07 10:58:36', 193, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(966, '2013-04-07 10:58:36', 194, 'checkin', 259, 'absolute');
INSERT INTO `record` VALUES(967, '2013-04-07 10:58:36', 194, 'checkin-unique', 117, 'absolute');
INSERT INTO `record` VALUES(968, '2013-04-07 10:58:36', 194, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(969, '2013-04-07 10:58:36', 194, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(970, '2013-04-07 10:58:36', 194, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(971, '2013-04-07 10:58:36', 195, 'checkin', 1498, 'absolute');
INSERT INTO `record` VALUES(972, '2013-04-07 10:58:36', 195, 'checkin-unique', 607, 'absolute');
INSERT INTO `record` VALUES(973, '2013-04-07 10:58:36', 195, 'review', 8, 'absolute');
INSERT INTO `record` VALUES(974, '2013-04-07 10:58:36', 195, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(975, '2013-04-07 10:58:36', 195, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(976, '2013-04-07 10:58:36', 196, 'checkin', 514, 'absolute');
INSERT INTO `record` VALUES(977, '2013-04-07 10:58:36', 196, 'checkin-unique', 111, 'absolute');
INSERT INTO `record` VALUES(978, '2013-04-07 10:58:36', 196, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(979, '2013-04-07 10:58:36', 196, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(980, '2013-04-07 10:58:36', 196, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(981, '2013-04-07 10:58:36', 197, 'checkin', 530, 'absolute');
INSERT INTO `record` VALUES(982, '2013-04-07 10:58:36', 197, 'checkin-unique', 94, 'absolute');
INSERT INTO `record` VALUES(983, '2013-04-07 10:58:36', 197, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(984, '2013-04-07 10:58:36', 197, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(985, '2013-04-07 10:58:36', 197, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(986, '2013-04-07 10:58:37', 198, 'checkin', 120, 'absolute');
INSERT INTO `record` VALUES(987, '2013-04-07 10:58:37', 198, 'checkin-unique', 47, 'absolute');
INSERT INTO `record` VALUES(988, '2013-04-07 10:58:37', 198, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(989, '2013-04-07 10:58:37', 198, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(990, '2013-04-07 10:58:37', 198, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(991, '2013-04-07 10:58:37', 199, 'checkin', 3680, 'absolute');
INSERT INTO `record` VALUES(992, '2013-04-07 10:58:37', 199, 'checkin-unique', 1486, 'absolute');
INSERT INTO `record` VALUES(993, '2013-04-07 10:58:37', 199, 'review', 22, 'absolute');
INSERT INTO `record` VALUES(994, '2013-04-07 10:58:37', 199, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(995, '2013-04-07 10:58:37', 199, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(996, '2013-04-07 10:58:37', 200, 'checkin', 2807, 'absolute');
INSERT INTO `record` VALUES(997, '2013-04-07 10:58:37', 200, 'checkin-unique', 806, 'absolute');
INSERT INTO `record` VALUES(998, '2013-04-07 10:58:37', 200, 'review', 10, 'absolute');
INSERT INTO `record` VALUES(999, '2013-04-07 10:58:37', 200, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1000, '2013-04-07 10:58:37', 200, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1001, '2013-04-07 10:58:37', 201, 'checkin', 1517, 'absolute');
INSERT INTO `record` VALUES(1002, '2013-04-07 10:58:37', 201, 'checkin-unique', 580, 'absolute');
INSERT INTO `record` VALUES(1003, '2013-04-07 10:58:37', 201, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(1004, '2013-04-07 10:58:37', 201, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1005, '2013-04-07 10:58:37', 201, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1006, '2013-04-07 10:58:37', 202, 'checkin', 1902, 'absolute');
INSERT INTO `record` VALUES(1007, '2013-04-07 10:58:37', 202, 'checkin-unique', 653, 'absolute');
INSERT INTO `record` VALUES(1008, '2013-04-07 10:58:37', 202, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(1009, '2013-04-07 10:58:37', 202, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1010, '2013-04-07 10:58:37', 202, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1011, '2013-04-07 10:58:38', 203, 'checkin', 1641, 'absolute');
INSERT INTO `record` VALUES(1012, '2013-04-07 10:58:38', 203, 'checkin-unique', 647, 'absolute');
INSERT INTO `record` VALUES(1013, '2013-04-07 10:58:38', 203, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(1014, '2013-04-07 10:58:38', 203, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1015, '2013-04-07 10:58:38', 203, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1016, '2013-04-07 10:58:38', 204, 'checkin', 16, 'absolute');
INSERT INTO `record` VALUES(1017, '2013-04-07 10:58:38', 204, 'checkin-unique', 2, 'absolute');
INSERT INTO `record` VALUES(1018, '2013-04-07 10:58:38', 204, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1019, '2013-04-07 10:58:38', 204, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1020, '2013-04-07 10:58:38', 204, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1021, '2013-04-07 10:58:38', 205, 'checkin', 5, 'absolute');
INSERT INTO `record` VALUES(1022, '2013-04-07 10:58:38', 205, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(1023, '2013-04-07 10:58:38', 205, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1024, '2013-04-07 10:58:38', 205, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1025, '2013-04-07 10:58:38', 205, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1026, '2013-04-07 10:58:38', 206, 'checkin', 2410, 'absolute');
INSERT INTO `record` VALUES(1027, '2013-04-07 10:58:38', 206, 'checkin-unique', 560, 'absolute');
INSERT INTO `record` VALUES(1028, '2013-04-07 10:58:38', 206, 'review', 16, 'absolute');
INSERT INTO `record` VALUES(1029, '2013-04-07 10:58:38', 206, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1030, '2013-04-07 10:58:38', 206, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1031, '2013-04-07 10:58:38', 207, 'checkin', 4, 'absolute');
INSERT INTO `record` VALUES(1032, '2013-04-07 10:58:38', 207, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(1033, '2013-04-07 10:58:38', 207, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1034, '2013-04-07 10:58:38', 207, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1035, '2013-04-07 10:58:38', 207, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1036, '2013-04-07 10:58:38', 208, 'checkin', 45, 'absolute');
INSERT INTO `record` VALUES(1037, '2013-04-07 10:58:38', 208, 'checkin-unique', 36, 'absolute');
INSERT INTO `record` VALUES(1038, '2013-04-07 10:58:38', 208, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1039, '2013-04-07 10:58:38', 208, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1040, '2013-04-07 10:58:38', 208, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1041, '2013-04-07 10:58:38', 209, 'checkin', 149, 'absolute');
INSERT INTO `record` VALUES(1042, '2013-04-07 10:58:38', 209, 'checkin-unique', 67, 'absolute');
INSERT INTO `record` VALUES(1043, '2013-04-07 10:58:38', 209, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1044, '2013-04-07 10:58:38', 209, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1045, '2013-04-07 10:58:38', 209, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1046, '2013-04-07 10:58:39', 210, 'checkin', 3878, 'absolute');
INSERT INTO `record` VALUES(1047, '2013-04-07 10:58:39', 210, 'checkin-unique', 2079, 'absolute');
INSERT INTO `record` VALUES(1048, '2013-04-07 10:58:39', 210, 'review', 18, 'absolute');
INSERT INTO `record` VALUES(1049, '2013-04-07 10:58:39', 210, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1050, '2013-04-07 10:58:39', 210, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1051, '2013-04-07 10:58:40', 211, 'checkin', 3, 'absolute');
INSERT INTO `record` VALUES(1052, '2013-04-07 10:58:40', 211, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(1053, '2013-04-07 10:58:40', 211, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1054, '2013-04-07 10:58:40', 211, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1055, '2013-04-07 10:58:40', 211, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1056, '2013-04-07 10:58:40', 212, 'checkin', 16, 'absolute');
INSERT INTO `record` VALUES(1057, '2013-04-07 10:58:40', 212, 'checkin-unique', 2, 'absolute');
INSERT INTO `record` VALUES(1058, '2013-04-07 10:58:40', 212, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1059, '2013-04-07 10:58:40', 212, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1060, '2013-04-07 10:58:40', 212, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1061, '2013-04-07 10:58:41', 213, 'checkin', 1382, 'absolute');
INSERT INTO `record` VALUES(1062, '2013-04-07 10:58:41', 213, 'checkin-unique', 287, 'absolute');
INSERT INTO `record` VALUES(1063, '2013-04-07 10:58:41', 213, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(1064, '2013-04-07 10:58:41', 213, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1065, '2013-04-07 10:58:41', 213, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1066, '2013-04-07 10:58:41', 214, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(1067, '2013-04-07 10:58:41', 214, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1068, '2013-04-07 10:58:41', 214, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1069, '2013-04-07 10:58:41', 214, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1070, '2013-04-07 10:58:41', 214, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1071, '2013-04-07 10:58:42', 215, 'checkin', 1432, 'absolute');
INSERT INTO `record` VALUES(1072, '2013-04-07 10:58:42', 215, 'checkin-unique', 582, 'absolute');
INSERT INTO `record` VALUES(1073, '2013-04-07 10:58:42', 215, 'review', 8, 'absolute');
INSERT INTO `record` VALUES(1074, '2013-04-07 10:58:42', 215, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1075, '2013-04-07 10:58:42', 215, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1076, '2013-04-07 10:58:43', 216, 'checkin', 28890, 'absolute');
INSERT INTO `record` VALUES(1077, '2013-04-07 10:58:43', 216, 'checkin-unique', 8889, 'absolute');
INSERT INTO `record` VALUES(1078, '2013-04-07 10:58:43', 216, 'review', 110, 'absolute');
INSERT INTO `record` VALUES(1079, '2013-04-07 10:58:43', 216, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1080, '2013-04-07 10:58:43', 216, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1081, '2013-04-07 10:58:43', 217, 'checkin', 2531, 'absolute');
INSERT INTO `record` VALUES(1082, '2013-04-07 10:58:43', 217, 'checkin-unique', 1095, 'absolute');
INSERT INTO `record` VALUES(1083, '2013-04-07 10:58:43', 217, 'review', 8, 'absolute');
INSERT INTO `record` VALUES(1084, '2013-04-07 10:58:43', 217, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1085, '2013-04-07 10:58:43', 217, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1086, '2013-04-07 10:58:45', 218, 'checkin', 2607, 'absolute');
INSERT INTO `record` VALUES(1087, '2013-04-07 10:58:45', 218, 'checkin-unique', 1583, 'absolute');
INSERT INTO `record` VALUES(1088, '2013-04-07 10:58:45', 218, 'review', 50, 'absolute');
INSERT INTO `record` VALUES(1089, '2013-04-07 10:58:45', 218, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1090, '2013-04-07 10:58:45', 218, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1091, '2013-04-07 10:58:45', 219, 'checkin', 23, 'absolute');
INSERT INTO `record` VALUES(1092, '2013-04-07 10:58:45', 219, 'checkin-unique', 20, 'absolute');
INSERT INTO `record` VALUES(1093, '2013-04-07 10:58:45', 219, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1094, '2013-04-07 10:58:45', 219, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1095, '2013-04-07 10:58:45', 219, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1096, '2013-04-07 10:58:46', 220, 'checkin', 4, 'absolute');
INSERT INTO `record` VALUES(1097, '2013-04-07 10:58:46', 220, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(1098, '2013-04-07 10:58:46', 220, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1099, '2013-04-07 10:58:46', 220, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1100, '2013-04-07 10:58:46', 220, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1101, '2013-04-07 10:58:46', 221, 'checkin', 41, 'absolute');
INSERT INTO `record` VALUES(1102, '2013-04-07 10:58:47', 221, 'checkin-unique', 35, 'absolute');
INSERT INTO `record` VALUES(1103, '2013-04-07 10:58:47', 221, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1104, '2013-04-07 10:58:47', 221, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1105, '2013-04-07 10:58:47', 221, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1106, '2013-04-07 10:58:48', 222, 'checkin', 2540, 'absolute');
INSERT INTO `record` VALUES(1107, '2013-04-07 10:58:48', 222, 'checkin-unique', 723, 'absolute');
INSERT INTO `record` VALUES(1108, '2013-04-07 10:58:48', 222, 'review', 17, 'absolute');
INSERT INTO `record` VALUES(1109, '2013-04-07 10:58:48', 222, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1110, '2013-04-07 10:58:48', 222, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1111, '2013-04-07 10:58:49', 223, 'checkin', 2662, 'absolute');
INSERT INTO `record` VALUES(1112, '2013-04-07 10:58:49', 223, 'checkin-unique', 537, 'absolute');
INSERT INTO `record` VALUES(1113, '2013-04-07 10:58:49', 223, 'review', 12, 'absolute');
INSERT INTO `record` VALUES(1114, '2013-04-07 10:58:49', 223, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1115, '2013-04-07 10:58:49', 223, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1116, '2013-04-07 10:58:50', 224, 'checkin', 2627, 'absolute');
INSERT INTO `record` VALUES(1117, '2013-04-07 10:58:50', 224, 'checkin-unique', 941, 'absolute');
INSERT INTO `record` VALUES(1118, '2013-04-07 10:58:50', 224, 'review', 16, 'absolute');
INSERT INTO `record` VALUES(1119, '2013-04-07 10:58:50', 224, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1120, '2013-04-07 10:58:50', 224, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1121, '2013-04-07 10:58:51', 225, 'checkin', 808, 'absolute');
INSERT INTO `record` VALUES(1122, '2013-04-07 10:58:51', 225, 'checkin-unique', 223, 'absolute');
INSERT INTO `record` VALUES(1123, '2013-04-07 10:58:51', 225, 'review', 11, 'absolute');
INSERT INTO `record` VALUES(1124, '2013-04-07 10:58:51', 225, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1125, '2013-04-07 10:58:52', 225, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1126, '2013-04-07 10:58:53', 226, 'checkin', 10, 'absolute');
INSERT INTO `record` VALUES(1127, '2013-04-07 10:58:53', 226, 'checkin-unique', 10, 'absolute');
INSERT INTO `record` VALUES(1128, '2013-04-07 10:58:53', 226, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1129, '2013-04-07 10:58:53', 226, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1130, '2013-04-07 10:58:53', 226, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1131, '2013-04-07 10:58:55', 227, 'checkin', 16, 'absolute');
INSERT INTO `record` VALUES(1132, '2013-04-07 10:58:55', 227, 'checkin-unique', 14, 'absolute');
INSERT INTO `record` VALUES(1133, '2013-04-07 10:58:55', 227, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1134, '2013-04-07 10:58:55', 227, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1135, '2013-04-07 10:58:55', 227, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1136, '2013-04-07 10:58:56', 228, 'checkin', 11, 'absolute');
INSERT INTO `record` VALUES(1137, '2013-04-07 10:58:56', 228, 'checkin-unique', 10, 'absolute');
INSERT INTO `record` VALUES(1138, '2013-04-07 10:58:56', 228, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1139, '2013-04-07 10:58:56', 228, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1140, '2013-04-07 10:58:56', 228, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1141, '2013-04-07 10:58:56', 229, 'checkin', 279, 'absolute');
INSERT INTO `record` VALUES(1142, '2013-04-07 10:58:57', 229, 'checkin-unique', 264, 'absolute');
INSERT INTO `record` VALUES(1143, '2013-04-07 10:58:57', 229, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1144, '2013-04-07 10:58:57', 229, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1145, '2013-04-07 10:58:57', 229, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1146, '2013-04-07 10:58:58', 230, 'checkin', 3543, 'absolute');
INSERT INTO `record` VALUES(1147, '2013-04-07 10:58:58', 230, 'checkin-unique', 1048, 'absolute');
INSERT INTO `record` VALUES(1148, '2013-04-07 10:58:58', 230, 'review', 23, 'absolute');
INSERT INTO `record` VALUES(1149, '2013-04-07 10:58:58', 230, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1150, '2013-04-07 10:58:58', 230, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1151, '2013-04-07 10:58:58', 231, 'checkin', 44966, 'absolute');
INSERT INTO `record` VALUES(1152, '2013-04-07 10:58:58', 231, 'checkin-unique', 13004, 'absolute');
INSERT INTO `record` VALUES(1153, '2013-04-07 10:58:58', 231, 'review', 176, 'absolute');
INSERT INTO `record` VALUES(1154, '2013-04-07 10:58:58', 231, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1155, '2013-04-07 10:58:58', 231, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1156, '2013-04-07 10:58:59', 232, 'checkin', 433, 'absolute');
INSERT INTO `record` VALUES(1157, '2013-04-07 10:58:59', 232, 'checkin-unique', 232, 'absolute');
INSERT INTO `record` VALUES(1158, '2013-04-07 10:58:59', 232, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(1159, '2013-04-07 10:58:59', 232, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1160, '2013-04-07 10:58:59', 232, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1161, '2013-04-07 10:58:59', 233, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(1162, '2013-04-07 10:58:59', 233, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1163, '2013-04-07 10:58:59', 233, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1164, '2013-04-07 10:58:59', 233, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1165, '2013-04-07 10:58:59', 233, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1166, '2013-04-07 10:59:00', 234, 'checkin', 1785, 'absolute');
INSERT INTO `record` VALUES(1167, '2013-04-07 10:59:00', 234, 'checkin-unique', 329, 'absolute');
INSERT INTO `record` VALUES(1168, '2013-04-07 10:59:00', 234, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(1169, '2013-04-07 10:59:00', 234, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1170, '2013-04-07 10:59:00', 234, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1171, '2013-04-07 10:59:00', 235, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(1172, '2013-04-07 10:59:00', 235, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1173, '2013-04-07 10:59:00', 235, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1174, '2013-04-07 10:59:00', 235, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1175, '2013-04-07 10:59:00', 235, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1176, '2013-04-07 10:59:00', 236, 'checkin', 9, 'absolute');
INSERT INTO `record` VALUES(1177, '2013-04-07 10:59:00', 236, 'checkin-unique', 5, 'absolute');
INSERT INTO `record` VALUES(1178, '2013-04-07 10:59:00', 236, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1179, '2013-04-07 10:59:00', 236, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1180, '2013-04-07 10:59:00', 236, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1181, '2013-04-07 10:59:00', 237, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(1182, '2013-04-07 10:59:00', 237, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1183, '2013-04-07 10:59:00', 237, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1184, '2013-04-07 10:59:00', 237, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1185, '2013-04-07 10:59:00', 237, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1186, '2013-04-07 10:59:01', 238, 'checkin', 10288, 'absolute');
INSERT INTO `record` VALUES(1187, '2013-04-07 10:59:01', 238, 'checkin-unique', 2633, 'absolute');
INSERT INTO `record` VALUES(1188, '2013-04-07 10:59:01', 238, 'review', 64, 'absolute');
INSERT INTO `record` VALUES(1189, '2013-04-07 10:59:01', 238, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1190, '2013-04-07 10:59:01', 238, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1191, '2013-04-07 10:59:01', 239, 'checkin', 1157, 'absolute');
INSERT INTO `record` VALUES(1192, '2013-04-07 10:59:01', 239, 'checkin-unique', 341, 'absolute');
INSERT INTO `record` VALUES(1193, '2013-04-07 10:59:01', 239, 'review', 14, 'absolute');
INSERT INTO `record` VALUES(1194, '2013-04-07 10:59:01', 239, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1195, '2013-04-07 10:59:01', 239, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1196, '2013-04-07 10:59:01', 240, 'checkin', 410, 'absolute');
INSERT INTO `record` VALUES(1197, '2013-04-07 10:59:01', 240, 'checkin-unique', 151, 'absolute');
INSERT INTO `record` VALUES(1198, '2013-04-07 10:59:01', 240, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1199, '2013-04-07 10:59:01', 240, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1200, '2013-04-07 10:59:01', 240, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1201, '2013-04-07 10:59:02', 241, 'checkin', 369, 'absolute');
INSERT INTO `record` VALUES(1202, '2013-04-07 10:59:02', 241, 'checkin-unique', 62, 'absolute');
INSERT INTO `record` VALUES(1203, '2013-04-07 10:59:02', 241, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1204, '2013-04-07 10:59:02', 241, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1205, '2013-04-07 10:59:02', 241, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1206, '2013-04-07 10:59:02', 242, 'checkin', 416, 'absolute');
INSERT INTO `record` VALUES(1207, '2013-04-07 10:59:02', 242, 'checkin-unique', 158, 'absolute');
INSERT INTO `record` VALUES(1208, '2013-04-07 10:59:02', 242, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1209, '2013-04-07 10:59:02', 242, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1210, '2013-04-07 10:59:02', 242, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1211, '2013-04-07 10:59:02', 243, 'checkin', 3, 'absolute');
INSERT INTO `record` VALUES(1212, '2013-04-07 10:59:02', 243, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(1213, '2013-04-07 10:59:02', 243, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1214, '2013-04-07 10:59:02', 243, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1215, '2013-04-07 10:59:02', 243, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1216, '2013-04-07 10:59:02', 244, 'checkin', 31, 'absolute');
INSERT INTO `record` VALUES(1217, '2013-04-07 10:59:02', 244, 'checkin-unique', 2, 'absolute');
INSERT INTO `record` VALUES(1218, '2013-04-07 10:59:02', 244, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1219, '2013-04-07 10:59:02', 244, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1220, '2013-04-07 10:59:02', 244, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1221, '2013-04-07 10:59:02', 245, 'checkin', 24, 'absolute');
INSERT INTO `record` VALUES(1222, '2013-04-07 10:59:02', 245, 'checkin-unique', 20, 'absolute');
INSERT INTO `record` VALUES(1223, '2013-04-07 10:59:02', 245, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1224, '2013-04-07 10:59:02', 245, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1225, '2013-04-07 10:59:02', 245, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1226, '2013-04-07 10:59:02', 246, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(1227, '2013-04-07 10:59:02', 246, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1228, '2013-04-07 10:59:02', 246, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1229, '2013-04-07 10:59:02', 246, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1230, '2013-04-07 10:59:02', 246, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1231, '2013-04-07 10:59:02', 247, 'checkin', 2, 'absolute');
INSERT INTO `record` VALUES(1232, '2013-04-07 10:59:02', 247, 'checkin-unique', 2, 'absolute');
INSERT INTO `record` VALUES(1233, '2013-04-07 10:59:02', 247, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1234, '2013-04-07 10:59:02', 247, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1235, '2013-04-07 10:59:02', 247, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1236, '2013-04-07 10:59:02', 248, 'checkin', 2, 'absolute');
INSERT INTO `record` VALUES(1237, '2013-04-07 10:59:02', 248, 'checkin-unique', 2, 'absolute');
INSERT INTO `record` VALUES(1238, '2013-04-07 10:59:02', 248, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1239, '2013-04-07 10:59:02', 248, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1240, '2013-04-07 10:59:02', 248, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1241, '2013-04-07 10:59:03', 249, 'checkin', 2403, 'absolute');
INSERT INTO `record` VALUES(1242, '2013-04-07 10:59:03', 249, 'checkin-unique', 719, 'absolute');
INSERT INTO `record` VALUES(1243, '2013-04-07 10:59:03', 249, 'review', 13, 'absolute');
INSERT INTO `record` VALUES(1244, '2013-04-07 10:59:03', 249, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1245, '2013-04-07 10:59:03', 249, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1246, '2013-04-07 10:59:03', 250, 'checkin', 3424, 'absolute');
INSERT INTO `record` VALUES(1247, '2013-04-07 10:59:03', 250, 'checkin-unique', 856, 'absolute');
INSERT INTO `record` VALUES(1248, '2013-04-07 10:59:03', 250, 'review', 19, 'absolute');
INSERT INTO `record` VALUES(1249, '2013-04-07 10:59:03', 250, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1250, '2013-04-07 10:59:03', 250, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1251, '2013-04-07 10:59:03', 251, 'checkin', 408, 'absolute');
INSERT INTO `record` VALUES(1252, '2013-04-07 10:59:03', 251, 'checkin-unique', 166, 'absolute');
INSERT INTO `record` VALUES(1253, '2013-04-07 10:59:03', 251, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(1254, '2013-04-07 10:59:03', 251, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1255, '2013-04-07 10:59:03', 251, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1256, '2013-04-07 10:59:03', 252, 'checkin', 4264, 'absolute');
INSERT INTO `record` VALUES(1257, '2013-04-07 10:59:03', 252, 'checkin-unique', 1226, 'absolute');
INSERT INTO `record` VALUES(1258, '2013-04-07 10:59:03', 252, 'review', 13, 'absolute');
INSERT INTO `record` VALUES(1259, '2013-04-07 10:59:03', 252, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1260, '2013-04-07 10:59:03', 252, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1261, '2013-04-07 10:59:04', 253, 'checkin', 2543, 'absolute');
INSERT INTO `record` VALUES(1262, '2013-04-07 10:59:04', 253, 'checkin-unique', 1078, 'absolute');
INSERT INTO `record` VALUES(1263, '2013-04-07 10:59:04', 253, 'review', 50, 'absolute');
INSERT INTO `record` VALUES(1264, '2013-04-07 10:59:04', 253, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1265, '2013-04-07 10:59:04', 253, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1266, '2013-04-07 10:59:04', 254, 'checkin', 244, 'absolute');
INSERT INTO `record` VALUES(1267, '2013-04-07 10:59:04', 254, 'checkin-unique', 105, 'absolute');
INSERT INTO `record` VALUES(1268, '2013-04-07 10:59:04', 254, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1269, '2013-04-07 10:59:04', 254, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1270, '2013-04-07 10:59:04', 254, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1271, '2013-04-07 10:59:04', 255, 'checkin', 195, 'absolute');
INSERT INTO `record` VALUES(1272, '2013-04-07 10:59:04', 255, 'checkin-unique', 124, 'absolute');
INSERT INTO `record` VALUES(1273, '2013-04-07 10:59:04', 255, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1274, '2013-04-07 10:59:04', 255, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1275, '2013-04-07 10:59:04', 255, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1276, '2013-04-07 10:59:04', 256, 'checkin', 29, 'absolute');
INSERT INTO `record` VALUES(1277, '2013-04-07 10:59:04', 256, 'checkin-unique', 20, 'absolute');
INSERT INTO `record` VALUES(1278, '2013-04-07 10:59:04', 256, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1279, '2013-04-07 10:59:04', 256, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1280, '2013-04-07 10:59:04', 256, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1281, '2013-04-07 10:59:04', 257, 'checkin', 40568, 'absolute');
INSERT INTO `record` VALUES(1282, '2013-04-07 10:59:04', 257, 'checkin-unique', 13741, 'absolute');
INSERT INTO `record` VALUES(1283, '2013-04-07 10:59:04', 257, 'review', 185, 'absolute');
INSERT INTO `record` VALUES(1284, '2013-04-07 10:59:04', 257, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1285, '2013-04-07 10:59:04', 257, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1286, '2013-04-07 10:59:04', 258, 'checkin', 15841, 'absolute');
INSERT INTO `record` VALUES(1287, '2013-04-07 10:59:04', 258, 'checkin-unique', 7061, 'absolute');
INSERT INTO `record` VALUES(1288, '2013-04-07 10:59:04', 258, 'review', 61, 'absolute');
INSERT INTO `record` VALUES(1289, '2013-04-07 10:59:04', 258, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1290, '2013-04-07 10:59:04', 258, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1291, '2013-04-07 10:59:04', 259, 'checkin', 4950, 'absolute');
INSERT INTO `record` VALUES(1292, '2013-04-07 10:59:04', 259, 'checkin-unique', 2088, 'absolute');
INSERT INTO `record` VALUES(1293, '2013-04-07 10:59:04', 259, 'review', 28, 'absolute');
INSERT INTO `record` VALUES(1294, '2013-04-07 10:59:04', 259, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1295, '2013-04-07 10:59:04', 259, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1296, '2013-04-07 10:59:04', 260, 'checkin', 2, 'absolute');
INSERT INTO `record` VALUES(1297, '2013-04-07 10:59:04', 260, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1298, '2013-04-07 10:59:04', 260, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1299, '2013-04-07 10:59:04', 260, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1300, '2013-04-07 10:59:04', 260, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1301, '2013-04-07 10:59:04', 261, 'checkin', 66, 'absolute');
INSERT INTO `record` VALUES(1302, '2013-04-07 10:59:04', 261, 'checkin-unique', 41, 'absolute');
INSERT INTO `record` VALUES(1303, '2013-04-07 10:59:04', 261, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1304, '2013-04-07 10:59:04', 261, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1305, '2013-04-07 10:59:04', 261, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1306, '2013-04-07 10:59:04', 262, 'checkin', 16, 'absolute');
INSERT INTO `record` VALUES(1307, '2013-04-07 10:59:04', 262, 'checkin-unique', 16, 'absolute');
INSERT INTO `record` VALUES(1308, '2013-04-07 10:59:04', 262, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1309, '2013-04-07 10:59:04', 262, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1310, '2013-04-07 10:59:04', 262, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1311, '2013-04-07 10:59:05', 263, 'checkin', 62225, 'absolute');
INSERT INTO `record` VALUES(1312, '2013-04-07 10:59:05', 263, 'checkin-unique', 23298, 'absolute');
INSERT INTO `record` VALUES(1313, '2013-04-07 10:59:05', 263, 'review', 254, 'absolute');
INSERT INTO `record` VALUES(1314, '2013-04-07 10:59:05', 263, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1315, '2013-04-07 10:59:05', 263, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1316, '2013-04-07 10:59:05', 264, 'checkin', 6175, 'absolute');
INSERT INTO `record` VALUES(1317, '2013-04-07 10:59:05', 264, 'checkin-unique', 2387, 'absolute');
INSERT INTO `record` VALUES(1318, '2013-04-07 10:59:05', 264, 'review', 22, 'absolute');
INSERT INTO `record` VALUES(1319, '2013-04-07 10:59:05', 264, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1320, '2013-04-07 10:59:05', 264, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1321, '2013-04-07 10:59:05', 265, 'checkin', 64539, 'absolute');
INSERT INTO `record` VALUES(1322, '2013-04-07 10:59:05', 265, 'checkin-unique', 27235, 'absolute');
INSERT INTO `record` VALUES(1323, '2013-04-07 10:59:05', 265, 'review', 269, 'absolute');
INSERT INTO `record` VALUES(1324, '2013-04-07 10:59:05', 265, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1325, '2013-04-07 10:59:05', 265, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1326, '2013-04-07 10:59:05', 266, 'checkin', 468, 'absolute');
INSERT INTO `record` VALUES(1327, '2013-04-07 10:59:05', 266, 'checkin-unique', 182, 'absolute');
INSERT INTO `record` VALUES(1328, '2013-04-07 10:59:05', 266, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1329, '2013-04-07 10:59:05', 266, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1330, '2013-04-07 10:59:05', 266, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1331, '2013-04-07 10:59:05', 267, 'checkin', 94, 'absolute');
INSERT INTO `record` VALUES(1332, '2013-04-07 10:59:05', 267, 'checkin-unique', 19, 'absolute');
INSERT INTO `record` VALUES(1333, '2013-04-07 10:59:05', 267, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1334, '2013-04-07 10:59:05', 267, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1335, '2013-04-07 10:59:05', 267, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1336, '2013-04-07 10:59:05', 268, 'checkin', 113, 'absolute');
INSERT INTO `record` VALUES(1337, '2013-04-07 10:59:05', 268, 'checkin-unique', 22, 'absolute');
INSERT INTO `record` VALUES(1338, '2013-04-07 10:59:05', 268, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(1339, '2013-04-07 10:59:05', 268, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1340, '2013-04-07 10:59:05', 268, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1341, '2013-04-07 10:59:05', 269, 'checkin', 63, 'absolute');
INSERT INTO `record` VALUES(1342, '2013-04-07 10:59:05', 269, 'checkin-unique', 21, 'absolute');
INSERT INTO `record` VALUES(1343, '2013-04-07 10:59:05', 269, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1344, '2013-04-07 10:59:05', 269, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1345, '2013-04-07 10:59:05', 269, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1346, '2013-04-07 10:59:05', 270, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(1347, '2013-04-07 10:59:05', 270, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1348, '2013-04-07 10:59:05', 270, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1349, '2013-04-07 10:59:05', 270, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1350, '2013-04-07 10:59:05', 270, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1351, '2013-04-07 10:59:05', 271, 'checkin', 2, 'absolute');
INSERT INTO `record` VALUES(1352, '2013-04-07 10:59:05', 271, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1353, '2013-04-07 10:59:05', 271, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1354, '2013-04-07 10:59:05', 271, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1355, '2013-04-07 10:59:05', 271, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1356, '2013-04-07 10:59:05', 272, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(1357, '2013-04-07 10:59:05', 272, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1358, '2013-04-07 10:59:05', 272, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1359, '2013-04-07 10:59:05', 272, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1360, '2013-04-07 10:59:05', 272, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1361, '2013-04-07 10:59:05', 273, 'checkin', 17, 'absolute');
INSERT INTO `record` VALUES(1362, '2013-04-07 10:59:05', 273, 'checkin-unique', 16, 'absolute');
INSERT INTO `record` VALUES(1363, '2013-04-07 10:59:05', 273, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1364, '2013-04-07 10:59:05', 273, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1365, '2013-04-07 10:59:05', 273, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1366, '2013-04-07 10:59:05', 274, 'checkin', 47, 'absolute');
INSERT INTO `record` VALUES(1367, '2013-04-07 10:59:05', 274, 'checkin-unique', 44, 'absolute');
INSERT INTO `record` VALUES(1368, '2013-04-07 10:59:05', 274, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1369, '2013-04-07 10:59:05', 274, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1370, '2013-04-07 10:59:05', 274, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1371, '2013-04-07 10:59:05', 275, 'checkin', 9, 'absolute');
INSERT INTO `record` VALUES(1372, '2013-04-07 10:59:05', 275, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(1373, '2013-04-07 10:59:05', 275, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1374, '2013-04-07 10:59:05', 275, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1375, '2013-04-07 10:59:05', 275, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1376, '2013-04-07 10:59:05', 276, 'checkin', 14, 'absolute');
INSERT INTO `record` VALUES(1377, '2013-04-07 10:59:05', 276, 'checkin-unique', 5, 'absolute');
INSERT INTO `record` VALUES(1378, '2013-04-07 10:59:05', 276, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1379, '2013-04-07 10:59:05', 276, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1380, '2013-04-07 10:59:05', 276, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1381, '2013-04-07 10:59:05', 277, 'checkin', 0, 'absolute');
INSERT INTO `record` VALUES(1382, '2013-04-07 10:59:05', 277, 'checkin-unique', 0, 'absolute');
INSERT INTO `record` VALUES(1383, '2013-04-07 10:59:05', 277, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1384, '2013-04-07 10:59:05', 277, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1385, '2013-04-07 10:59:05', 277, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1386, '2013-04-07 10:59:05', 278, 'checkin', 3412, 'absolute');
INSERT INTO `record` VALUES(1387, '2013-04-07 10:59:05', 278, 'checkin-unique', 2394, 'absolute');
INSERT INTO `record` VALUES(1388, '2013-04-07 10:59:05', 278, 'review', 55, 'absolute');
INSERT INTO `record` VALUES(1389, '2013-04-07 10:59:05', 278, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1390, '2013-04-07 10:59:05', 278, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1391, '2013-04-07 10:59:05', 279, 'checkin', 218, 'absolute');
INSERT INTO `record` VALUES(1392, '2013-04-07 10:59:05', 279, 'checkin-unique', 70, 'absolute');
INSERT INTO `record` VALUES(1393, '2013-04-07 10:59:05', 279, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1394, '2013-04-07 10:59:05', 279, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1395, '2013-04-07 10:59:05', 279, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1396, '2013-04-07 10:59:06', 280, 'checkin', 964, 'absolute');
INSERT INTO `record` VALUES(1397, '2013-04-07 10:59:06', 280, 'checkin-unique', 333, 'absolute');
INSERT INTO `record` VALUES(1398, '2013-04-07 10:59:06', 280, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(1399, '2013-04-07 10:59:06', 280, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1400, '2013-04-07 10:59:06', 280, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1401, '2013-04-07 10:59:06', 281, 'checkin', 791, 'absolute');
INSERT INTO `record` VALUES(1402, '2013-04-07 10:59:06', 281, 'checkin-unique', 276, 'absolute');
INSERT INTO `record` VALUES(1403, '2013-04-07 10:59:06', 281, 'review', 11, 'absolute');
INSERT INTO `record` VALUES(1404, '2013-04-07 10:59:06', 281, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1405, '2013-04-07 10:59:06', 281, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1406, '2013-04-07 10:59:08', 282, 'checkin', 81155, 'absolute');
INSERT INTO `record` VALUES(1407, '2013-04-07 10:59:08', 282, 'checkin-unique', 40575, 'absolute');
INSERT INTO `record` VALUES(1408, '2013-04-07 10:59:08', 282, 'review', 323, 'absolute');
INSERT INTO `record` VALUES(1409, '2013-04-07 10:59:08', 282, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1410, '2013-04-07 10:59:08', 282, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1411, '2013-04-07 10:59:08', 283, 'checkin', 1402, 'absolute');
INSERT INTO `record` VALUES(1412, '2013-04-07 10:59:08', 283, 'checkin-unique', 284, 'absolute');
INSERT INTO `record` VALUES(1413, '2013-04-07 10:59:08', 283, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1414, '2013-04-07 10:59:08', 283, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1415, '2013-04-07 10:59:08', 283, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1416, '2013-04-07 10:59:08', 284, 'checkin', 281, 'absolute');
INSERT INTO `record` VALUES(1417, '2013-04-07 10:59:08', 284, 'checkin-unique', 125, 'absolute');
INSERT INTO `record` VALUES(1418, '2013-04-07 10:59:08', 284, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(1419, '2013-04-07 10:59:08', 284, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1420, '2013-04-07 10:59:08', 284, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1421, '2013-04-07 10:59:08', 285, 'checkin', 13, 'absolute');
INSERT INTO `record` VALUES(1422, '2013-04-07 10:59:08', 285, 'checkin-unique', 12, 'absolute');
INSERT INTO `record` VALUES(1423, '2013-04-07 10:59:08', 285, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1424, '2013-04-07 10:59:08', 285, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1425, '2013-04-07 10:59:08', 285, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1426, '2013-04-07 10:59:08', 286, 'checkin', 1120, 'absolute');
INSERT INTO `record` VALUES(1427, '2013-04-07 10:59:08', 286, 'checkin-unique', 712, 'absolute');
INSERT INTO `record` VALUES(1428, '2013-04-07 10:59:08', 286, 'review', 19, 'absolute');
INSERT INTO `record` VALUES(1429, '2013-04-07 10:59:08', 286, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1430, '2013-04-07 10:59:08', 286, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1431, '2013-04-07 10:59:08', 287, 'checkin', 2869, 'absolute');
INSERT INTO `record` VALUES(1432, '2013-04-07 10:59:08', 287, 'checkin-unique', 837, 'absolute');
INSERT INTO `record` VALUES(1433, '2013-04-07 10:59:08', 287, 'review', 20, 'absolute');
INSERT INTO `record` VALUES(1434, '2013-04-07 10:59:08', 287, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1435, '2013-04-07 10:59:08', 287, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1436, '2013-04-07 10:59:08', 288, 'checkin', 313, 'absolute');
INSERT INTO `record` VALUES(1437, '2013-04-07 10:59:08', 288, 'checkin-unique', 218, 'absolute');
INSERT INTO `record` VALUES(1438, '2013-04-07 10:59:08', 288, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1439, '2013-04-07 10:59:08', 288, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1440, '2013-04-07 10:59:08', 288, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1441, '2013-04-07 10:59:08', 289, 'checkin', 995, 'absolute');
INSERT INTO `record` VALUES(1442, '2013-04-07 10:59:08', 289, 'checkin-unique', 382, 'absolute');
INSERT INTO `record` VALUES(1443, '2013-04-07 10:59:08', 289, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(1444, '2013-04-07 10:59:08', 289, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1445, '2013-04-07 10:59:08', 289, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1446, '2013-04-07 10:59:08', 290, 'checkin', 1680, 'absolute');
INSERT INTO `record` VALUES(1447, '2013-04-07 10:59:08', 290, 'checkin-unique', 403, 'absolute');
INSERT INTO `record` VALUES(1448, '2013-04-07 10:59:08', 290, 'review', 9, 'absolute');
INSERT INTO `record` VALUES(1449, '2013-04-07 10:59:08', 290, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1450, '2013-04-07 10:59:08', 290, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1451, '2013-04-07 10:59:08', 291, 'checkin', 1093, 'absolute');
INSERT INTO `record` VALUES(1452, '2013-04-07 10:59:08', 291, 'checkin-unique', 420, 'absolute');
INSERT INTO `record` VALUES(1453, '2013-04-07 10:59:08', 291, 'review', 17, 'absolute');
INSERT INTO `record` VALUES(1454, '2013-04-07 10:59:08', 291, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1455, '2013-04-07 10:59:08', 291, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1456, '2013-04-07 10:59:09', 292, 'checkin', 1214, 'absolute');
INSERT INTO `record` VALUES(1457, '2013-04-07 10:59:09', 292, 'checkin-unique', 532, 'absolute');
INSERT INTO `record` VALUES(1458, '2013-04-07 10:59:09', 292, 'review', 12, 'absolute');
INSERT INTO `record` VALUES(1459, '2013-04-07 10:59:09', 292, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1460, '2013-04-07 10:59:09', 292, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1461, '2013-04-07 10:59:09', 293, 'checkin', 2652, 'absolute');
INSERT INTO `record` VALUES(1462, '2013-04-07 10:59:09', 293, 'checkin-unique', 1056, 'absolute');
INSERT INTO `record` VALUES(1463, '2013-04-07 10:59:09', 293, 'review', 19, 'absolute');
INSERT INTO `record` VALUES(1464, '2013-04-07 10:59:09', 293, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1465, '2013-04-07 10:59:09', 293, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1466, '2013-04-07 10:59:09', 294, 'checkin', 2727, 'absolute');
INSERT INTO `record` VALUES(1467, '2013-04-07 10:59:09', 294, 'checkin-unique', 902, 'absolute');
INSERT INTO `record` VALUES(1468, '2013-04-07 10:59:09', 294, 'review', 40, 'absolute');
INSERT INTO `record` VALUES(1469, '2013-04-07 10:59:09', 294, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1470, '2013-04-07 10:59:09', 294, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1471, '2013-04-07 10:59:09', 295, 'checkin', 189, 'absolute');
INSERT INTO `record` VALUES(1472, '2013-04-07 10:59:09', 295, 'checkin-unique', 89, 'absolute');
INSERT INTO `record` VALUES(1473, '2013-04-07 10:59:09', 295, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1474, '2013-04-07 10:59:09', 295, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1475, '2013-04-07 10:59:09', 295, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1476, '2013-04-07 10:59:09', 296, 'checkin', 865, 'absolute');
INSERT INTO `record` VALUES(1477, '2013-04-07 10:59:09', 296, 'checkin-unique', 580, 'absolute');
INSERT INTO `record` VALUES(1478, '2013-04-07 10:59:09', 296, 'review', 12, 'absolute');
INSERT INTO `record` VALUES(1479, '2013-04-07 10:59:09', 296, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1480, '2013-04-07 10:59:09', 296, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1481, '2013-04-07 10:59:10', 297, 'checkin', 133, 'absolute');
INSERT INTO `record` VALUES(1482, '2013-04-07 10:59:10', 297, 'checkin-unique', 66, 'absolute');
INSERT INTO `record` VALUES(1483, '2013-04-07 10:59:10', 297, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1484, '2013-04-07 10:59:10', 297, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1485, '2013-04-07 10:59:10', 297, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1486, '2013-04-07 10:59:10', 298, 'checkin', 3884, 'absolute');
INSERT INTO `record` VALUES(1487, '2013-04-07 10:59:10', 298, 'checkin-unique', 1549, 'absolute');
INSERT INTO `record` VALUES(1488, '2013-04-07 10:59:10', 298, 'review', 27, 'absolute');
INSERT INTO `record` VALUES(1489, '2013-04-07 10:59:10', 298, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1490, '2013-04-07 10:59:10', 298, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1491, '2013-04-07 10:59:10', 299, 'checkin', 17, 'absolute');
INSERT INTO `record` VALUES(1492, '2013-04-07 10:59:10', 299, 'checkin-unique', 8, 'absolute');
INSERT INTO `record` VALUES(1493, '2013-04-07 10:59:10', 299, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1494, '2013-04-07 10:59:10', 299, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1495, '2013-04-07 10:59:10', 299, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1496, '2013-04-07 10:59:10', 300, 'checkin', 0, 'absolute');
INSERT INTO `record` VALUES(1497, '2013-04-07 10:59:10', 300, 'checkin-unique', 0, 'absolute');
INSERT INTO `record` VALUES(1498, '2013-04-07 10:59:10', 300, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1499, '2013-04-07 10:59:10', 300, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1500, '2013-04-07 10:59:10', 300, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1501, '2013-04-07 10:59:10', 301, 'checkin', 0, 'absolute');
INSERT INTO `record` VALUES(1502, '2013-04-07 10:59:10', 301, 'checkin-unique', 0, 'absolute');
INSERT INTO `record` VALUES(1503, '2013-04-07 10:59:10', 301, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1504, '2013-04-07 10:59:10', 301, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1505, '2013-04-07 10:59:10', 301, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1506, '2013-04-07 10:59:10', 302, 'checkin', 0, 'absolute');
INSERT INTO `record` VALUES(1507, '2013-04-07 10:59:10', 302, 'checkin-unique', 0, 'absolute');
INSERT INTO `record` VALUES(1508, '2013-04-07 10:59:10', 302, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1509, '2013-04-07 10:59:10', 302, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1510, '2013-04-07 10:59:10', 302, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1511, '2013-04-07 10:59:10', 303, 'checkin', 672, 'absolute');
INSERT INTO `record` VALUES(1512, '2013-04-07 10:59:10', 303, 'checkin-unique', 120, 'absolute');
INSERT INTO `record` VALUES(1513, '2013-04-07 10:59:10', 303, 'review', 8, 'absolute');
INSERT INTO `record` VALUES(1514, '2013-04-07 10:59:10', 303, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1515, '2013-04-07 10:59:10', 303, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1516, '2013-04-07 10:59:10', 304, 'checkin', 1459, 'absolute');
INSERT INTO `record` VALUES(1517, '2013-04-07 10:59:10', 304, 'checkin-unique', 342, 'absolute');
INSERT INTO `record` VALUES(1518, '2013-04-07 10:59:10', 304, 'review', 10, 'absolute');
INSERT INTO `record` VALUES(1519, '2013-04-07 10:59:10', 304, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1520, '2013-04-07 10:59:10', 304, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1521, '2013-04-07 10:59:10', 305, 'checkin', 146, 'absolute');
INSERT INTO `record` VALUES(1522, '2013-04-07 10:59:10', 305, 'checkin-unique', 67, 'absolute');
INSERT INTO `record` VALUES(1523, '2013-04-07 10:59:10', 305, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(1524, '2013-04-07 10:59:10', 305, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1525, '2013-04-07 10:59:10', 305, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1526, '2013-04-07 10:59:11', 306, 'checkin', 610, 'absolute');
INSERT INTO `record` VALUES(1527, '2013-04-07 10:59:11', 306, 'checkin-unique', 355, 'absolute');
INSERT INTO `record` VALUES(1528, '2013-04-07 10:59:11', 306, 'review', 15, 'absolute');
INSERT INTO `record` VALUES(1529, '2013-04-07 10:59:11', 306, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1530, '2013-04-07 10:59:11', 306, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1531, '2013-04-07 10:59:11', 307, 'checkin', 1034, 'absolute');
INSERT INTO `record` VALUES(1532, '2013-04-07 10:59:11', 307, 'checkin-unique', 294, 'absolute');
INSERT INTO `record` VALUES(1533, '2013-04-07 10:59:11', 307, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1534, '2013-04-07 10:59:11', 307, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1535, '2013-04-07 10:59:11', 307, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1536, '2013-04-07 10:59:11', 308, 'checkin', 719, 'absolute');
INSERT INTO `record` VALUES(1537, '2013-04-07 10:59:11', 308, 'checkin-unique', 227, 'absolute');
INSERT INTO `record` VALUES(1538, '2013-04-07 10:59:11', 308, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(1539, '2013-04-07 10:59:11', 308, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1540, '2013-04-07 10:59:11', 308, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1541, '2013-04-07 10:59:11', 309, 'checkin', 201, 'absolute');
INSERT INTO `record` VALUES(1542, '2013-04-07 10:59:11', 309, 'checkin-unique', 100, 'absolute');
INSERT INTO `record` VALUES(1543, '2013-04-07 10:59:11', 309, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1544, '2013-04-07 10:59:11', 309, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1545, '2013-04-07 10:59:11', 309, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1546, '2013-04-07 10:59:11', 310, 'checkin', 32, 'absolute');
INSERT INTO `record` VALUES(1547, '2013-04-07 10:59:11', 310, 'checkin-unique', 26, 'absolute');
INSERT INTO `record` VALUES(1548, '2013-04-07 10:59:11', 310, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1549, '2013-04-07 10:59:11', 310, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1550, '2013-04-07 10:59:11', 310, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1551, '2013-04-07 10:59:11', 311, 'checkin', 30, 'absolute');
INSERT INTO `record` VALUES(1552, '2013-04-07 10:59:11', 311, 'checkin-unique', 9, 'absolute');
INSERT INTO `record` VALUES(1553, '2013-04-07 10:59:11', 311, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1554, '2013-04-07 10:59:11', 311, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1555, '2013-04-07 10:59:11', 311, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1556, '2013-04-07 10:59:12', 312, 'checkin', 1269, 'absolute');
INSERT INTO `record` VALUES(1557, '2013-04-07 10:59:12', 312, 'checkin-unique', 452, 'absolute');
INSERT INTO `record` VALUES(1558, '2013-04-07 10:59:12', 312, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(1559, '2013-04-07 10:59:12', 312, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1560, '2013-04-07 10:59:12', 312, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1561, '2013-04-07 10:59:12', 313, 'checkin', 1530, 'absolute');
INSERT INTO `record` VALUES(1562, '2013-04-07 10:59:12', 313, 'checkin-unique', 758, 'absolute');
INSERT INTO `record` VALUES(1563, '2013-04-07 10:59:12', 313, 'review', 16, 'absolute');
INSERT INTO `record` VALUES(1564, '2013-04-07 10:59:12', 313, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1565, '2013-04-07 10:59:12', 313, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1566, '2013-04-07 10:59:12', 314, 'checkin', 1534, 'absolute');
INSERT INTO `record` VALUES(1567, '2013-04-07 10:59:12', 314, 'checkin-unique', 259, 'absolute');
INSERT INTO `record` VALUES(1568, '2013-04-07 10:59:12', 314, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(1569, '2013-04-07 10:59:12', 314, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1570, '2013-04-07 10:59:12', 314, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1571, '2013-04-07 10:59:12', 315, 'checkin', 13, 'absolute');
INSERT INTO `record` VALUES(1572, '2013-04-07 10:59:12', 315, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(1573, '2013-04-07 10:59:12', 315, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1574, '2013-04-07 10:59:12', 315, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1575, '2013-04-07 10:59:12', 315, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1576, '2013-04-07 10:59:12', 316, 'checkin', 383, 'absolute');
INSERT INTO `record` VALUES(1577, '2013-04-07 10:59:12', 316, 'checkin-unique', 55, 'absolute');
INSERT INTO `record` VALUES(1578, '2013-04-07 10:59:12', 316, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1579, '2013-04-07 10:59:12', 316, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1580, '2013-04-07 10:59:12', 316, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1581, '2013-04-07 10:59:13', 317, 'checkin', 456, 'absolute');
INSERT INTO `record` VALUES(1582, '2013-04-07 10:59:13', 317, 'checkin-unique', 152, 'absolute');
INSERT INTO `record` VALUES(1583, '2013-04-07 10:59:13', 317, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1584, '2013-04-07 10:59:13', 317, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1585, '2013-04-07 10:59:13', 317, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1586, '2013-04-07 10:59:13', 318, 'checkin', 22, 'absolute');
INSERT INTO `record` VALUES(1587, '2013-04-07 10:59:13', 318, 'checkin-unique', 12, 'absolute');
INSERT INTO `record` VALUES(1588, '2013-04-07 10:59:13', 318, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1589, '2013-04-07 10:59:13', 318, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1590, '2013-04-07 10:59:13', 318, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1591, '2013-04-07 10:59:15', 319, 'checkin', 963, 'absolute');
INSERT INTO `record` VALUES(1592, '2013-04-07 10:59:15', 319, 'checkin-unique', 191, 'absolute');
INSERT INTO `record` VALUES(1593, '2013-04-07 10:59:15', 319, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1594, '2013-04-07 10:59:15', 319, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1595, '2013-04-07 10:59:15', 319, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1596, '2013-04-07 10:59:15', 320, 'checkin', 3048, 'absolute');
INSERT INTO `record` VALUES(1597, '2013-04-07 10:59:15', 320, 'checkin-unique', 1149, 'absolute');
INSERT INTO `record` VALUES(1598, '2013-04-07 10:59:15', 320, 'review', 22, 'absolute');
INSERT INTO `record` VALUES(1599, '2013-04-07 10:59:15', 320, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1600, '2013-04-07 10:59:15', 320, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1601, '2013-04-07 10:59:15', 321, 'checkin', 9, 'absolute');
INSERT INTO `record` VALUES(1602, '2013-04-07 10:59:15', 321, 'checkin-unique', 9, 'absolute');
INSERT INTO `record` VALUES(1603, '2013-04-07 10:59:15', 321, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1604, '2013-04-07 10:59:15', 321, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1605, '2013-04-07 10:59:15', 321, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1606, '2013-04-07 10:59:15', 322, 'checkin', 1421, 'absolute');
INSERT INTO `record` VALUES(1607, '2013-04-07 10:59:15', 322, 'checkin-unique', 538, 'absolute');
INSERT INTO `record` VALUES(1608, '2013-04-07 10:59:15', 322, 'review', 15, 'absolute');
INSERT INTO `record` VALUES(1609, '2013-04-07 10:59:15', 322, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1610, '2013-04-07 10:59:15', 322, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1611, '2013-04-07 10:59:15', 323, 'checkin', 173, 'absolute');
INSERT INTO `record` VALUES(1612, '2013-04-07 10:59:15', 323, 'checkin-unique', 73, 'absolute');
INSERT INTO `record` VALUES(1613, '2013-04-07 10:59:15', 323, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1614, '2013-04-07 10:59:15', 323, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1615, '2013-04-07 10:59:15', 323, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1616, '2013-04-07 10:59:16', 324, 'checkin', 0, 'absolute');
INSERT INTO `record` VALUES(1617, '2013-04-07 10:59:16', 324, 'checkin-unique', 0, 'absolute');
INSERT INTO `record` VALUES(1618, '2013-04-07 10:59:16', 324, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1619, '2013-04-07 10:59:16', 324, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1620, '2013-04-07 10:59:16', 324, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1621, '2013-04-07 10:59:17', 325, 'checkin', 142, 'absolute');
INSERT INTO `record` VALUES(1622, '2013-04-07 10:59:17', 325, 'checkin-unique', 12, 'absolute');
INSERT INTO `record` VALUES(1623, '2013-04-07 10:59:17', 325, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1624, '2013-04-07 10:59:17', 325, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1625, '2013-04-07 10:59:17', 325, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1626, '2013-04-07 10:59:17', 326, 'checkin', 433, 'absolute');
INSERT INTO `record` VALUES(1627, '2013-04-07 10:59:17', 326, 'checkin-unique', 199, 'absolute');
INSERT INTO `record` VALUES(1628, '2013-04-07 10:59:17', 326, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(1629, '2013-04-07 10:59:17', 326, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1630, '2013-04-07 10:59:17', 326, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1631, '2013-04-07 10:59:19', 327, 'checkin', 1460, 'absolute');
INSERT INTO `record` VALUES(1632, '2013-04-07 10:59:19', 327, 'checkin-unique', 429, 'absolute');
INSERT INTO `record` VALUES(1633, '2013-04-07 10:59:19', 327, 'review', 5, 'absolute');
INSERT INTO `record` VALUES(1634, '2013-04-07 10:59:19', 327, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1635, '2013-04-07 10:59:19', 327, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1636, '2013-04-07 10:59:20', 328, 'checkin', 574, 'absolute');
INSERT INTO `record` VALUES(1637, '2013-04-07 10:59:20', 328, 'checkin-unique', 124, 'absolute');
INSERT INTO `record` VALUES(1638, '2013-04-07 10:59:20', 328, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1639, '2013-04-07 10:59:20', 328, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1640, '2013-04-07 10:59:20', 328, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1641, '2013-04-07 10:59:23', 329, 'checkin', 1086, 'absolute');
INSERT INTO `record` VALUES(1642, '2013-04-07 10:59:23', 329, 'checkin-unique', 415, 'absolute');
INSERT INTO `record` VALUES(1643, '2013-04-07 10:59:23', 329, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(1644, '2013-04-07 10:59:23', 329, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1645, '2013-04-07 10:59:23', 329, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1646, '2013-04-07 10:59:23', 330, 'checkin', 1669, 'absolute');
INSERT INTO `record` VALUES(1647, '2013-04-07 10:59:23', 330, 'checkin-unique', 758, 'absolute');
INSERT INTO `record` VALUES(1648, '2013-04-07 10:59:23', 330, 'review', 20, 'absolute');
INSERT INTO `record` VALUES(1649, '2013-04-07 10:59:23', 330, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1650, '2013-04-07 10:59:23', 330, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1651, '2013-04-07 10:59:23', 331, 'checkin', 570, 'absolute');
INSERT INTO `record` VALUES(1652, '2013-04-07 10:59:23', 331, 'checkin-unique', 215, 'absolute');
INSERT INTO `record` VALUES(1653, '2013-04-07 10:59:23', 331, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1654, '2013-04-07 10:59:23', 331, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1655, '2013-04-07 10:59:23', 331, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1656, '2013-04-07 10:59:23', 332, 'checkin', 938, 'absolute');
INSERT INTO `record` VALUES(1657, '2013-04-07 10:59:23', 332, 'checkin-unique', 270, 'absolute');
INSERT INTO `record` VALUES(1658, '2013-04-07 10:59:23', 332, 'review', 9, 'absolute');
INSERT INTO `record` VALUES(1659, '2013-04-07 10:59:23', 332, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1660, '2013-04-07 10:59:23', 332, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1661, '2013-04-07 10:59:23', 333, 'checkin', 48, 'absolute');
INSERT INTO `record` VALUES(1662, '2013-04-07 10:59:23', 333, 'checkin-unique', 21, 'absolute');
INSERT INTO `record` VALUES(1663, '2013-04-07 10:59:23', 333, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1664, '2013-04-07 10:59:23', 333, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1665, '2013-04-07 10:59:23', 333, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1666, '2013-04-07 10:59:23', 334, 'checkin', 263, 'absolute');
INSERT INTO `record` VALUES(1667, '2013-04-07 10:59:23', 334, 'checkin-unique', 21, 'absolute');
INSERT INTO `record` VALUES(1668, '2013-04-07 10:59:23', 334, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1669, '2013-04-07 10:59:23', 334, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1670, '2013-04-07 10:59:23', 334, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1671, '2013-04-07 10:59:25', 335, 'checkin', 179, 'absolute');
INSERT INTO `record` VALUES(1672, '2013-04-07 10:59:25', 335, 'checkin-unique', 80, 'absolute');
INSERT INTO `record` VALUES(1673, '2013-04-07 10:59:25', 335, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1674, '2013-04-07 10:59:25', 335, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1675, '2013-04-07 10:59:25', 335, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1676, '2013-04-07 10:59:25', 336, 'checkin', 1331, 'absolute');
INSERT INTO `record` VALUES(1677, '2013-04-07 10:59:25', 336, 'checkin-unique', 241, 'absolute');
INSERT INTO `record` VALUES(1678, '2013-04-07 10:59:25', 336, 'review', 9, 'absolute');
INSERT INTO `record` VALUES(1679, '2013-04-07 10:59:25', 336, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1680, '2013-04-07 10:59:26', 336, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1681, '2013-04-07 10:59:26', 337, 'checkin', 1409, 'absolute');
INSERT INTO `record` VALUES(1682, '2013-04-07 10:59:26', 337, 'checkin-unique', 341, 'absolute');
INSERT INTO `record` VALUES(1683, '2013-04-07 10:59:26', 337, 'review', 18, 'absolute');
INSERT INTO `record` VALUES(1684, '2013-04-07 10:59:26', 337, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1685, '2013-04-07 10:59:26', 337, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1686, '2013-04-07 10:59:26', 338, 'checkin', 49, 'absolute');
INSERT INTO `record` VALUES(1687, '2013-04-07 10:59:26', 338, 'checkin-unique', 32, 'absolute');
INSERT INTO `record` VALUES(1688, '2013-04-07 10:59:26', 338, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(1689, '2013-04-07 10:59:26', 338, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1690, '2013-04-07 10:59:26', 338, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1691, '2013-04-07 10:59:26', 339, 'checkin', 7588, 'absolute');
INSERT INTO `record` VALUES(1692, '2013-04-07 10:59:26', 339, 'checkin-unique', 4093, 'absolute');
INSERT INTO `record` VALUES(1693, '2013-04-07 10:59:26', 339, 'review', 49, 'absolute');
INSERT INTO `record` VALUES(1694, '2013-04-07 10:59:26', 339, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1695, '2013-04-07 10:59:26', 339, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1696, '2013-04-07 10:59:26', 340, 'checkin', 8, 'absolute');
INSERT INTO `record` VALUES(1697, '2013-04-07 10:59:26', 340, 'checkin-unique', 8, 'absolute');
INSERT INTO `record` VALUES(1698, '2013-04-07 10:59:26', 340, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1699, '2013-04-07 10:59:26', 340, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1700, '2013-04-07 10:59:26', 340, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1701, '2013-04-07 10:59:27', 341, 'checkin', 7, 'absolute');
INSERT INTO `record` VALUES(1702, '2013-04-07 10:59:27', 341, 'checkin-unique', 7, 'absolute');
INSERT INTO `record` VALUES(1703, '2013-04-07 10:59:27', 341, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1704, '2013-04-07 10:59:27', 341, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1705, '2013-04-07 10:59:27', 341, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1706, '2013-04-07 10:59:27', 342, 'checkin', 3107, 'absolute');
INSERT INTO `record` VALUES(1707, '2013-04-07 10:59:27', 342, 'checkin-unique', 593, 'absolute');
INSERT INTO `record` VALUES(1708, '2013-04-07 10:59:27', 342, 'review', 16, 'absolute');
INSERT INTO `record` VALUES(1709, '2013-04-07 10:59:27', 342, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1710, '2013-04-07 10:59:27', 342, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1711, '2013-04-07 10:59:28', 343, 'checkin', 1665, 'absolute');
INSERT INTO `record` VALUES(1712, '2013-04-07 10:59:28', 343, 'checkin-unique', 453, 'absolute');
INSERT INTO `record` VALUES(1713, '2013-04-07 10:59:28', 343, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(1714, '2013-04-07 10:59:28', 343, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1715, '2013-04-07 10:59:28', 343, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1716, '2013-04-07 10:59:31', 344, 'checkin', 1323, 'absolute');
INSERT INTO `record` VALUES(1717, '2013-04-07 10:59:31', 344, 'checkin-unique', 430, 'absolute');
INSERT INTO `record` VALUES(1718, '2013-04-07 10:59:31', 344, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(1719, '2013-04-07 10:59:31', 344, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1720, '2013-04-07 10:59:31', 344, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1721, '2013-04-07 10:59:31', 345, 'checkin', 1094, 'absolute');
INSERT INTO `record` VALUES(1722, '2013-04-07 10:59:31', 345, 'checkin-unique', 407, 'absolute');
INSERT INTO `record` VALUES(1723, '2013-04-07 10:59:31', 345, 'review', 9, 'absolute');
INSERT INTO `record` VALUES(1724, '2013-04-07 10:59:31', 345, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1725, '2013-04-07 10:59:31', 345, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1726, '2013-04-07 10:59:31', 346, 'checkin', 220, 'absolute');
INSERT INTO `record` VALUES(1727, '2013-04-07 10:59:31', 346, 'checkin-unique', 93, 'absolute');
INSERT INTO `record` VALUES(1728, '2013-04-07 10:59:31', 346, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(1729, '2013-04-07 10:59:31', 346, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1730, '2013-04-07 10:59:31', 346, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1731, '2013-04-07 10:59:31', 347, 'checkin', 4411, 'absolute');
INSERT INTO `record` VALUES(1732, '2013-04-07 10:59:31', 347, 'checkin-unique', 1179, 'absolute');
INSERT INTO `record` VALUES(1733, '2013-04-07 10:59:32', 347, 'review', 36, 'absolute');
INSERT INTO `record` VALUES(1734, '2013-04-07 10:59:32', 347, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1735, '2013-04-07 10:59:32', 347, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1736, '2013-04-07 10:59:32', 348, 'checkin', 386, 'absolute');
INSERT INTO `record` VALUES(1737, '2013-04-07 10:59:32', 348, 'checkin-unique', 243, 'absolute');
INSERT INTO `record` VALUES(1738, '2013-04-07 10:59:32', 348, 'review', 7, 'absolute');
INSERT INTO `record` VALUES(1739, '2013-04-07 10:59:32', 348, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1740, '2013-04-07 10:59:32', 348, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1741, '2013-04-07 10:59:32', 349, 'checkin', 1, 'absolute');
INSERT INTO `record` VALUES(1742, '2013-04-07 10:59:32', 349, 'checkin-unique', 1, 'absolute');
INSERT INTO `record` VALUES(1743, '2013-04-07 10:59:32', 349, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1744, '2013-04-07 10:59:32', 349, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1745, '2013-04-07 10:59:32', 349, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1746, '2013-04-07 10:59:32', 350, 'checkin', 3997, 'absolute');
INSERT INTO `record` VALUES(1747, '2013-04-07 10:59:32', 350, 'checkin-unique', 1119, 'absolute');
INSERT INTO `record` VALUES(1748, '2013-04-07 10:59:32', 350, 'review', 17, 'absolute');
INSERT INTO `record` VALUES(1749, '2013-04-07 10:59:32', 350, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1750, '2013-04-07 10:59:32', 350, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1751, '2013-04-07 10:59:32', 351, 'checkin', 0, 'absolute');
INSERT INTO `record` VALUES(1752, '2013-04-07 10:59:32', 351, 'checkin-unique', 0, 'absolute');
INSERT INTO `record` VALUES(1753, '2013-04-07 10:59:32', 351, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1754, '2013-04-07 10:59:32', 351, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1755, '2013-04-07 10:59:32', 351, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1756, '2013-04-07 11:06:03', 352, 'checkin', 10, 'absolute');
INSERT INTO `record` VALUES(1757, '2013-04-07 11:06:03', 352, 'checkin-unique', 6, 'absolute');
INSERT INTO `record` VALUES(1758, '2013-04-07 11:06:03', 352, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1759, '2013-04-07 11:06:03', 352, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1760, '2013-04-07 11:06:03', 352, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1761, '2013-04-07 11:06:06', 353, 'checkin', 23, 'absolute');
INSERT INTO `record` VALUES(1762, '2013-04-07 11:06:06', 353, 'checkin-unique', 21, 'absolute');
INSERT INTO `record` VALUES(1763, '2013-04-07 11:06:06', 353, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1764, '2013-04-07 11:06:06', 353, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1765, '2013-04-07 11:06:06', 353, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1766, '2013-04-07 11:06:07', 354, 'checkin', 3906, 'absolute');
INSERT INTO `record` VALUES(1767, '2013-04-07 11:06:07', 354, 'checkin-unique', 751, 'absolute');
INSERT INTO `record` VALUES(1768, '2013-04-07 11:06:07', 354, 'review', 11, 'absolute');
INSERT INTO `record` VALUES(1769, '2013-04-07 11:06:07', 354, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1770, '2013-04-07 11:06:07', 354, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1771, '2013-04-07 11:06:10', 355, 'checkin', 118, 'absolute');
INSERT INTO `record` VALUES(1772, '2013-04-07 11:06:10', 355, 'checkin-unique', 49, 'absolute');
INSERT INTO `record` VALUES(1773, '2013-04-07 11:06:10', 355, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1774, '2013-04-07 11:06:10', 355, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1775, '2013-04-07 11:06:10', 355, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1776, '2013-04-07 11:06:11', 356, 'checkin', 43, 'absolute');
INSERT INTO `record` VALUES(1777, '2013-04-07 11:06:11', 356, 'checkin-unique', 37, 'absolute');
INSERT INTO `record` VALUES(1778, '2013-04-07 11:06:11', 356, 'review', 1, 'absolute');
INSERT INTO `record` VALUES(1779, '2013-04-07 11:06:11', 356, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1780, '2013-04-07 11:06:11', 356, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1781, '2013-04-07 11:06:12', 357, 'checkin', 3245, 'absolute');
INSERT INTO `record` VALUES(1782, '2013-04-07 11:06:12', 357, 'checkin-unique', 863, 'absolute');
INSERT INTO `record` VALUES(1783, '2013-04-07 11:06:12', 357, 'review', 11, 'absolute');
INSERT INTO `record` VALUES(1784, '2013-04-07 11:06:12', 357, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1785, '2013-04-07 11:06:12', 357, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1786, '2013-04-07 11:06:12', 358, 'checkin', 1410, 'absolute');
INSERT INTO `record` VALUES(1787, '2013-04-07 11:06:12', 358, 'checkin-unique', 487, 'absolute');
INSERT INTO `record` VALUES(1788, '2013-04-07 11:06:12', 358, 'review', 4, 'absolute');
INSERT INTO `record` VALUES(1789, '2013-04-07 11:06:12', 358, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1790, '2013-04-07 11:06:12', 358, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1791, '2013-04-07 11:06:15', 359, 'checkin', 7, 'absolute');
INSERT INTO `record` VALUES(1792, '2013-04-07 11:06:15', 359, 'checkin-unique', 4, 'absolute');
INSERT INTO `record` VALUES(1793, '2013-04-07 11:06:15', 359, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1794, '2013-04-07 11:06:15', 359, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1795, '2013-04-07 11:06:15', 359, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1796, '2013-04-07 11:06:17', 360, 'checkin', 536, 'absolute');
INSERT INTO `record` VALUES(1797, '2013-04-07 11:06:17', 360, 'checkin-unique', 130, 'absolute');
INSERT INTO `record` VALUES(1798, '2013-04-07 11:06:17', 360, 'review', 6, 'absolute');
INSERT INTO `record` VALUES(1799, '2013-04-07 11:06:17', 360, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1800, '2013-04-07 11:06:17', 360, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1801, '2013-04-07 11:06:18', 361, 'checkin', 314, 'absolute');
INSERT INTO `record` VALUES(1802, '2013-04-07 11:06:18', 361, 'checkin-unique', 116, 'absolute');
INSERT INTO `record` VALUES(1803, '2013-04-07 11:06:18', 361, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1804, '2013-04-07 11:06:18', 361, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1805, '2013-04-07 11:06:18', 361, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1806, '2013-04-07 11:06:20', 362, 'checkin', 2072, 'absolute');
INSERT INTO `record` VALUES(1807, '2013-04-07 11:06:20', 362, 'checkin-unique', 291, 'absolute');
INSERT INTO `record` VALUES(1808, '2013-04-07 11:06:20', 362, 'review', 2, 'absolute');
INSERT INTO `record` VALUES(1809, '2013-04-07 11:06:20', 362, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1810, '2013-04-07 11:06:20', 362, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1811, '2013-04-07 11:06:22', 363, 'checkin', 502, 'absolute');
INSERT INTO `record` VALUES(1812, '2013-04-07 11:06:22', 363, 'checkin-unique', 208, 'absolute');
INSERT INTO `record` VALUES(1813, '2013-04-07 11:06:22', 363, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(1814, '2013-04-07 11:06:22', 363, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1815, '2013-04-07 11:06:22', 363, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1816, '2013-04-07 11:06:26', 364, 'checkin', 8, 'absolute');
INSERT INTO `record` VALUES(1817, '2013-04-07 11:06:26', 364, 'checkin-unique', 3, 'absolute');
INSERT INTO `record` VALUES(1818, '2013-04-07 11:06:26', 364, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1819, '2013-04-07 11:06:26', 364, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1820, '2013-04-07 11:06:26', 364, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1821, '2013-04-07 11:06:30', 365, 'checkin', 31, 'absolute');
INSERT INTO `record` VALUES(1822, '2013-04-07 11:06:30', 365, 'checkin-unique', 20, 'absolute');
INSERT INTO `record` VALUES(1823, '2013-04-07 11:06:30', 365, 'review', 0, 'absolute');
INSERT INTO `record` VALUES(1824, '2013-04-07 11:06:30', 365, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1825, '2013-04-07 11:06:30', 365, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1826, '2013-04-07 11:06:31', 366, 'checkin', 766, 'absolute');
INSERT INTO `record` VALUES(1827, '2013-04-07 11:06:31', 366, 'checkin-unique', 60, 'absolute');
INSERT INTO `record` VALUES(1828, '2013-04-07 11:06:31', 366, 'review', 3, 'absolute');
INSERT INTO `record` VALUES(1829, '2013-04-07 11:06:31', 366, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1830, '2013-04-07 11:06:31', 366, 'herenow', 0, 'absolute');
INSERT INTO `record` VALUES(1831, '2013-04-07 11:06:33', 367, 'checkin', 189, 'absolute');
INSERT INTO `record` VALUES(1832, '2013-04-07 11:06:33', 367, 'checkin-unique', 65, 'absolute');
INSERT INTO `record` VALUES(1833, '2013-04-07 11:06:33', 367, 'review', 9, 'absolute');
INSERT INTO `record` VALUES(1834, '2013-04-07 11:06:33', 367, 'like', 0, 'absolute');
INSERT INTO `record` VALUES(1835, '2013-04-07 11:06:33', 367, 'herenow', 0, 'absolute');

-- --------------------------------------------------------

--
-- Table structure for table `singleton`
--

CREATE TABLE `singleton` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `object_type` enum('interaction','venue','keyword','keword_venue') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_type` (`object_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=368 ;

--
-- Dumping data for table `singleton`
--

INSERT INTO `singleton` VALUES(1, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(2, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(3, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(4, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(5, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(6, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(7, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(8, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(9, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(10, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(11, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(12, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(13, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(14, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(15, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(16, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(17, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(18, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(19, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(20, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(21, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(22, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(23, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(24, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(25, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(26, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(27, 'venue', '2013-04-06 17:57:18', '2013-04-06 17:57:18', NULL);
INSERT INTO `singleton` VALUES(28, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(29, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(30, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(31, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(32, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(33, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(34, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(35, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(36, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(37, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(38, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(39, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(40, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(41, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(42, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(43, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(44, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(45, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(46, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(47, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(48, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(49, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(50, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(51, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(52, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(53, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(54, 'venue', '2013-04-06 17:57:19', '2013-04-06 17:57:19', NULL);
INSERT INTO `singleton` VALUES(55, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(56, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(57, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(58, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(59, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(60, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(61, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(62, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(63, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(64, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(65, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(66, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(67, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(68, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(69, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(70, 'venue', '2013-04-06 17:57:20', '2013-04-06 17:57:20', NULL);
INSERT INTO `singleton` VALUES(71, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(72, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(73, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(74, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(75, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(76, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(77, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(78, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(79, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(80, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(81, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(82, 'venue', '2013-04-06 17:57:21', '2013-04-06 17:57:21', NULL);
INSERT INTO `singleton` VALUES(83, 'venue', '2013-04-06 17:57:22', '2013-04-06 17:57:22', NULL);
INSERT INTO `singleton` VALUES(84, 'venue', '2013-04-06 17:57:23', '2013-04-06 17:57:23', NULL);
INSERT INTO `singleton` VALUES(85, 'venue', '2013-04-06 17:57:23', '2013-04-06 17:57:23', NULL);
INSERT INTO `singleton` VALUES(86, 'venue', '2013-04-06 17:57:24', '2013-04-06 17:57:24', NULL);
INSERT INTO `singleton` VALUES(87, 'venue', '2013-04-06 17:57:24', '2013-04-06 17:57:24', NULL);
INSERT INTO `singleton` VALUES(88, 'venue', '2013-04-06 17:57:24', '2013-04-06 17:57:24', NULL);
INSERT INTO `singleton` VALUES(89, 'venue', '2013-04-06 17:57:24', '2013-04-06 17:57:24', NULL);
INSERT INTO `singleton` VALUES(90, 'venue', '2013-04-06 17:57:25', '2013-04-06 17:57:25', NULL);
INSERT INTO `singleton` VALUES(91, 'venue', '2013-04-06 17:57:27', '2013-04-06 17:57:27', NULL);
INSERT INTO `singleton` VALUES(92, 'venue', '2013-04-06 17:57:27', '2013-04-06 17:57:27', NULL);
INSERT INTO `singleton` VALUES(93, 'venue', '2013-04-06 17:57:28', '2013-04-06 17:57:28', NULL);
INSERT INTO `singleton` VALUES(94, 'venue', '2013-04-06 17:57:28', '2013-04-06 17:57:28', NULL);
INSERT INTO `singleton` VALUES(95, 'venue', '2013-04-06 17:57:28', '2013-04-06 17:57:28', NULL);
INSERT INTO `singleton` VALUES(96, 'venue', '2013-04-06 17:57:33', '2013-04-06 17:57:33', NULL);
INSERT INTO `singleton` VALUES(97, 'venue', '2013-04-06 17:57:33', '2013-04-06 17:57:33', NULL);
INSERT INTO `singleton` VALUES(98, 'venue', '2013-04-06 17:57:34', '2013-04-06 17:57:34', NULL);
INSERT INTO `singleton` VALUES(99, 'venue', '2013-04-06 17:57:34', '2013-04-06 17:57:34', NULL);
INSERT INTO `singleton` VALUES(100, 'venue', '2013-04-06 17:57:35', '2013-04-06 17:57:35', NULL);
INSERT INTO `singleton` VALUES(101, 'venue', '2013-04-06 17:57:35', '2013-04-06 17:57:35', NULL);
INSERT INTO `singleton` VALUES(102, 'venue', '2013-04-06 17:57:35', '2013-04-06 17:57:35', NULL);
INSERT INTO `singleton` VALUES(103, 'venue', '2013-04-06 17:57:35', '2013-04-06 17:57:35', NULL);
INSERT INTO `singleton` VALUES(104, 'venue', '2013-04-06 17:57:35', '2013-04-06 17:57:35', NULL);
INSERT INTO `singleton` VALUES(105, 'venue', '2013-04-06 17:57:36', '2013-04-06 17:57:36', NULL);
INSERT INTO `singleton` VALUES(106, 'venue', '2013-04-06 17:57:36', '2013-04-06 17:57:36', NULL);
INSERT INTO `singleton` VALUES(107, 'venue', '2013-04-06 17:57:36', '2013-04-06 17:57:36', NULL);
INSERT INTO `singleton` VALUES(108, 'venue', '2013-04-06 17:57:36', '2013-04-06 17:57:36', NULL);
INSERT INTO `singleton` VALUES(109, 'venue', '2013-04-06 17:57:36', '2013-04-06 17:57:36', NULL);
INSERT INTO `singleton` VALUES(110, 'venue', '2013-04-06 17:57:36', '2013-04-06 17:57:36', NULL);
INSERT INTO `singleton` VALUES(111, 'venue', '2013-04-06 17:57:36', '2013-04-06 17:57:36', NULL);
INSERT INTO `singleton` VALUES(112, 'venue', '2013-04-06 17:57:37', '2013-04-06 17:57:37', NULL);
INSERT INTO `singleton` VALUES(113, 'venue', '2013-04-06 17:57:37', '2013-04-06 17:57:37', NULL);
INSERT INTO `singleton` VALUES(114, 'venue', '2013-04-06 17:57:37', '2013-04-06 17:57:37', NULL);
INSERT INTO `singleton` VALUES(115, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(116, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(117, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(118, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(119, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(120, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(121, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(122, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(123, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(124, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(125, 'venue', '2013-04-06 17:58:03', '2013-04-06 17:58:03', NULL);
INSERT INTO `singleton` VALUES(126, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(127, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(128, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(129, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(130, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(131, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(132, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(133, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(134, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(135, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(136, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(137, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(138, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(139, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(140, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(141, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(142, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(143, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(144, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(145, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(146, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(147, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(148, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(149, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(150, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(151, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(152, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(153, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(154, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(155, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(156, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(157, 'venue', '2013-04-06 17:58:04', '2013-04-06 17:58:04', NULL);
INSERT INTO `singleton` VALUES(158, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(159, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(160, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(161, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(162, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(163, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(164, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(165, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(166, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(167, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(168, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(169, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(170, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(171, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(172, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(173, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(174, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(175, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(176, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(177, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(178, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(179, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(180, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(181, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(182, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(183, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(184, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(185, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(186, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(187, 'venue', '2013-04-06 17:58:05', '2013-04-06 17:58:05', NULL);
INSERT INTO `singleton` VALUES(188, 'venue', '2013-04-07 10:58:34', '2013-04-07 10:58:34', NULL);
INSERT INTO `singleton` VALUES(189, 'venue', '2013-04-07 10:58:34', '2013-04-07 10:58:34', NULL);
INSERT INTO `singleton` VALUES(190, 'venue', '2013-04-07 10:58:35', '2013-04-07 10:58:35', NULL);
INSERT INTO `singleton` VALUES(191, 'venue', '2013-04-07 10:58:35', '2013-04-07 10:58:35', NULL);
INSERT INTO `singleton` VALUES(192, 'venue', '2013-04-07 10:58:35', '2013-04-07 10:58:35', NULL);
INSERT INTO `singleton` VALUES(193, 'venue', '2013-04-07 10:58:36', '2013-04-07 10:58:36', NULL);
INSERT INTO `singleton` VALUES(194, 'venue', '2013-04-07 10:58:36', '2013-04-07 10:58:36', NULL);
INSERT INTO `singleton` VALUES(195, 'venue', '2013-04-07 10:58:36', '2013-04-07 10:58:36', NULL);
INSERT INTO `singleton` VALUES(196, 'venue', '2013-04-07 10:58:36', '2013-04-07 10:58:36', NULL);
INSERT INTO `singleton` VALUES(197, 'venue', '2013-04-07 10:58:36', '2013-04-07 10:58:36', NULL);
INSERT INTO `singleton` VALUES(198, 'venue', '2013-04-07 10:58:37', '2013-04-07 10:58:37', NULL);
INSERT INTO `singleton` VALUES(199, 'venue', '2013-04-07 10:58:37', '2013-04-07 10:58:37', NULL);
INSERT INTO `singleton` VALUES(200, 'venue', '2013-04-07 10:58:37', '2013-04-07 10:58:37', NULL);
INSERT INTO `singleton` VALUES(201, 'venue', '2013-04-07 10:58:37', '2013-04-07 10:58:37', NULL);
INSERT INTO `singleton` VALUES(202, 'venue', '2013-04-07 10:58:37', '2013-04-07 10:58:37', NULL);
INSERT INTO `singleton` VALUES(203, 'venue', '2013-04-07 10:58:37', '2013-04-07 10:58:37', NULL);
INSERT INTO `singleton` VALUES(204, 'venue', '2013-04-07 10:58:38', '2013-04-07 10:58:38', NULL);
INSERT INTO `singleton` VALUES(205, 'venue', '2013-04-07 10:58:38', '2013-04-07 10:58:38', NULL);
INSERT INTO `singleton` VALUES(206, 'venue', '2013-04-07 10:58:38', '2013-04-07 10:58:38', NULL);
INSERT INTO `singleton` VALUES(207, 'venue', '2013-04-07 10:58:38', '2013-04-07 10:58:38', NULL);
INSERT INTO `singleton` VALUES(208, 'venue', '2013-04-07 10:58:38', '2013-04-07 10:58:38', NULL);
INSERT INTO `singleton` VALUES(209, 'venue', '2013-04-07 10:58:38', '2013-04-07 10:58:38', NULL);
INSERT INTO `singleton` VALUES(210, 'venue', '2013-04-07 10:58:39', '2013-04-07 10:58:39', NULL);
INSERT INTO `singleton` VALUES(211, 'venue', '2013-04-07 10:58:40', '2013-04-07 10:58:40', NULL);
INSERT INTO `singleton` VALUES(212, 'venue', '2013-04-07 10:58:40', '2013-04-07 10:58:40', NULL);
INSERT INTO `singleton` VALUES(213, 'venue', '2013-04-07 10:58:41', '2013-04-07 10:58:41', NULL);
INSERT INTO `singleton` VALUES(214, 'venue', '2013-04-07 10:58:41', '2013-04-07 10:58:41', NULL);
INSERT INTO `singleton` VALUES(215, 'venue', '2013-04-07 10:58:42', '2013-04-07 10:58:42', NULL);
INSERT INTO `singleton` VALUES(216, 'venue', '2013-04-07 10:58:43', '2013-04-07 10:58:43', NULL);
INSERT INTO `singleton` VALUES(217, 'venue', '2013-04-07 10:58:43', '2013-04-07 10:58:43', NULL);
INSERT INTO `singleton` VALUES(218, 'venue', '2013-04-07 10:58:44', '2013-04-07 10:58:44', NULL);
INSERT INTO `singleton` VALUES(219, 'venue', '2013-04-07 10:58:45', '2013-04-07 10:58:45', NULL);
INSERT INTO `singleton` VALUES(220, 'venue', '2013-04-07 10:58:45', '2013-04-07 10:58:45', NULL);
INSERT INTO `singleton` VALUES(221, 'venue', '2013-04-07 10:58:46', '2013-04-07 10:58:46', NULL);
INSERT INTO `singleton` VALUES(222, 'venue', '2013-04-07 10:58:48', '2013-04-07 10:58:48', NULL);
INSERT INTO `singleton` VALUES(223, 'venue', '2013-04-07 10:58:49', '2013-04-07 10:58:49', NULL);
INSERT INTO `singleton` VALUES(224, 'venue', '2013-04-07 10:58:49', '2013-04-07 10:58:49', NULL);
INSERT INTO `singleton` VALUES(225, 'venue', '2013-04-07 10:58:50', '2013-04-07 10:58:50', NULL);
INSERT INTO `singleton` VALUES(226, 'venue', '2013-04-07 10:58:52', '2013-04-07 10:58:52', NULL);
INSERT INTO `singleton` VALUES(227, 'venue', '2013-04-07 10:58:54', '2013-04-07 10:58:54', NULL);
INSERT INTO `singleton` VALUES(228, 'venue', '2013-04-07 10:58:55', '2013-04-07 10:58:55', NULL);
INSERT INTO `singleton` VALUES(229, 'venue', '2013-04-07 10:58:56', '2013-04-07 10:58:56', NULL);
INSERT INTO `singleton` VALUES(230, 'venue', '2013-04-07 10:58:58', '2013-04-07 10:58:58', NULL);
INSERT INTO `singleton` VALUES(231, 'venue', '2013-04-07 10:58:58', '2013-04-07 10:58:58', NULL);
INSERT INTO `singleton` VALUES(232, 'venue', '2013-04-07 10:58:59', '2013-04-07 10:58:59', NULL);
INSERT INTO `singleton` VALUES(233, 'venue', '2013-04-07 10:58:59', '2013-04-07 10:58:59', NULL);
INSERT INTO `singleton` VALUES(234, 'venue', '2013-04-07 10:59:00', '2013-04-07 10:59:00', NULL);
INSERT INTO `singleton` VALUES(235, 'venue', '2013-04-07 10:59:00', '2013-04-07 10:59:00', NULL);
INSERT INTO `singleton` VALUES(236, 'venue', '2013-04-07 10:59:00', '2013-04-07 10:59:00', NULL);
INSERT INTO `singleton` VALUES(237, 'venue', '2013-04-07 10:59:00', '2013-04-07 10:59:00', NULL);
INSERT INTO `singleton` VALUES(238, 'venue', '2013-04-07 10:59:01', '2013-04-07 10:59:01', NULL);
INSERT INTO `singleton` VALUES(239, 'venue', '2013-04-07 10:59:01', '2013-04-07 10:59:01', NULL);
INSERT INTO `singleton` VALUES(240, 'venue', '2013-04-07 10:59:01', '2013-04-07 10:59:01', NULL);
INSERT INTO `singleton` VALUES(241, 'venue', '2013-04-07 10:59:02', '2013-04-07 10:59:02', NULL);
INSERT INTO `singleton` VALUES(242, 'venue', '2013-04-07 10:59:02', '2013-04-07 10:59:02', NULL);
INSERT INTO `singleton` VALUES(243, 'venue', '2013-04-07 10:59:02', '2013-04-07 10:59:02', NULL);
INSERT INTO `singleton` VALUES(244, 'venue', '2013-04-07 10:59:02', '2013-04-07 10:59:02', NULL);
INSERT INTO `singleton` VALUES(245, 'venue', '2013-04-07 10:59:02', '2013-04-07 10:59:02', NULL);
INSERT INTO `singleton` VALUES(246, 'venue', '2013-04-07 10:59:02', '2013-04-07 10:59:02', NULL);
INSERT INTO `singleton` VALUES(247, 'venue', '2013-04-07 10:59:02', '2013-04-07 10:59:02', NULL);
INSERT INTO `singleton` VALUES(248, 'venue', '2013-04-07 10:59:02', '2013-04-07 10:59:02', NULL);
INSERT INTO `singleton` VALUES(249, 'venue', '2013-04-07 10:59:03', '2013-04-07 10:59:03', NULL);
INSERT INTO `singleton` VALUES(250, 'venue', '2013-04-07 10:59:03', '2013-04-07 10:59:03', NULL);
INSERT INTO `singleton` VALUES(251, 'venue', '2013-04-07 10:59:03', '2013-04-07 10:59:03', NULL);
INSERT INTO `singleton` VALUES(252, 'venue', '2013-04-07 10:59:03', '2013-04-07 10:59:03', NULL);
INSERT INTO `singleton` VALUES(253, 'venue', '2013-04-07 10:59:03', '2013-04-07 10:59:03', NULL);
INSERT INTO `singleton` VALUES(254, 'venue', '2013-04-07 10:59:04', '2013-04-07 10:59:04', NULL);
INSERT INTO `singleton` VALUES(255, 'venue', '2013-04-07 10:59:04', '2013-04-07 10:59:04', NULL);
INSERT INTO `singleton` VALUES(256, 'venue', '2013-04-07 10:59:04', '2013-04-07 10:59:04', NULL);
INSERT INTO `singleton` VALUES(257, 'venue', '2013-04-07 10:59:04', '2013-04-07 10:59:04', NULL);
INSERT INTO `singleton` VALUES(258, 'venue', '2013-04-07 10:59:04', '2013-04-07 10:59:04', NULL);
INSERT INTO `singleton` VALUES(259, 'venue', '2013-04-07 10:59:04', '2013-04-07 10:59:04', NULL);
INSERT INTO `singleton` VALUES(260, 'venue', '2013-04-07 10:59:04', '2013-04-07 10:59:04', NULL);
INSERT INTO `singleton` VALUES(261, 'venue', '2013-04-07 10:59:04', '2013-04-07 10:59:04', NULL);
INSERT INTO `singleton` VALUES(262, 'venue', '2013-04-07 10:59:04', '2013-04-07 10:59:04', NULL);
INSERT INTO `singleton` VALUES(263, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(264, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(265, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(266, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(267, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(268, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(269, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(270, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(271, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(272, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(273, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(274, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(275, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(276, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(277, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(278, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(279, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(280, 'venue', '2013-04-07 10:59:05', '2013-04-07 10:59:05', NULL);
INSERT INTO `singleton` VALUES(281, 'venue', '2013-04-07 10:59:06', '2013-04-07 10:59:06', NULL);
INSERT INTO `singleton` VALUES(282, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(283, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(284, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(285, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(286, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(287, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(288, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(289, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(290, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(291, 'venue', '2013-04-07 10:59:08', '2013-04-07 10:59:08', NULL);
INSERT INTO `singleton` VALUES(292, 'venue', '2013-04-07 10:59:09', '2013-04-07 10:59:09', NULL);
INSERT INTO `singleton` VALUES(293, 'venue', '2013-04-07 10:59:09', '2013-04-07 10:59:09', NULL);
INSERT INTO `singleton` VALUES(294, 'venue', '2013-04-07 10:59:09', '2013-04-07 10:59:09', NULL);
INSERT INTO `singleton` VALUES(295, 'venue', '2013-04-07 10:59:09', '2013-04-07 10:59:09', NULL);
INSERT INTO `singleton` VALUES(296, 'venue', '2013-04-07 10:59:09', '2013-04-07 10:59:09', NULL);
INSERT INTO `singleton` VALUES(297, 'venue', '2013-04-07 10:59:10', '2013-04-07 10:59:10', NULL);
INSERT INTO `singleton` VALUES(298, 'venue', '2013-04-07 10:59:10', '2013-04-07 10:59:10', NULL);
INSERT INTO `singleton` VALUES(299, 'venue', '2013-04-07 10:59:10', '2013-04-07 10:59:10', NULL);
INSERT INTO `singleton` VALUES(300, 'venue', '2013-04-07 10:59:10', '2013-04-07 10:59:10', NULL);
INSERT INTO `singleton` VALUES(301, 'venue', '2013-04-07 10:59:10', '2013-04-07 10:59:10', NULL);
INSERT INTO `singleton` VALUES(302, 'venue', '2013-04-07 10:59:10', '2013-04-07 10:59:10', NULL);
INSERT INTO `singleton` VALUES(303, 'venue', '2013-04-07 10:59:10', '2013-04-07 10:59:10', NULL);
INSERT INTO `singleton` VALUES(304, 'venue', '2013-04-07 10:59:10', '2013-04-07 10:59:10', NULL);
INSERT INTO `singleton` VALUES(305, 'venue', '2013-04-07 10:59:10', '2013-04-07 10:59:10', NULL);
INSERT INTO `singleton` VALUES(306, 'venue', '2013-04-07 10:59:11', '2013-04-07 10:59:11', NULL);
INSERT INTO `singleton` VALUES(307, 'venue', '2013-04-07 10:59:11', '2013-04-07 10:59:11', NULL);
INSERT INTO `singleton` VALUES(308, 'venue', '2013-04-07 10:59:11', '2013-04-07 10:59:11', NULL);
INSERT INTO `singleton` VALUES(309, 'venue', '2013-04-07 10:59:11', '2013-04-07 10:59:11', NULL);
INSERT INTO `singleton` VALUES(310, 'venue', '2013-04-07 10:59:11', '2013-04-07 10:59:11', NULL);
INSERT INTO `singleton` VALUES(311, 'venue', '2013-04-07 10:59:11', '2013-04-07 10:59:11', NULL);
INSERT INTO `singleton` VALUES(312, 'venue', '2013-04-07 10:59:12', '2013-04-07 10:59:12', NULL);
INSERT INTO `singleton` VALUES(313, 'venue', '2013-04-07 10:59:12', '2013-04-07 10:59:12', NULL);
INSERT INTO `singleton` VALUES(314, 'venue', '2013-04-07 10:59:12', '2013-04-07 10:59:12', NULL);
INSERT INTO `singleton` VALUES(315, 'venue', '2013-04-07 10:59:12', '2013-04-07 10:59:12', NULL);
INSERT INTO `singleton` VALUES(316, 'venue', '2013-04-07 10:59:12', '2013-04-07 10:59:12', NULL);
INSERT INTO `singleton` VALUES(317, 'venue', '2013-04-07 10:59:13', '2013-04-07 10:59:13', NULL);
INSERT INTO `singleton` VALUES(318, 'venue', '2013-04-07 10:59:13', '2013-04-07 10:59:13', NULL);
INSERT INTO `singleton` VALUES(319, 'venue', '2013-04-07 10:59:15', '2013-04-07 10:59:15', NULL);
INSERT INTO `singleton` VALUES(320, 'venue', '2013-04-07 10:59:15', '2013-04-07 10:59:15', NULL);
INSERT INTO `singleton` VALUES(321, 'venue', '2013-04-07 10:59:15', '2013-04-07 10:59:15', NULL);
INSERT INTO `singleton` VALUES(322, 'venue', '2013-04-07 10:59:15', '2013-04-07 10:59:15', NULL);
INSERT INTO `singleton` VALUES(323, 'venue', '2013-04-07 10:59:15', '2013-04-07 10:59:15', NULL);
INSERT INTO `singleton` VALUES(324, 'venue', '2013-04-07 10:59:16', '2013-04-07 10:59:16', NULL);
INSERT INTO `singleton` VALUES(325, 'venue', '2013-04-07 10:59:17', '2013-04-07 10:59:17', NULL);
INSERT INTO `singleton` VALUES(326, 'venue', '2013-04-07 10:59:17', '2013-04-07 10:59:17', NULL);
INSERT INTO `singleton` VALUES(327, 'venue', '2013-04-07 10:59:19', '2013-04-07 10:59:19', NULL);
INSERT INTO `singleton` VALUES(328, 'venue', '2013-04-07 10:59:20', '2013-04-07 10:59:20', NULL);
INSERT INTO `singleton` VALUES(329, 'venue', '2013-04-07 10:59:23', '2013-04-07 10:59:23', NULL);
INSERT INTO `singleton` VALUES(330, 'venue', '2013-04-07 10:59:23', '2013-04-07 10:59:23', NULL);
INSERT INTO `singleton` VALUES(331, 'venue', '2013-04-07 10:59:23', '2013-04-07 10:59:23', NULL);
INSERT INTO `singleton` VALUES(332, 'venue', '2013-04-07 10:59:23', '2013-04-07 10:59:23', NULL);
INSERT INTO `singleton` VALUES(333, 'venue', '2013-04-07 10:59:23', '2013-04-07 10:59:23', NULL);
INSERT INTO `singleton` VALUES(334, 'venue', '2013-04-07 10:59:23', '2013-04-07 10:59:23', NULL);
INSERT INTO `singleton` VALUES(335, 'venue', '2013-04-07 10:59:24', '2013-04-07 10:59:24', NULL);
INSERT INTO `singleton` VALUES(336, 'venue', '2013-04-07 10:59:25', '2013-04-07 10:59:25', NULL);
INSERT INTO `singleton` VALUES(337, 'venue', '2013-04-07 10:59:26', '2013-04-07 10:59:26', NULL);
INSERT INTO `singleton` VALUES(338, 'venue', '2013-04-07 10:59:26', '2013-04-07 10:59:26', NULL);
INSERT INTO `singleton` VALUES(339, 'venue', '2013-04-07 10:59:26', '2013-04-07 10:59:26', NULL);
INSERT INTO `singleton` VALUES(340, 'venue', '2013-04-07 10:59:26', '2013-04-07 10:59:26', NULL);
INSERT INTO `singleton` VALUES(341, 'venue', '2013-04-07 10:59:27', '2013-04-07 10:59:27', NULL);
INSERT INTO `singleton` VALUES(342, 'venue', '2013-04-07 10:59:27', '2013-04-07 10:59:27', NULL);
INSERT INTO `singleton` VALUES(343, 'venue', '2013-04-07 10:59:28', '2013-04-07 10:59:28', NULL);
INSERT INTO `singleton` VALUES(344, 'venue', '2013-04-07 10:59:31', '2013-04-07 10:59:31', NULL);
INSERT INTO `singleton` VALUES(345, 'venue', '2013-04-07 10:59:31', '2013-04-07 10:59:31', NULL);
INSERT INTO `singleton` VALUES(346, 'venue', '2013-04-07 10:59:31', '2013-04-07 10:59:31', NULL);
INSERT INTO `singleton` VALUES(347, 'venue', '2013-04-07 10:59:31', '2013-04-07 10:59:31', NULL);
INSERT INTO `singleton` VALUES(348, 'venue', '2013-04-07 10:59:32', '2013-04-07 10:59:32', NULL);
INSERT INTO `singleton` VALUES(349, 'venue', '2013-04-07 10:59:32', '2013-04-07 10:59:32', NULL);
INSERT INTO `singleton` VALUES(350, 'venue', '2013-04-07 10:59:32', '2013-04-07 10:59:32', NULL);
INSERT INTO `singleton` VALUES(351, 'venue', '2013-04-07 10:59:32', '2013-04-07 10:59:32', NULL);
INSERT INTO `singleton` VALUES(352, 'venue', '2013-04-07 11:06:03', '2013-04-07 11:06:03', NULL);
INSERT INTO `singleton` VALUES(353, 'venue', '2013-04-07 11:06:06', '2013-04-07 11:06:06', NULL);
INSERT INTO `singleton` VALUES(354, 'venue', '2013-04-07 11:06:07', '2013-04-07 11:06:07', NULL);
INSERT INTO `singleton` VALUES(355, 'venue', '2013-04-07 11:06:10', '2013-04-07 11:06:10', NULL);
INSERT INTO `singleton` VALUES(356, 'venue', '2013-04-07 11:06:11', '2013-04-07 11:06:11', NULL);
INSERT INTO `singleton` VALUES(357, 'venue', '2013-04-07 11:06:12', '2013-04-07 11:06:12', NULL);
INSERT INTO `singleton` VALUES(358, 'venue', '2013-04-07 11:06:12', '2013-04-07 11:06:12', NULL);
INSERT INTO `singleton` VALUES(359, 'venue', '2013-04-07 11:06:15', '2013-04-07 11:06:15', NULL);
INSERT INTO `singleton` VALUES(360, 'venue', '2013-04-07 11:06:17', '2013-04-07 11:06:17', NULL);
INSERT INTO `singleton` VALUES(361, 'venue', '2013-04-07 11:06:18', '2013-04-07 11:06:18', NULL);
INSERT INTO `singleton` VALUES(362, 'venue', '2013-04-07 11:06:20', '2013-04-07 11:06:20', NULL);
INSERT INTO `singleton` VALUES(363, 'venue', '2013-04-07 11:06:22', '2013-04-07 11:06:22', NULL);
INSERT INTO `singleton` VALUES(364, 'venue', '2013-04-07 11:06:26', '2013-04-07 11:06:26', NULL);
INSERT INTO `singleton` VALUES(365, 'venue', '2013-04-07 11:06:30', '2013-04-07 11:06:30', NULL);
INSERT INTO `singleton` VALUES(366, 'venue', '2013-04-07 11:06:31', '2013-04-07 11:06:31', NULL);
INSERT INTO `singleton` VALUES(367, 'venue', '2013-04-07 11:06:33', '2013-04-07 11:06:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `statistic`
--

CREATE TABLE `statistic` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `time_start` timestamp NULL DEFAULT NULL,
  `time_end` timestamp NULL DEFAULT NULL,
  `timespan` varchar(255) DEFAULT NULL,
  `object_type` varchar(32) DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `value` decimal(15,2) DEFAULT NULL,
  `text_value` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `statistic`
--


-- --------------------------------------------------------

--
-- Table structure for table `tracking_cycle`
--

CREATE TABLE `tracking_cycle` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `object_id` int(12) NOT NULL,
  `frequency` enum('quaterday','hourly','daily','weekly','monthly','disabled') NOT NULL,
  `TZ` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `object_id` (`object_id`),
  KEY `frequency` (`frequency`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=368 ;

--
-- Dumping data for table `tracking_cycle`
--

INSERT INTO `tracking_cycle` VALUES(1, 1, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(2, 2, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(3, 3, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(4, 4, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(5, 5, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(6, 6, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(7, 7, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(8, 8, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(9, 9, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(10, 10, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(11, 11, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(12, 12, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(13, 13, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(14, 14, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(15, 15, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(16, 16, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(17, 17, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(18, 18, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(19, 19, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(20, 20, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(21, 21, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(22, 22, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(23, 23, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(24, 24, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(25, 25, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(26, 26, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(27, 27, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(28, 28, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(29, 29, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(30, 30, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(31, 31, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(32, 32, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(33, 33, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(34, 34, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(35, 35, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(36, 36, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(37, 37, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(38, 38, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(39, 39, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(40, 40, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(41, 41, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(42, 42, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(43, 43, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(44, 44, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(45, 45, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(46, 46, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(47, 47, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(48, 48, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(49, 49, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(50, 50, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(51, 51, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(52, 52, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(53, 53, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(54, 54, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(55, 55, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(56, 56, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(57, 57, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(58, 58, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(59, 59, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(60, 60, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(61, 61, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(62, 62, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(63, 63, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(64, 64, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(65, 65, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(66, 66, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(67, 67, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(68, 68, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(69, 69, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(70, 70, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(71, 71, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(72, 72, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(73, 73, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(74, 74, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(75, 75, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(76, 76, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(77, 77, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(78, 78, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(79, 79, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(80, 80, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(81, 81, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(82, 82, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(83, 83, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(84, 84, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(85, 85, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(86, 86, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(87, 87, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(88, 88, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(89, 89, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(90, 90, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(91, 91, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(92, 92, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(93, 93, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(94, 94, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(95, 95, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(96, 96, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(97, 97, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(98, 98, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(99, 99, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(100, 100, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(101, 101, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(102, 102, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(103, 103, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(104, 104, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(105, 105, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(106, 106, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(107, 107, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(108, 108, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(109, 109, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(110, 110, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(111, 111, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(112, 112, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(113, 113, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(114, 114, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(115, 115, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(116, 116, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(117, 117, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(118, 118, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(119, 119, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(120, 120, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(121, 121, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(122, 122, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(123, 123, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(124, 124, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(125, 125, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(126, 126, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(127, 127, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(128, 128, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(129, 129, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(130, 130, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(131, 131, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(132, 132, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(133, 133, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(134, 134, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(135, 135, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(136, 136, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(137, 137, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(138, 138, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(139, 139, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(140, 140, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(141, 141, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(142, 142, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(143, 143, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(144, 144, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(145, 145, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(146, 146, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(147, 147, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(148, 148, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(149, 149, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(150, 150, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(151, 151, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(152, 152, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(153, 153, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(154, 154, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(155, 155, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(156, 156, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(157, 157, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(158, 158, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(159, 159, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(160, 160, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(161, 161, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(162, 162, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(163, 163, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(164, 164, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(165, 165, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(166, 166, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(167, 167, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(168, 168, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(169, 169, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(170, 170, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(171, 171, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(172, 172, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(173, 173, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(174, 174, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(175, 175, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(176, 176, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(177, 177, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(178, 178, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(179, 179, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(180, 180, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(181, 181, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(182, 182, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(183, 183, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(184, 184, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(185, 185, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(186, 186, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(187, 187, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(188, 188, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(189, 189, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(190, 190, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(191, 191, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(192, 192, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(193, 193, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(194, 194, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(195, 195, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(196, 196, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(197, 197, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(198, 198, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(199, 199, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(200, 200, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(201, 201, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(202, 202, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(203, 203, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(204, 204, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(205, 205, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(206, 206, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(207, 207, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(208, 208, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(209, 209, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(210, 210, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(211, 211, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(212, 212, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(213, 213, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(214, 214, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(215, 215, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(216, 216, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(217, 217, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(218, 218, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(219, 219, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(220, 220, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(221, 221, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(222, 222, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(223, 223, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(224, 224, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(225, 225, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(226, 226, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(227, 227, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(228, 228, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(229, 229, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(230, 230, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(231, 231, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(232, 232, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(233, 233, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(234, 234, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(235, 235, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(236, 236, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(237, 237, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(238, 238, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(239, 239, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(240, 240, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(241, 241, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(242, 242, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(243, 243, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(244, 244, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(245, 245, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(246, 246, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(247, 247, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(248, 248, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(249, 249, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(250, 250, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(251, 251, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(252, 252, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(253, 253, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(254, 254, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(255, 255, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(256, 256, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(257, 257, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(258, 258, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(259, 259, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(260, 260, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(261, 261, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(262, 262, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(263, 263, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(264, 264, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(265, 265, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(266, 266, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(267, 267, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(268, 268, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(269, 269, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(270, 270, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(271, 271, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(272, 272, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(273, 273, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(274, 274, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(275, 275, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(276, 276, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(277, 277, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(278, 278, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(279, 279, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(280, 280, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(281, 281, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(282, 282, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(283, 283, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(284, 284, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(285, 285, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(286, 286, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(287, 287, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(288, 288, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(289, 289, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(290, 290, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(291, 291, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(292, 292, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(293, 293, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(294, 294, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(295, 295, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(296, 296, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(297, 297, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(298, 298, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(299, 299, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(300, 300, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(301, 301, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(302, 302, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(303, 303, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(304, 304, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(305, 305, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(306, 306, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(307, 307, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(308, 308, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(309, 309, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(310, 310, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(311, 311, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(312, 312, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(313, 313, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(314, 314, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(315, 315, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(316, 316, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(317, 317, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(318, 318, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(319, 319, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(320, 320, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(321, 321, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(322, 322, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(323, 323, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(324, 324, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(325, 325, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(326, 326, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(327, 327, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(328, 328, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(329, 329, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(330, 330, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(331, 331, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(332, 332, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(333, 333, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(334, 334, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(335, 335, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(336, 336, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(337, 337, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(338, 338, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(339, 339, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(340, 340, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(341, 341, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(342, 342, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(343, 343, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(344, 344, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(345, 345, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(346, 346, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(347, 347, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(348, 348, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(349, 349, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(350, 350, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(351, 351, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(352, 352, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(353, 353, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(354, 354, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(355, 355, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(356, 356, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(357, 357, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(358, 358, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(359, 359, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(360, 360, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(361, 361, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(362, 362, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(363, 363, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(364, 364, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(365, 365, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(366, 366, 'hourly', NULL);
INSERT INTO `tracking_cycle` VALUES(367, 367, 'hourly', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tracking_log`
--

CREATE TABLE `tracking_log` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `object_id` int(12) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT '0',
  `is_latest` tinyint(1) NOT NULL DEFAULT '0',
  `source` enum('instagram','foursquare') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `is_latest` (`is_latest`),
  KEY `object_id` (`object_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=368 ;

--
-- Dumping data for table `tracking_log`
--

INSERT INTO `tracking_log` VALUES(1, 1, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(2, 2, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(3, 3, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(4, 4, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(5, 5, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(6, 6, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(7, 7, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(8, 8, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(9, 9, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(10, 10, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(11, 11, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(12, 12, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(13, 13, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(14, 14, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(15, 15, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(16, 16, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(17, 17, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(18, 18, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(19, 19, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(20, 20, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(21, 21, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(22, 22, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(23, 23, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(24, 24, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(25, 25, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(26, 26, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(27, 27, '2013-04-06 17:57:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(28, 28, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(29, 29, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(30, 30, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(31, 31, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(32, 32, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(33, 33, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(34, 34, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(35, 35, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(36, 36, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(37, 37, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(38, 38, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(39, 39, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(40, 40, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(41, 41, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(42, 42, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(43, 43, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(44, 44, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(45, 45, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(46, 46, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(47, 47, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(48, 48, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(49, 49, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(50, 50, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(51, 51, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(52, 52, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(53, 53, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(54, 54, '2013-04-06 17:57:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(55, 55, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(56, 56, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(57, 57, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(58, 58, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(59, 59, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(60, 60, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(61, 61, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(62, 62, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(63, 63, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(64, 64, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(65, 65, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(66, 66, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(67, 67, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(68, 68, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(69, 69, '2013-04-06 17:57:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(70, 70, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(71, 71, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(72, 72, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(73, 73, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(74, 74, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(75, 75, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(76, 76, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(77, 77, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(78, 78, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(79, 79, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(80, 80, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(81, 81, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(82, 82, '2013-04-06 17:57:21', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(83, 83, '2013-04-06 17:57:22', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(84, 84, '2013-04-06 17:57:23', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(85, 85, '2013-04-06 17:57:23', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(86, 86, '2013-04-06 17:57:24', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(87, 87, '2013-04-06 17:57:24', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(88, 88, '2013-04-06 17:57:24', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(89, 89, '2013-04-06 17:57:24', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(90, 90, '2013-04-06 17:57:25', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(91, 91, '2013-04-06 17:57:27', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(92, 92, '2013-04-06 17:57:27', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(93, 93, '2013-04-06 17:57:28', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(94, 94, '2013-04-06 17:57:28', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(95, 95, '2013-04-06 17:57:28', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(96, 96, '2013-04-06 17:57:33', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(97, 97, '2013-04-06 17:57:33', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(98, 98, '2013-04-06 17:57:34', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(99, 99, '2013-04-06 17:57:34', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(100, 100, '2013-04-06 17:57:35', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(101, 101, '2013-04-06 17:57:35', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(102, 102, '2013-04-06 17:57:35', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(103, 103, '2013-04-06 17:57:35', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(104, 104, '2013-04-06 17:57:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(105, 105, '2013-04-06 17:57:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(106, 106, '2013-04-06 17:57:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(107, 107, '2013-04-06 17:57:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(108, 108, '2013-04-06 17:57:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(109, 109, '2013-04-06 17:57:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(110, 110, '2013-04-06 17:57:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(111, 111, '2013-04-06 17:57:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(112, 112, '2013-04-06 17:57:37', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(113, 113, '2013-04-06 17:57:37', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(114, 114, '2013-04-06 17:57:37', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(115, 115, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(116, 116, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(117, 117, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(118, 118, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(119, 119, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(120, 120, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(121, 121, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(122, 122, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(123, 123, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(124, 124, '2013-04-06 17:58:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(125, 125, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(126, 126, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(127, 127, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(128, 128, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(129, 129, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(130, 130, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(131, 131, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(132, 132, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(133, 133, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(134, 134, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(135, 135, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(136, 136, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(137, 137, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(138, 138, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(139, 139, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(140, 140, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(141, 141, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(142, 142, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(143, 143, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(144, 144, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(145, 145, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(146, 146, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(147, 147, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(148, 148, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(149, 149, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(150, 150, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(151, 151, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(152, 152, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(153, 153, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(154, 154, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(155, 155, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(156, 156, '2013-04-06 17:58:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(157, 157, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(158, 158, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(159, 159, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(160, 160, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(161, 161, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(162, 162, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(163, 163, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(164, 164, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(165, 165, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(166, 166, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(167, 167, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(168, 168, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(169, 169, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(170, 170, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(171, 171, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(172, 172, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(173, 173, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(174, 174, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(175, 175, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(176, 176, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(177, 177, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(178, 178, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(179, 179, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(180, 180, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(181, 181, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(182, 182, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(183, 183, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(184, 184, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(185, 185, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(186, 186, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(187, 187, '2013-04-06 17:58:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(188, 188, '2013-04-07 10:58:34', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(189, 189, '2013-04-07 10:58:34', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(190, 190, '2013-04-07 10:58:35', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(191, 191, '2013-04-07 10:58:35', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(192, 192, '2013-04-07 10:58:35', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(193, 193, '2013-04-07 10:58:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(194, 194, '2013-04-07 10:58:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(195, 195, '2013-04-07 10:58:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(196, 196, '2013-04-07 10:58:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(197, 197, '2013-04-07 10:58:36', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(198, 198, '2013-04-07 10:58:37', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(199, 199, '2013-04-07 10:58:37', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(200, 200, '2013-04-07 10:58:37', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(201, 201, '2013-04-07 10:58:37', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(202, 202, '2013-04-07 10:58:37', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(203, 203, '2013-04-07 10:58:38', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(204, 204, '2013-04-07 10:58:38', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(205, 205, '2013-04-07 10:58:38', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(206, 206, '2013-04-07 10:58:38', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(207, 207, '2013-04-07 10:58:38', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(208, 208, '2013-04-07 10:58:38', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(209, 209, '2013-04-07 10:58:38', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(210, 210, '2013-04-07 10:58:39', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(211, 211, '2013-04-07 10:58:40', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(212, 212, '2013-04-07 10:58:40', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(213, 213, '2013-04-07 10:58:41', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(214, 214, '2013-04-07 10:58:41', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(215, 215, '2013-04-07 10:58:43', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(216, 216, '2013-04-07 10:58:43', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(217, 217, '2013-04-07 10:58:43', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(218, 218, '2013-04-07 10:58:45', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(219, 219, '2013-04-07 10:58:45', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(220, 220, '2013-04-07 10:58:46', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(221, 221, '2013-04-07 10:58:47', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(222, 222, '2013-04-07 10:58:48', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(223, 223, '2013-04-07 10:58:49', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(224, 224, '2013-04-07 10:58:50', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(225, 225, '2013-04-07 10:58:52', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(226, 226, '2013-04-07 10:58:53', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(227, 227, '2013-04-07 10:58:55', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(228, 228, '2013-04-07 10:58:56', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(229, 229, '2013-04-07 10:58:57', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(230, 230, '2013-04-07 10:58:58', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(231, 231, '2013-04-07 10:58:59', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(232, 232, '2013-04-07 10:58:59', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(233, 233, '2013-04-07 10:58:59', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(234, 234, '2013-04-07 10:59:00', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(235, 235, '2013-04-07 10:59:00', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(236, 236, '2013-04-07 10:59:00', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(237, 237, '2013-04-07 10:59:00', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(238, 238, '2013-04-07 10:59:01', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(239, 239, '2013-04-07 10:59:01', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(240, 240, '2013-04-07 10:59:01', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(241, 241, '2013-04-07 10:59:02', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(242, 242, '2013-04-07 10:59:02', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(243, 243, '2013-04-07 10:59:02', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(244, 244, '2013-04-07 10:59:02', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(245, 245, '2013-04-07 10:59:02', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(246, 246, '2013-04-07 10:59:02', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(247, 247, '2013-04-07 10:59:02', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(248, 248, '2013-04-07 10:59:02', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(249, 249, '2013-04-07 10:59:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(250, 250, '2013-04-07 10:59:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(251, 251, '2013-04-07 10:59:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(252, 252, '2013-04-07 10:59:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(253, 253, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(254, 254, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(255, 255, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(256, 256, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(257, 257, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(258, 258, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(259, 259, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(260, 260, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(261, 261, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(262, 262, '2013-04-07 10:59:04', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(263, 263, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(264, 264, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(265, 265, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(266, 266, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(267, 267, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(268, 268, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(269, 269, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(270, 270, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(271, 271, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(272, 272, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(273, 273, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(274, 274, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(275, 275, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(276, 276, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(277, 277, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(278, 278, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(279, 279, '2013-04-07 10:59:05', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(280, 280, '2013-04-07 10:59:06', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(281, 281, '2013-04-07 10:59:06', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(282, 282, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(283, 283, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(284, 284, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(285, 285, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(286, 286, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(287, 287, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(288, 288, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(289, 289, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(290, 290, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(291, 291, '2013-04-07 10:59:08', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(292, 292, '2013-04-07 10:59:09', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(293, 293, '2013-04-07 10:59:09', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(294, 294, '2013-04-07 10:59:09', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(295, 295, '2013-04-07 10:59:09', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(296, 296, '2013-04-07 10:59:09', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(297, 297, '2013-04-07 10:59:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(298, 298, '2013-04-07 10:59:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(299, 299, '2013-04-07 10:59:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(300, 300, '2013-04-07 10:59:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(301, 301, '2013-04-07 10:59:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(302, 302, '2013-04-07 10:59:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(303, 303, '2013-04-07 10:59:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(304, 304, '2013-04-07 10:59:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(305, 305, '2013-04-07 10:59:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(306, 306, '2013-04-07 10:59:11', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(307, 307, '2013-04-07 10:59:11', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(308, 308, '2013-04-07 10:59:11', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(309, 309, '2013-04-07 10:59:11', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(310, 310, '2013-04-07 10:59:11', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(311, 311, '2013-04-07 10:59:11', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(312, 312, '2013-04-07 10:59:12', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(313, 313, '2013-04-07 10:59:12', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(314, 314, '2013-04-07 10:59:12', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(315, 315, '2013-04-07 10:59:12', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(316, 316, '2013-04-07 10:59:12', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(317, 317, '2013-04-07 10:59:13', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(318, 318, '2013-04-07 10:59:13', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(319, 319, '2013-04-07 10:59:15', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(320, 320, '2013-04-07 10:59:15', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(321, 321, '2013-04-07 10:59:15', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(322, 322, '2013-04-07 10:59:15', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(323, 323, '2013-04-07 10:59:15', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(324, 324, '2013-04-07 10:59:16', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(325, 325, '2013-04-07 10:59:17', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(326, 326, '2013-04-07 10:59:17', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(327, 327, '2013-04-07 10:59:19', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(328, 328, '2013-04-07 10:59:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(329, 329, '2013-04-07 10:59:23', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(330, 330, '2013-04-07 10:59:23', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(331, 331, '2013-04-07 10:59:23', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(332, 332, '2013-04-07 10:59:23', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(333, 333, '2013-04-07 10:59:23', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(334, 334, '2013-04-07 10:59:23', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(335, 335, '2013-04-07 10:59:25', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(336, 336, '2013-04-07 10:59:26', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(337, 337, '2013-04-07 10:59:26', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(338, 338, '2013-04-07 10:59:26', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(339, 339, '2013-04-07 10:59:26', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(340, 340, '2013-04-07 10:59:26', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(341, 341, '2013-04-07 10:59:27', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(342, 342, '2013-04-07 10:59:27', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(343, 343, '2013-04-07 10:59:28', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(344, 344, '2013-04-07 10:59:31', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(345, 345, '2013-04-07 10:59:31', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(346, 346, '2013-04-07 10:59:31', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(347, 347, '2013-04-07 10:59:32', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(348, 348, '2013-04-07 10:59:32', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(349, 349, '2013-04-07 10:59:32', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(350, 350, '2013-04-07 10:59:32', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(351, 351, '2013-04-07 10:59:32', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(352, 352, '2013-04-07 11:06:03', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(353, 353, '2013-04-07 11:06:06', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(354, 354, '2013-04-07 11:06:07', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(355, 355, '2013-04-07 11:06:10', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(356, 356, '2013-04-07 11:06:11', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(357, 357, '2013-04-07 11:06:12', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(358, 358, '2013-04-07 11:06:12', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(359, 359, '2013-04-07 11:06:15', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(360, 360, '2013-04-07 11:06:17', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(361, 361, '2013-04-07 11:06:18', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(362, 362, '2013-04-07 11:06:20', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(363, 363, '2013-04-07 11:06:22', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(364, 364, '2013-04-07 11:06:26', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(365, 365, '2013-04-07 11:06:30', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(366, 366, '2013-04-07 11:06:31', 1, 1, 'foursquare');
INSERT INTO `tracking_log` VALUES(367, 367, '2013-04-07 11:06:33', 1, 1, 'foursquare');

-- --------------------------------------------------------

--
-- Table structure for table `tracking_log_ratelimit`
--

CREATE TABLE `tracking_log_ratelimit` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `service` enum('foursquare','instagram') NOT NULL,
  `limit` int(11) DEFAULT '0',
  `remaining` int(11) DEFAULT NULL,
  `response` text,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=293 ;

--
-- Dumping data for table `tracking_log_ratelimit`
--

INSERT INTO `tracking_log_ratelimit` VALUES(1, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:22 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 133\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 595\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:22');
INSERT INTO `tracking_log_ratelimit` VALUES(2, 'foursquare', 500, 367, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:22 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 73\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 367\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:22');
INSERT INTO `tracking_log_ratelimit` VALUES(3, 'foursquare', 500, 366, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:22 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 128\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 366\r\nContent-Length: 613\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:22');
INSERT INTO `tracking_log_ratelimit` VALUES(4, 'foursquare', 500, 365, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:23 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 155\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 365\r\nContent-Length: 835\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:23');
INSERT INTO `tracking_log_ratelimit` VALUES(5, 'foursquare', 500, 364, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:23 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 62\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 364\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:23');
INSERT INTO `tracking_log_ratelimit` VALUES(6, 'foursquare', 500, 363, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:23 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 81\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 363\r\nContent-Length: 543\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:23');
INSERT INTO `tracking_log_ratelimit` VALUES(7, 'foursquare', 500, 362, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:24 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 116\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 362\r\nContent-Length: 578\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:24');
INSERT INTO `tracking_log_ratelimit` VALUES(8, 'foursquare', 500, 361, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:24 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 108\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 361\r\nContent-Length: 943\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:24');
INSERT INTO `tracking_log_ratelimit` VALUES(9, 'foursquare', 500, 360, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:24 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 26\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 360\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:24');
INSERT INTO `tracking_log_ratelimit` VALUES(10, 'foursquare', 500, 359, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:25 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 128\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 359\r\nContent-Length: 783\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:25');
INSERT INTO `tracking_log_ratelimit` VALUES(11, 'foursquare', 500, 358, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:25 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 157\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 358\r\nContent-Length: 589\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:25');
INSERT INTO `tracking_log_ratelimit` VALUES(12, 'foursquare', 500, 357, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:25 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 133\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 357\r\nContent-Length: 993\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:25');
INSERT INTO `tracking_log_ratelimit` VALUES(13, 'foursquare', 500, 356, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:25 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 108\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 356\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:25');
INSERT INTO `tracking_log_ratelimit` VALUES(14, 'foursquare', 500, 355, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:26 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:26 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 44\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 355\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:26');
INSERT INTO `tracking_log_ratelimit` VALUES(15, 'foursquare', 500, 354, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:27 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 44\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 354\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:27');
INSERT INTO `tracking_log_ratelimit` VALUES(16, 'foursquare', 500, 353, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:27 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 39\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 353\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:27');
INSERT INTO `tracking_log_ratelimit` VALUES(17, 'foursquare', 500, 352, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:27 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 91\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 352\r\nContent-Length: 568\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:27');
INSERT INTO `tracking_log_ratelimit` VALUES(18, 'foursquare', 500, 351, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:27 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 111\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 351\r\nContent-Length: 874\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:27');
INSERT INTO `tracking_log_ratelimit` VALUES(19, 'foursquare', 500, 350, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:28 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:28 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 117\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 350\r\nContent-Length: 670\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:28');
INSERT INTO `tracking_log_ratelimit` VALUES(20, 'foursquare', 500, 349, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:28 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:28 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 53\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 349\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:28');
INSERT INTO `tracking_log_ratelimit` VALUES(21, 'foursquare', 500, 348, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:28 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:28 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 95\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 348\r\nContent-Length: 687\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:28');
INSERT INTO `tracking_log_ratelimit` VALUES(22, 'foursquare', 500, 347, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:29 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:29 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 521\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 347\r\nContent-Length: 562\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:29');
INSERT INTO `tracking_log_ratelimit` VALUES(23, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:30 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 139\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 937\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:30');
INSERT INTO `tracking_log_ratelimit` VALUES(24, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:30 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 157\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 630\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:30');
INSERT INTO `tracking_log_ratelimit` VALUES(25, 'foursquare', 500, 345, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:31 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:31 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 93\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 345\r\nContent-Length: 599\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:31');
INSERT INTO `tracking_log_ratelimit` VALUES(26, 'foursquare', 500, 344, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:32 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:31 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 96\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 344\r\nContent-Length: 609\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:32');
INSERT INTO `tracking_log_ratelimit` VALUES(27, 'foursquare', 500, 343, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:33 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:33 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 111\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 343\r\nContent-Length: 605\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:33');
INSERT INTO `tracking_log_ratelimit` VALUES(28, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:33 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:33 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 121\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 500\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:33');
INSERT INTO `tracking_log_ratelimit` VALUES(29, 'foursquare', 500, 341, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:34 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 195\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 341\r\nContent-Length: 610\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:34');
INSERT INTO `tracking_log_ratelimit` VALUES(30, 'foursquare', 500, 340, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:34 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 122\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 340\r\nContent-Length: 557\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:34');
INSERT INTO `tracking_log_ratelimit` VALUES(31, 'foursquare', 500, 339, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:34 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 38\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 339\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:34');
INSERT INTO `tracking_log_ratelimit` VALUES(32, 'foursquare', 500, 338, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:35 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:35 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 140\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 338\r\nContent-Length: 721\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:35');
INSERT INTO `tracking_log_ratelimit` VALUES(33, 'foursquare', 500, 337, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:35 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:35 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 117\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 337\r\nContent-Length: 587\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:35');
INSERT INTO `tracking_log_ratelimit` VALUES(34, 'foursquare', 500, 336, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:35 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:35 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 133\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 336\r\nContent-Length: 639\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:35');
INSERT INTO `tracking_log_ratelimit` VALUES(35, 'foursquare', 500, 335, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:36 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:36 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 194\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 335\r\nContent-Length: 850\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:36');
INSERT INTO `tracking_log_ratelimit` VALUES(36, 'foursquare', 500, 334, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:36 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:36 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 120\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 334\r\nContent-Length: 1075\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:36');
INSERT INTO `tracking_log_ratelimit` VALUES(37, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:37 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:37 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 163\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 924\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:37');
INSERT INTO `tracking_log_ratelimit` VALUES(38, 'foursquare', 500, 332, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sat, 06 Apr 2013 21:57:37 GMT\r\nExpires: Sat, 6 Apr 2013 21:57:37 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 41\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 332\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-06 17:57:37');
INSERT INTO `tracking_log_ratelimit` VALUES(39, 'foursquare', 500, 499, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:35 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:35 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 52\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 499\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:34');
INSERT INTO `tracking_log_ratelimit` VALUES(40, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:35 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:35 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 53\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:34');
INSERT INTO `tracking_log_ratelimit` VALUES(41, 'foursquare', 500, 497, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:36 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:36 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 163\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 497\r\nContent-Length: 767\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:34');
INSERT INTO `tracking_log_ratelimit` VALUES(42, 'foursquare', 500, 496, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:36 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:36 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 126\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 496\r\nContent-Length: 768\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:35');
INSERT INTO `tracking_log_ratelimit` VALUES(43, 'foursquare', 500, 495, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:36 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:36 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 138\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 495\r\nContent-Length: 795\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:35');
INSERT INTO `tracking_log_ratelimit` VALUES(44, 'foursquare', 500, 494, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:37 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:37 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 131\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 494\r\nContent-Length: 611\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:35');
INSERT INTO `tracking_log_ratelimit` VALUES(45, 'foursquare', 500, 493, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:37 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:37 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 134\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 493\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:36');
INSERT INTO `tracking_log_ratelimit` VALUES(46, 'foursquare', 500, 492, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:37 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:37 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 177\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 492\r\nContent-Length: 1490\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:36');
INSERT INTO `tracking_log_ratelimit` VALUES(47, 'foursquare', 500, 491, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:38 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:38 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 116\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 491\r\nContent-Length: 576\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:36');
INSERT INTO `tracking_log_ratelimit` VALUES(48, 'foursquare', 500, 490, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:38 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:38 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 96\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 490\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:36');
INSERT INTO `tracking_log_ratelimit` VALUES(49, 'foursquare', 500, 489, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:38 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:38 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 230\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 489\r\nContent-Length: 1622\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:37');
INSERT INTO `tracking_log_ratelimit` VALUES(50, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:39 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:39 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 140\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 1264\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:38');
INSERT INTO `tracking_log_ratelimit` VALUES(51, 'foursquare', 500, 488, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:40 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:40 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 212\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 488\r\nContent-Length: 792\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:38');
INSERT INTO `tracking_log_ratelimit` VALUES(52, 'foursquare', 500, 487, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:40 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:40 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 171\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 487\r\nContent-Length: 621\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:39');
INSERT INTO `tracking_log_ratelimit` VALUES(53, 'foursquare', 500, 486, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:42 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:42 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 1235\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 486\r\nContent-Length: 894\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:40');
INSERT INTO `tracking_log_ratelimit` VALUES(54, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:42 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:42 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 129\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 771\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:41');
INSERT INTO `tracking_log_ratelimit` VALUES(55, 'foursquare', 500, 484, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:42 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:42 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 48\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 484\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:41');
INSERT INTO `tracking_log_ratelimit` VALUES(56, 'foursquare', 500, 483, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:42 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:42 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 53\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 483\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:41');
INSERT INTO `tracking_log_ratelimit` VALUES(57, 'foursquare', 500, 482, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:42 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:42 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 46\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 482\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:41');
INSERT INTO `tracking_log_ratelimit` VALUES(58, 'foursquare', 500, 481, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:43 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:43 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 52\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 481\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:41');
INSERT INTO `tracking_log_ratelimit` VALUES(59, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:43 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:43 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 129\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 811\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:42');
INSERT INTO `tracking_log_ratelimit` VALUES(60, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:44 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:44 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 241\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 777\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:43');
INSERT INTO `tracking_log_ratelimit` VALUES(61, 'foursquare', 500, 480, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:46 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:46 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 696\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 480\r\nContent-Length: 932\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:44');
INSERT INTO `tracking_log_ratelimit` VALUES(62, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:48 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:48 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 131\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 550\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:46');
INSERT INTO `tracking_log_ratelimit` VALUES(63, 'foursquare', 500, 478, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:49 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:49 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 55\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 478\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:47');
INSERT INTO `tracking_log_ratelimit` VALUES(64, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:49 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:49 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 118\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 812\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:48');
INSERT INTO `tracking_log_ratelimit` VALUES(65, 'foursquare', 500, 476, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:51 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:51 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 159\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 476\r\nContent-Length: 910\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:49');
INSERT INTO `tracking_log_ratelimit` VALUES(66, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:55 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:55 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 576\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 832\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:54');
INSERT INTO `tracking_log_ratelimit` VALUES(67, 'foursquare', 500, 475, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:59 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:59 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 79\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 475\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:57');
INSERT INTO `tracking_log_ratelimit` VALUES(68, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:59 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:59 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 55\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:57');
INSERT INTO `tracking_log_ratelimit` VALUES(69, 'foursquare', 500, 473, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:58:59 GMT\r\nExpires: Sun, 7 Apr 2013 14:58:59 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 155\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 473\r\nContent-Length: 933\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:58');
INSERT INTO `tracking_log_ratelimit` VALUES(70, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:00 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:00 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 130\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 1016\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:58:58');
INSERT INTO `tracking_log_ratelimit` VALUES(71, 'foursquare', 500, 472, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:01 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:01 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 268\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 472\r\nContent-Length: 692\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:00');
INSERT INTO `tracking_log_ratelimit` VALUES(72, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:02 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:02 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 132\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 785\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:00');
INSERT INTO `tracking_log_ratelimit` VALUES(73, 'foursquare', 500, 471, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:02 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:02 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 122\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 471\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:01');
INSERT INTO `tracking_log_ratelimit` VALUES(74, 'foursquare', 500, 470, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:02 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:02 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 168\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 470\r\nContent-Length: 960\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:01');
INSERT INTO `tracking_log_ratelimit` VALUES(75, 'foursquare', 500, 469, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:03 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:03 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 162\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 469\r\nContent-Length: 845\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:01');
INSERT INTO `tracking_log_ratelimit` VALUES(76, 'foursquare', 500, 468, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:03 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:03 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 212\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 468\r\nContent-Length: 1536\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:02');
INSERT INTO `tracking_log_ratelimit` VALUES(77, 'foursquare', 500, 467, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:03 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:03 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 52\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 467\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:02');
INSERT INTO `tracking_log_ratelimit` VALUES(78, 'foursquare', 500, 466, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:04 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:04 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 360\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 466\r\nContent-Length: 902\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:03');
INSERT INTO `tracking_log_ratelimit` VALUES(79, 'foursquare', 500, 465, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:04 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:04 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 106\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 465\r\nContent-Length: 816\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:03');
INSERT INTO `tracking_log_ratelimit` VALUES(80, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:04 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:04 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 218\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 585\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:03');
INSERT INTO `tracking_log_ratelimit` VALUES(81, 'foursquare', 500, 463, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:05 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:05 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 41\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 463\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:03');
INSERT INTO `tracking_log_ratelimit` VALUES(82, 'foursquare', 500, 462, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:05 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:05 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 101\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 462\r\nContent-Length: 1377\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:03');
INSERT INTO `tracking_log_ratelimit` VALUES(83, 'foursquare', 500, 461, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:05 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:05 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 145\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 461\r\nContent-Length: 1389\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:04');
INSERT INTO `tracking_log_ratelimit` VALUES(84, 'foursquare', 500, 460, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:06 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:06 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 215\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 460\r\nContent-Length: 3097\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:05');
INSERT INTO `tracking_log_ratelimit` VALUES(85, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:07 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:07 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 319\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 1269\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:05');
INSERT INTO `tracking_log_ratelimit` VALUES(86, 'foursquare', 500, 459, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:07 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:07 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 366\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 459\r\nContent-Length: 1170\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:06');
INSERT INTO `tracking_log_ratelimit` VALUES(87, 'foursquare', 500, 458, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:09 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:09 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 1512\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 458\r\nContent-Length: 1580\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:08');
INSERT INTO `tracking_log_ratelimit` VALUES(88, 'foursquare', 500, 457, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:09 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:09 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 123\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 457\r\nContent-Length: 1946\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:08');
INSERT INTO `tracking_log_ratelimit` VALUES(89, 'foursquare', 500, 456, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:10 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:10 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 173\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 456\r\nContent-Length: 824\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:08');
INSERT INTO `tracking_log_ratelimit` VALUES(90, 'foursquare', 500, 455, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:10 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:10 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 130\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 455\r\nContent-Length: 823\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:09');
INSERT INTO `tracking_log_ratelimit` VALUES(91, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:10 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:10 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 202\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 614\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:09');
INSERT INTO `tracking_log_ratelimit` VALUES(92, 'foursquare', 500, 454, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:11 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:11 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 308\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 454\r\nContent-Length: 1279\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:09');
INSERT INTO `tracking_log_ratelimit` VALUES(93, 'foursquare', 500, 453, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:11 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:11 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 147\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 453\r\ntransfer-encoding: chunked\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:10');
INSERT INTO `tracking_log_ratelimit` VALUES(94, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:11 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:11 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 152\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 579\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:10');
INSERT INTO `tracking_log_ratelimit` VALUES(95, 'foursquare', 500, 452, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:12 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:12 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 128\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 452\r\nContent-Length: 1111\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:10');
INSERT INTO `tracking_log_ratelimit` VALUES(96, 'foursquare', 500, 451, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:12 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:12 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 373\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 451\r\nContent-Length: 1250\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:11');
INSERT INTO `tracking_log_ratelimit` VALUES(97, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:13 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:13 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 162\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 783\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:12');
INSERT INTO `tracking_log_ratelimit` VALUES(98, 'foursquare', 500, 449, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:13 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:13 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 202\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 449\r\nContent-Length: 665\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:12');
INSERT INTO `tracking_log_ratelimit` VALUES(99, 'foursquare', 500, 448, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:14 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:14 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 100\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 448\r\nContent-Length: 540\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:12');
INSERT INTO `tracking_log_ratelimit` VALUES(100, 'foursquare', 500, 447, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:14 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:14 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 204\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 447\r\nContent-Length: 786\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:13');
INSERT INTO `tracking_log_ratelimit` VALUES(101, 'foursquare', 500, 446, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:14 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:14 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 101\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 446\r\nContent-Length: 626\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:13');
INSERT INTO `tracking_log_ratelimit` VALUES(102, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:15 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:15 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 159\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 790\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:14');
INSERT INTO `tracking_log_ratelimit` VALUES(103, 'foursquare', 500, 445, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:15 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:15 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 161\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 445\r\nContent-Length: 1340\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:14');
INSERT INTO `tracking_log_ratelimit` VALUES(104, 'foursquare', 500, 444, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:16 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:16 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 132\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 444\r\nContent-Length: 814\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:14');
INSERT INTO `tracking_log_ratelimit` VALUES(105, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:16 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:16 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 132\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 1179\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:15');
INSERT INTO `tracking_log_ratelimit` VALUES(106, 'foursquare', 500, 443, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:16 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:16 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 219\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 443\r\nContent-Length: 753\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:15');
INSERT INTO `tracking_log_ratelimit` VALUES(107, 'foursquare', 500, 442, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:17 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:17 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 196\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 442\r\nContent-Length: 1379\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:15');
INSERT INTO `tracking_log_ratelimit` VALUES(108, 'foursquare', 500, 441, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:17 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:17 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 165\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 441\r\nContent-Length: 1039\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:16');
INSERT INTO `tracking_log_ratelimit` VALUES(109, 'foursquare', 500, 440, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:17 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:17 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 157\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 440\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:16');
INSERT INTO `tracking_log_ratelimit` VALUES(110, 'foursquare', 500, 439, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:18 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:18 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 798\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 439\r\nContent-Length: 996\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:17');
INSERT INTO `tracking_log_ratelimit` VALUES(111, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:18 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:18 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 160\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 810\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:17');
INSERT INTO `tracking_log_ratelimit` VALUES(112, 'foursquare', 500, 438, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:19 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:19 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 148\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 438\r\nContent-Length: 1023\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:17');
INSERT INTO `tracking_log_ratelimit` VALUES(113, 'foursquare', 500, 437, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:19 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:19 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 195\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 437\r\nContent-Length: 1185\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:18');
INSERT INTO `tracking_log_ratelimit` VALUES(114, 'foursquare', 500, 436, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:19 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:19 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 122\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 436\r\nContent-Length: 2497\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:18');
INSERT INTO `tracking_log_ratelimit` VALUES(115, 'foursquare', 500, 435, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:20 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:20 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 209\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 435\r\nContent-Length: 3340\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:18');
INSERT INTO `tracking_log_ratelimit` VALUES(116, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:20 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:20 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 142\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 769\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:18');
INSERT INTO `tracking_log_ratelimit` VALUES(117, 'foursquare', 500, 434, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:20 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:20 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 482\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 434\r\nContent-Length: 1171\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:19');
INSERT INTO `tracking_log_ratelimit` VALUES(118, 'foursquare', 500, 433, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:21 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:21 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 164\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 433\r\nContent-Length: 1492\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:19');
INSERT INTO `tracking_log_ratelimit` VALUES(119, 'foursquare', 500, 432, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:21 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:21 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 402\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 432\r\nContent-Length: 1175\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:20');
INSERT INTO `tracking_log_ratelimit` VALUES(120, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:22 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 297\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 603\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:20');
INSERT INTO `tracking_log_ratelimit` VALUES(121, 'foursquare', 500, 431, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:22 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 220\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 431\r\nContent-Length: 1044\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:21');
INSERT INTO `tracking_log_ratelimit` VALUES(122, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:22 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 149\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 730\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:21');
INSERT INTO `tracking_log_ratelimit` VALUES(123, 'foursquare', 500, 430, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:23 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 253\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 430\r\nContent-Length: 771\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:21');
INSERT INTO `tracking_log_ratelimit` VALUES(124, 'foursquare', 500, 429, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:23 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 198\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 429\r\nContent-Length: 1458\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:22');
INSERT INTO `tracking_log_ratelimit` VALUES(125, 'foursquare', 500, 428, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:23 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 144\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 428\r\nContent-Length: 908\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:22');
INSERT INTO `tracking_log_ratelimit` VALUES(126, 'foursquare', 500, 427, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:23 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 60\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 427\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:22');
INSERT INTO `tracking_log_ratelimit` VALUES(127, 'foursquare', 500, 426, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:24 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 470\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 426\r\nContent-Length: 1209\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:23');
INSERT INTO `tracking_log_ratelimit` VALUES(128, 'foursquare', 500, 425, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:24 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 129\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 425\r\nContent-Length: 893\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:23');
INSERT INTO `tracking_log_ratelimit` VALUES(129, 'foursquare', 500, 424, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:25 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 51\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 424\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:23');
INSERT INTO `tracking_log_ratelimit` VALUES(130, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:25 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 77\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:23');
INSERT INTO `tracking_log_ratelimit` VALUES(131, 'foursquare', 500, 423, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:25 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 55\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 423\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:23');
INSERT INTO `tracking_log_ratelimit` VALUES(132, 'foursquare', 500, 422, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:25 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 171\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 422\r\nContent-Length: 1082\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:24');
INSERT INTO `tracking_log_ratelimit` VALUES(133, 'foursquare', 500, 421, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:27 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 246\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 421\r\nContent-Length: 781\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:26');
INSERT INTO `tracking_log_ratelimit` VALUES(134, 'foursquare', 500, 420, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:28 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:28 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 279\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 420\r\nContent-Length: 531\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:27');
INSERT INTO `tracking_log_ratelimit` VALUES(135, 'foursquare', 500, 419, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:28 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:28 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 174\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 419\r\nContent-Length: 598\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:27');
INSERT INTO `tracking_log_ratelimit` VALUES(136, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:29 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:29 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 558\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 626\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:28');
INSERT INTO `tracking_log_ratelimit` VALUES(137, 'foursquare', 500, 418, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:30 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 336\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 418\r\nContent-Length: 1179\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:28');
INSERT INTO `tracking_log_ratelimit` VALUES(138, 'foursquare', 500, 417, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:30 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 126\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 417\r\nContent-Length: 570\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:28');
INSERT INTO `tracking_log_ratelimit` VALUES(139, 'foursquare', 500, 416, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:30 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 122\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 416\r\nContent-Length: 825\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:29');
INSERT INTO `tracking_log_ratelimit` VALUES(140, 'foursquare', 500, 415, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:30 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 254\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 415\r\nContent-Length: 928\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:30');
INSERT INTO `tracking_log_ratelimit` VALUES(141, 'foursquare', 500, 414, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:32 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:32 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 400\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 414\r\nContent-Length: 917\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:31');
INSERT INTO `tracking_log_ratelimit` VALUES(142, 'foursquare', 500, 413, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:33 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:33 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 159\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 413\r\nContent-Length: 786\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:31');
INSERT INTO `tracking_log_ratelimit` VALUES(143, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:33 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:33 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 165\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 1635\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:31');
INSERT INTO `tracking_log_ratelimit` VALUES(144, 'foursquare', 500, 411, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:33 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:33 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 148\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 411\r\nContent-Length: 1145\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:32');
INSERT INTO `tracking_log_ratelimit` VALUES(145, 'foursquare', 500, 410, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:33 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:33 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 56\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 410\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:32');
INSERT INTO `tracking_log_ratelimit` VALUES(146, 'foursquare', 500, 409, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:34 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 188\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 409\r\nContent-Length: 1172\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:32');
INSERT INTO `tracking_log_ratelimit` VALUES(147, 'foursquare', 500, 408, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:34 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 360\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 408\r\nContent-Length: 1072\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:33');
INSERT INTO `tracking_log_ratelimit` VALUES(148, 'foursquare', 500, 407, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 14:59:35 GMT\r\nExpires: Sun, 7 Apr 2013 14:59:35 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 46\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 407\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 10:59:33');
INSERT INTO `tracking_log_ratelimit` VALUES(149, 'foursquare', 500, 406, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:04 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:04 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 50\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 406\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:03');
INSERT INTO `tracking_log_ratelimit` VALUES(150, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:04 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:04 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 40\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:03');
INSERT INTO `tracking_log_ratelimit` VALUES(151, 'foursquare', 500, 405, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:04 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:04 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 39\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 405\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:03');
INSERT INTO `tracking_log_ratelimit` VALUES(152, 'foursquare', 500, 404, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:05 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:05 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 120\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 404\r\nContent-Length: 617\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:03');
INSERT INTO `tracking_log_ratelimit` VALUES(153, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:05 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:05 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 97\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:03');
INSERT INTO `tracking_log_ratelimit` VALUES(154, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:05 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:05 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 38\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:04');
INSERT INTO `tracking_log_ratelimit` VALUES(155, 'foursquare', 500, 403, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:05 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:05 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 46\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 403\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:04');
INSERT INTO `tracking_log_ratelimit` VALUES(156, 'foursquare', 500, 402, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:05 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:05 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 87\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 402\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:04');
INSERT INTO `tracking_log_ratelimit` VALUES(157, 'foursquare', 500, 401, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:05 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:05 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 42\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 401\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:04');
INSERT INTO `tracking_log_ratelimit` VALUES(158, 'foursquare', 500, 400, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:06 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:06 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 32\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 400\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:04');
INSERT INTO `tracking_log_ratelimit` VALUES(159, 'foursquare', 500, 399, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:06 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:06 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 50\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 399\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:04');
INSERT INTO `tracking_log_ratelimit` VALUES(160, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:06 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:06 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 270\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:05');
INSERT INTO `tracking_log_ratelimit` VALUES(161, 'foursquare', 500, 397, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:06 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:06 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 39\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 397\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:05');
INSERT INTO `tracking_log_ratelimit` VALUES(162, 'foursquare', 500, 396, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:06 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:06 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 34\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 396\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:05');
INSERT INTO `tracking_log_ratelimit` VALUES(163, 'foursquare', 500, 395, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:06 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:06 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 118\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 395\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:05');
INSERT INTO `tracking_log_ratelimit` VALUES(164, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:07 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:07 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 41\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:05');
INSERT INTO `tracking_log_ratelimit` VALUES(165, 'foursquare', 500, 393, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:07 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:07 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 52\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 393\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:05');
INSERT INTO `tracking_log_ratelimit` VALUES(166, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:07 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:07 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 71\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:06');
INSERT INTO `tracking_log_ratelimit` VALUES(167, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:07 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:07 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 65\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:06');
INSERT INTO `tracking_log_ratelimit` VALUES(168, 'foursquare', 500, 390, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:07 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:07 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 109\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 390\r\nContent-Length: 543\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:06');
INSERT INTO `tracking_log_ratelimit` VALUES(169, 'foursquare', 500, 389, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:08 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:08 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 389\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:06');
INSERT INTO `tracking_log_ratelimit` VALUES(170, 'foursquare', 500, 388, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:08 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:08 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 72\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 388\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:06');
INSERT INTO `tracking_log_ratelimit` VALUES(171, 'foursquare', 500, 387, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:08 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:08 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 42\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 387\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:06');
INSERT INTO `tracking_log_ratelimit` VALUES(172, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:08 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:08 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 40\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:07');
INSERT INTO `tracking_log_ratelimit` VALUES(173, 'foursquare', 500, 386, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:08 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:08 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 49\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 386\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:07');
INSERT INTO `tracking_log_ratelimit` VALUES(174, 'foursquare', 500, 385, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:08 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:08 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 47\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 385\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:07');
INSERT INTO `tracking_log_ratelimit` VALUES(175, 'foursquare', 500, 384, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:08 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:08 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 48\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 384\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:07');
INSERT INTO `tracking_log_ratelimit` VALUES(176, 'foursquare', 500, 383, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:08 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:08 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 73\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 383\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:07');
INSERT INTO `tracking_log_ratelimit` VALUES(177, 'foursquare', 500, 382, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:09 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:09 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 117\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 382\r\nContent-Length: 592\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:07');
INSERT INTO `tracking_log_ratelimit` VALUES(178, 'foursquare', 500, 381, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:09 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:09 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 106\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 381\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:07');
INSERT INTO `tracking_log_ratelimit` VALUES(179, 'foursquare', 500, 380, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:09 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:09 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 41\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 380\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:08');
INSERT INTO `tracking_log_ratelimit` VALUES(180, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:09 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:09 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 36\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:08');
INSERT INTO `tracking_log_ratelimit` VALUES(181, 'foursquare', 500, 379, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:10 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:10 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 47\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 379\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:08');
INSERT INTO `tracking_log_ratelimit` VALUES(182, 'foursquare', 500, 378, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:10 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:10 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 378\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:08');
INSERT INTO `tracking_log_ratelimit` VALUES(183, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:10 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:10 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 61\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:09');
INSERT INTO `tracking_log_ratelimit` VALUES(184, 'foursquare', 500, 376, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:10 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:10 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 34\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 376\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:09');
INSERT INTO `tracking_log_ratelimit` VALUES(185, 'foursquare', 500, 375, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:11 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:11 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 38\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 375\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:09');
INSERT INTO `tracking_log_ratelimit` VALUES(186, 'foursquare', 500, 374, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:11 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:11 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 87\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 374\r\nContent-Length: 550\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:10');
INSERT INTO `tracking_log_ratelimit` VALUES(187, 'foursquare', 500, 373, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:11 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:11 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 41\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 373\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:10');
INSERT INTO `tracking_log_ratelimit` VALUES(188, 'foursquare', 500, 372, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:12 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:12 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 42\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 372\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:10');
INSERT INTO `tracking_log_ratelimit` VALUES(189, 'foursquare', 500, 371, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:12 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:12 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 48\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 371\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:10');
INSERT INTO `tracking_log_ratelimit` VALUES(190, 'foursquare', 500, 370, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:12 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:12 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 41\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 370\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:11');
INSERT INTO `tracking_log_ratelimit` VALUES(191, 'foursquare', 500, 369, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:12 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:12 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 41\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 369\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:11');
INSERT INTO `tracking_log_ratelimit` VALUES(192, 'foursquare', 500, 368, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:12 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:12 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 42\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 368\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:11');
INSERT INTO `tracking_log_ratelimit` VALUES(193, 'foursquare', 500, 367, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:12 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:12 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 42\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 367\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:11');
INSERT INTO `tracking_log_ratelimit` VALUES(194, 'foursquare', 500, 366, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:12 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:12 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 114\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 366\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:11');
INSERT INTO `tracking_log_ratelimit` VALUES(195, 'foursquare', 500, 365, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:13 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:13 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 113\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 365\r\nContent-Length: 541\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:11');
INSERT INTO `tracking_log_ratelimit` VALUES(196, 'foursquare', 500, 364, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:13 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:13 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 364\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:11');
INSERT INTO `tracking_log_ratelimit` VALUES(197, 'foursquare', 500, 363, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:13 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:13 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 44\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 363\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:12');
INSERT INTO `tracking_log_ratelimit` VALUES(198, 'foursquare', 500, 362, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:13 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:13 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 362\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:12');
INSERT INTO `tracking_log_ratelimit` VALUES(199, 'foursquare', 500, 361, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:13 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:13 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 46\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 361\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:12');
INSERT INTO `tracking_log_ratelimit` VALUES(200, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:13 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:13 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 41\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:12');
INSERT INTO `tracking_log_ratelimit` VALUES(201, 'foursquare', 500, 360, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:14 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:14 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 161\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 360\r\nContent-Length: 730\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:12');
INSERT INTO `tracking_log_ratelimit` VALUES(202, 'foursquare', 500, 359, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:14 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:14 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 35\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 359\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:12');
INSERT INTO `tracking_log_ratelimit` VALUES(203, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:14 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:14 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 67\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:13');
INSERT INTO `tracking_log_ratelimit` VALUES(204, 'foursquare', 500, 358, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:14 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:14 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 43\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 358\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:13');
INSERT INTO `tracking_log_ratelimit` VALUES(205, 'foursquare', 500, 357, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:14 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:14 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 39\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 357\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:13');
INSERT INTO `tracking_log_ratelimit` VALUES(206, 'foursquare', 500, 356, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:15 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:15 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 510\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 356\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:14');
INSERT INTO `tracking_log_ratelimit` VALUES(207, 'foursquare', 500, 355, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:15 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:15 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 48\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 355\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:14');
INSERT INTO `tracking_log_ratelimit` VALUES(208, 'foursquare', 500, 354, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:16 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:16 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 109\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 354\r\nContent-Length: 524\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:15');
INSERT INTO `tracking_log_ratelimit` VALUES(209, 'foursquare', 500, 353, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:17 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:17 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 48\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 353\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:15');
INSERT INTO `tracking_log_ratelimit` VALUES(210, 'foursquare', 500, 352, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:17 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:17 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 53\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 352\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:16');
INSERT INTO `tracking_log_ratelimit` VALUES(211, 'foursquare', 500, 351, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:17 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:17 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 49\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 351\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:16');
INSERT INTO `tracking_log_ratelimit` VALUES(212, 'foursquare', 500, 350, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:18 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:18 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 89\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 350\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:16');
INSERT INTO `tracking_log_ratelimit` VALUES(213, 'foursquare', 500, 349, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:18 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:18 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 53\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 349\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:16');
INSERT INTO `tracking_log_ratelimit` VALUES(214, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:18 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:18 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 35\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:16');
INSERT INTO `tracking_log_ratelimit` VALUES(215, 'foursquare', 500, 347, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:18 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:18 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 347\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:17');
INSERT INTO `tracking_log_ratelimit` VALUES(216, 'foursquare', 500, 346, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:18 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:18 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 44\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 346\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:17');
INSERT INTO `tracking_log_ratelimit` VALUES(217, 'foursquare', 500, 345, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:18 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:18 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 36\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 345\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:17');
INSERT INTO `tracking_log_ratelimit` VALUES(218, 'foursquare', 500, 344, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:19 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:19 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 168\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 344\r\nContent-Length: 559\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:17');
INSERT INTO `tracking_log_ratelimit` VALUES(219, 'foursquare', 500, 343, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:19 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:19 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 42\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 343\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:17');
INSERT INTO `tracking_log_ratelimit` VALUES(220, 'foursquare', 500, 342, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:19 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:19 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 44\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 342\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:17');
INSERT INTO `tracking_log_ratelimit` VALUES(221, 'foursquare', 500, 341, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:19 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:19 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 341\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:18');
INSERT INTO `tracking_log_ratelimit` VALUES(222, 'foursquare', 500, 340, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:19 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:19 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 98\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 340\r\nContent-Length: 561\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:18');
INSERT INTO `tracking_log_ratelimit` VALUES(223, 'foursquare', 500, 339, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:19 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:19 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 46\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 339\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:18');
INSERT INTO `tracking_log_ratelimit` VALUES(224, 'foursquare', 500, 338, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:20 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:20 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 66\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 338\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:18');
INSERT INTO `tracking_log_ratelimit` VALUES(225, 'foursquare', 500, 337, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:20 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:20 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 53\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 337\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:18');
INSERT INTO `tracking_log_ratelimit` VALUES(226, 'foursquare', 500, 336, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:20 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:20 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 104\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 336\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:18');
INSERT INTO `tracking_log_ratelimit` VALUES(227, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:21 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:21 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 142\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:20');
INSERT INTO `tracking_log_ratelimit` VALUES(228, 'foursquare', 500, 334, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:22 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 96\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 334\r\nContent-Length: 573\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:20');
INSERT INTO `tracking_log_ratelimit` VALUES(229, 'foursquare', 500, 333, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:22 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 333\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:20');
INSERT INTO `tracking_log_ratelimit` VALUES(230, 'foursquare', 500, 332, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:22 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 39\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 332\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:21');
INSERT INTO `tracking_log_ratelimit` VALUES(231, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:22 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 35\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:21');
INSERT INTO `tracking_log_ratelimit` VALUES(232, 'foursquare', 500, 331, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:22 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 50\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 331\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:21');
INSERT INTO `tracking_log_ratelimit` VALUES(233, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:22 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:22 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 63\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:21');
INSERT INTO `tracking_log_ratelimit` VALUES(234, 'foursquare', 500, 329, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:23 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 94\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 329\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:21');
INSERT INTO `tracking_log_ratelimit` VALUES(235, 'foursquare', 500, 328, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:23 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 50\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 328\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:21');
INSERT INTO `tracking_log_ratelimit` VALUES(236, 'foursquare', 500, 327, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:23 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 60\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 327\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:21');
INSERT INTO `tracking_log_ratelimit` VALUES(237, 'foursquare', 500, 326, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:23 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 40\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 326\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:22');
INSERT INTO `tracking_log_ratelimit` VALUES(238, 'foursquare', 500, 325, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:23 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 111\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 325\r\nContent-Length: 580\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:22');
INSERT INTO `tracking_log_ratelimit` VALUES(239, 'foursquare', 500, 324, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:23 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:23 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 42\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 324\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:22');
INSERT INTO `tracking_log_ratelimit` VALUES(240, 'foursquare', 500, 323, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:24 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 83\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 323\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:22');
INSERT INTO `tracking_log_ratelimit` VALUES(241, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:24 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 119\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:22');
INSERT INTO `tracking_log_ratelimit` VALUES(242, 'foursquare', 500, 322, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:24 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 39\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 322\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:22');
INSERT INTO `tracking_log_ratelimit` VALUES(243, 'foursquare', 500, 321, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:24 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 38\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 321\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:23');
INSERT INTO `tracking_log_ratelimit` VALUES(244, 'foursquare', 500, 320, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:24 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:24 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 43\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 320\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:23');
INSERT INTO `tracking_log_ratelimit` VALUES(245, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:25 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 669\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:23');
INSERT INTO `tracking_log_ratelimit` VALUES(246, 'foursquare', 500, 318, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:25 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 37\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 318\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:24');
INSERT INTO `tracking_log_ratelimit` VALUES(247, 'foursquare', 500, 317, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:25 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 108\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 317\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:24');
INSERT INTO `tracking_log_ratelimit` VALUES(248, 'foursquare', 500, 316, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:25 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 44\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 316\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:24');
INSERT INTO `tracking_log_ratelimit` VALUES(249, 'foursquare', 500, 315, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:25 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 34\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 315\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:24');
INSERT INTO `tracking_log_ratelimit` VALUES(250, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:25 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:25 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 54\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:24');
INSERT INTO `tracking_log_ratelimit` VALUES(251, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:26 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:26 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 39\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:24');
INSERT INTO `tracking_log_ratelimit` VALUES(252, 'foursquare', 500, 313, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:26 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:26 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 98\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 313\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:24');
INSERT INTO `tracking_log_ratelimit` VALUES(253, 'foursquare', 500, 312, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:26 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:26 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 312\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:25');
INSERT INTO `tracking_log_ratelimit` VALUES(254, 'foursquare', 500, 311, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:26 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:26 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 46\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 311\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:25');
INSERT INTO `tracking_log_ratelimit` VALUES(255, 'foursquare', 500, 310, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:26 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:26 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 43\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 310\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:25');
INSERT INTO `tracking_log_ratelimit` VALUES(256, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:27 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 31\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:25');
INSERT INTO `tracking_log_ratelimit` VALUES(257, 'foursquare', 500, 309, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:27 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 140\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 309\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:26');
INSERT INTO `tracking_log_ratelimit` VALUES(258, 'foursquare', 500, 308, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:27 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 41\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 308\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:26');
INSERT INTO `tracking_log_ratelimit` VALUES(259, 'foursquare', 500, 307, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:27 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 40\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 307\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:26');
INSERT INTO `tracking_log_ratelimit` VALUES(260, 'foursquare', 500, 306, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:27 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:27 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 160\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 306\r\nContent-Length: 490\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:26');
INSERT INTO `tracking_log_ratelimit` VALUES(261, 'foursquare', 500, 305, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:28 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:28 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 716\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 305\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:27');
INSERT INTO `tracking_log_ratelimit` VALUES(262, 'foursquare', 500, 304, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:29 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:29 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 37\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 304\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:27');
INSERT INTO `tracking_log_ratelimit` VALUES(263, 'foursquare', 500, 303, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:29 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:29 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 44\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 303\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:27');
INSERT INTO `tracking_log_ratelimit` VALUES(264, 'foursquare', 500, 302, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:29 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:29 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 46\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 302\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:27');
INSERT INTO `tracking_log_ratelimit` VALUES(265, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:29 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:29 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:28');
INSERT INTO `tracking_log_ratelimit` VALUES(266, 'foursquare', 500, 301, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:29 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:29 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 46\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 301\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:28');
INSERT INTO `tracking_log_ratelimit` VALUES(267, 'foursquare', 500, 300, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:29 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:29 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 24\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 300\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:28');
INSERT INTO `tracking_log_ratelimit` VALUES(268, 'foursquare', 500, 299, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:30 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 306\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 299\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:28');
INSERT INTO `tracking_log_ratelimit` VALUES(269, 'foursquare', 500, 298, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:30 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 75\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 298\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:28');
INSERT INTO `tracking_log_ratelimit` VALUES(270, 'foursquare', 500, 297, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:30 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 39\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 297\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:29');
INSERT INTO `tracking_log_ratelimit` VALUES(271, 'foursquare', 500, 296, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:30 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 40\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 296\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:29');
INSERT INTO `tracking_log_ratelimit` VALUES(272, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:30 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 34\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:29');
INSERT INTO `tracking_log_ratelimit` VALUES(273, 'foursquare', 500, 295, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:30 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:30 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 52\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 295\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:29');
INSERT INTO `tracking_log_ratelimit` VALUES(274, 'foursquare', 0, 0, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:31 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:31 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 239\r\nX-RateLimit-Limit: 0\r\nX-RateLimit-Remaining: 0\r\nContent-Length: 547\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:30');
INSERT INTO `tracking_log_ratelimit` VALUES(275, 'foursquare', 500, 294, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:31 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:31 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 46\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 294\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:30');
INSERT INTO `tracking_log_ratelimit` VALUES(276, 'foursquare', 500, 293, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:31 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:31 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 74\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 293\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:30');
INSERT INTO `tracking_log_ratelimit` VALUES(277, 'foursquare', 500, 292, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:32 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:31 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 134\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 292\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:30');
INSERT INTO `tracking_log_ratelimit` VALUES(278, 'foursquare', 500, 291, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:32 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:32 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 291\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:30');
INSERT INTO `tracking_log_ratelimit` VALUES(279, 'foursquare', 500, 290, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:32 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:32 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 79\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 290\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:30');
INSERT INTO `tracking_log_ratelimit` VALUES(280, 'foursquare', 500, 289, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:32 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:32 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 45\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 289\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:31');
INSERT INTO `tracking_log_ratelimit` VALUES(281, 'foursquare', 500, 288, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:32 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:32 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 112\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 288\r\nContent-Length: 580\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:31');
INSERT INTO `tracking_log_ratelimit` VALUES(282, 'foursquare', 500, 287, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:32 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:32 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 37\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 287\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:31');
INSERT INTO `tracking_log_ratelimit` VALUES(283, 'foursquare', 500, 286, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:33 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:33 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 249\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 286\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:31');
INSERT INTO `tracking_log_ratelimit` VALUES(284, 'foursquare', 500, 285, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:33 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:33 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 348\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 285\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:32');
INSERT INTO `tracking_log_ratelimit` VALUES(285, 'foursquare', 500, 284, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:33 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:33 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 335\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 284\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:32');
INSERT INTO `tracking_log_ratelimit` VALUES(286, 'foursquare', 500, 283, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:34 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 24\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 283\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:32');
INSERT INTO `tracking_log_ratelimit` VALUES(287, 'foursquare', 500, 282, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:34 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 64\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 282\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:32');
INSERT INTO `tracking_log_ratelimit` VALUES(288, 'foursquare', 500, 281, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:34 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 66\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 281\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:33');
INSERT INTO `tracking_log_ratelimit` VALUES(289, 'foursquare', 500, 280, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:34 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 119\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 280\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:33');
INSERT INTO `tracking_log_ratelimit` VALUES(290, 'foursquare', 500, 279, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:34 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:34 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 114\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 279\r\nContent-Length: 535\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:33');
INSERT INTO `tracking_log_ratelimit` VALUES(291, 'foursquare', 500, 278, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:35 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:35 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 88\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 278\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:33');
INSERT INTO `tracking_log_ratelimit` VALUES(292, 'foursquare', 500, 277, 'HTTP/1.1 200 OK\r\nAccess-Control-Allow-Origin: *\r\nCache-Control: no-cache, private, no-store\r\nContent-Encoding: gzip\r\nContent-Type: application/json; charset=utf-8\r\nDate: Sun, 07 Apr 2013 15:06:35 GMT\r\nExpires: Sun, 7 Apr 2013 15:06:35 GMT\r\nPragma: no-cache\r\nServer: nginx/1.2.1\r\nStrict-Transport-Security: max-age=864000\r\nTracer-Time: 65\r\nX-RateLimit-Limit: 500\r\nX-RateLimit-Remaining: 277\r\nContent-Length: 112\r\nConnection: keep-alive\r\n\r\n', '2013-04-07 11:06:33');

-- --------------------------------------------------------

--
-- Table structure for table `tracking_point`
--

CREATE TABLE `tracking_point` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lat` decimal(13,10) DEFAULT NULL,
  `lng` decimal(13,10) DEFAULT NULL,
  `scanned` tinyint(1) NOT NULL DEFAULT '0',
  `region_id` int(12) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `region_id_idx` (`region_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2019 ;

--
-- Dumping data for table `tracking_point`
--

INSERT INTO `tracking_point` VALUES(1, 40.8112511934, -73.9596147494, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(2, 40.7964056264, -73.9484138445, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(3, 40.7957233652, -73.9458818392, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(4, 40.7943588217, -73.9431781725, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(5, 40.7936115598, -73.9412469820, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(6, 40.7922794634, -73.9385862307, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(7, 40.7917271229, -73.9369125323, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(8, 40.7897451575, -73.9381247360, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(9, 40.7870807829, -73.9388972122, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(10, 40.7855535931, -73.9411717255, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(11, 40.7844487956, -73.9435320694, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(12, 40.7855535931, -73.9475661118, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(13, 40.7877956256, -73.9526301224, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(14, 40.7911422868, -73.9514714081, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(15, 40.7887379065, -73.9490681488, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(16, 40.7885754452, -73.9428025086, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(17, 40.7904623526, -73.9416835647, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(18, 40.7917944854, -73.9479062896, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(19, 40.7942312446, -73.9488504272, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(20, 40.7984547487, -73.9474771362, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(21, 40.8005014271, -73.9463613372, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(22, 40.7995918001, -73.9525840621, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:18');
INSERT INTO `tracking_point` VALUES(23, 40.8021582158, -73.9567468505, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(24, 40.8053092488, -73.9564035278, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(25, 40.8081677884, -73.9555023055, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(26, 40.8114159795, -73.9561460357, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(27, 40.8141443371, -73.9582059722, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(28, 40.8182691409, -73.9575193267, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(29, 40.8205425452, -73.9556310516, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(30, 40.8256411828, -73.9512107711, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(31, 40.8302523519, -73.9485500198, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(32, 40.8365191311, -73.9468334060, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(33, 40.8404802092, -73.9449880462, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(34, 40.8447007696, -73.9429281097, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(35, 40.8465187744, -73.9407823425, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(36, 40.8455448495, -73.9376924377, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:19');
INSERT INTO `tracking_point` VALUES(37, 40.8435969567, -73.9360960234, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(38, 40.8402854076, -73.9360960234, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(39, 40.8367788811, -73.9391859282, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(40, 40.8411295437, -73.9401300658, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(41, 40.8333371100, -73.9418466795, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(42, 40.8320382820, -73.9378126372, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(43, 40.8258035534, -73.9373834837, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(44, 40.8213869326, -73.9372976530, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(45, 40.8155409529, -73.9375551451, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(46, 40.8106039466, -73.9378126372, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(47, 40.8056016051, -73.9366968382, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(48, 40.8028079256, -73.9333494414, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(49, 40.7987146479, -73.9327486265, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:20');
INSERT INTO `tracking_point` VALUES(50, 40.7948160535, -73.9337785948, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(51, 40.7962455647, -73.9372118223, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(52, 40.8005988864, -73.9346369017, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(53, 40.8016384434, -73.9372118223, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(54, 40.7987146479, -73.9415891875, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(55, 40.8018983301, -73.9402425409, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(56, 40.8054716691, -73.9398133875, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(57, 40.8028728962, -73.9479673029, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(58, 40.8041722954, -73.9507997156, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(59, 40.8071608169, -73.9501989008, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(60, 40.8100842404, -73.9435899377, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(61, 40.8130724957, -73.9423024774, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(62, 40.8176845386, -73.9450490594, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(63, 40.8166452330, -73.9523446680, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(64, 40.8204775919, -73.9494264246, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(65, 40.8248293241, -73.9465081812, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(66, 40.8288560458, -73.9439332605, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:21');
INSERT INTO `tracking_point` VALUES(67, 40.8238550805, -73.9408433557, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:22');
INSERT INTO `tracking_point` VALUES(68, 40.8181392297, -73.9420449854, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:22');
INSERT INTO `tracking_point` VALUES(69, 40.8167101901, -73.9388692499, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:22');
INSERT INTO `tracking_point` VALUES(70, 40.8146315320, -73.9447915674, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:23');
INSERT INTO `tracking_point` VALUES(71, 40.8125528088, -73.9488256097, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:23');
INSERT INTO `tracking_point` VALUES(72, 40.8129425744, -73.9524304987, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:23');
INSERT INTO `tracking_point` VALUES(73, 40.8094346019, -73.9477956415, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:24');
INSERT INTO `tracking_point` VALUES(74, 40.8056016051, -73.9446199060, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:24');
INSERT INTO `tracking_point` VALUES(75, 40.8033926589, -73.9422166467, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:24');
INSERT INTO `tracking_point` VALUES(76, 40.7968303559, -73.9342343927, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:25');
INSERT INTO `tracking_point` VALUES(77, 40.7984547487, -73.9377534509, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:25');
INSERT INTO `tracking_point` VALUES(78, 40.7962455647, -73.9314019800, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:25');
INSERT INTO `tracking_point` VALUES(79, 40.7993643914, -73.9308869959, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:25');
INSERT INTO `tracking_point` VALUES(80, 40.8069659174, -73.9339769006, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:26');
INSERT INTO `tracking_point` VALUES(81, 40.8098243857, -73.9349210382, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:27');
INSERT INTO `tracking_point` VALUES(82, 40.8143067358, -73.9355218530, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:27');
INSERT INTO `tracking_point` VALUES(83, 40.8237251803, -73.9351785303, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:27');
INSERT INTO `tracking_point` VALUES(84, 40.8218415984, -73.9412725092, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:27');
INSERT INTO `tracking_point` VALUES(85, 40.8222313093, -73.9451348901, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:28');
INSERT INTO `tracking_point` VALUES(86, 40.8187238280, -73.9471089960, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:28');
INSERT INTO `tracking_point` VALUES(87, 40.8159956587, -73.9484822870, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:28');
INSERT INTO `tracking_point` VALUES(88, 40.8149563266, -73.9543187738, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:29');
INSERT INTO `tracking_point` VALUES(89, 40.8064461827, -73.9539754511, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:30');
INSERT INTO `tracking_point` VALUES(90, 40.8029378668, -73.9530313135, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:30');
INSERT INTO `tracking_point` VALUES(91, 40.8000141285, -73.9486539484, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:31');
INSERT INTO `tracking_point` VALUES(92, 40.8091097802, -73.9585244775, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:32');
INSERT INTO `tracking_point` VALUES(93, 40.8295054942, -73.9365518213, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:33');
INSERT INTO `tracking_point` VALUES(94, 40.8506740266, -73.9390409113, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:33');
INSERT INTO `tracking_point` VALUES(95, 40.8522321790, -73.9330327631, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:34');
INSERT INTO `tracking_point` VALUES(96, 40.8585293382, -73.9348352075, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:34');
INSERT INTO `tracking_point` VALUES(97, 40.8681362216, -73.9259088159, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:34');
INSERT INTO `tracking_point` VALUES(98, 40.8706026289, -73.9172208068, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:35');
INSERT INTO `tracking_point` VALUES(99, 40.8647609889, -73.9197957274, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:35');
INSERT INTO `tracking_point` VALUES(100, 40.8600873058, -73.9271771666, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:36');
INSERT INTO `tracking_point` VALUES(101, 40.8548780808, -73.9277026331, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:36');
INSERT INTO `tracking_point` VALUES(102, 40.8483857967, -73.9323374903, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:36');
INSERT INTO `tracking_point` VALUES(103, 40.8546184017, -73.9369723475, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:37');
INSERT INTO `tracking_point` VALUES(104, 40.8835663560, -74.0672633326, 1, 1, '2013-04-06 14:41:08', '2013-04-06 17:57:37');
INSERT INTO `tracking_point` VALUES(1692, 40.8211247423, -74.0638132052, 1, 10, '2013-04-06 21:25:10', '2013-04-06 17:58:03');
INSERT INTO `tracking_point` VALUES(1693, 40.7877956256, -73.9554948763, 1, 10, '2013-04-06 21:25:10', '2013-04-06 17:58:03');
INSERT INTO `tracking_point` VALUES(1694, 40.7863659324, -73.9527482943, 1, 10, '2013-04-06 21:25:10', '2013-04-06 17:58:03');
INSERT INTO `tracking_point` VALUES(1695, 40.7853261363, -73.9494867281, 1, 10, '2013-04-06 21:25:10', '2013-04-06 17:58:03');
INSERT INTO `tracking_point` VALUES(1696, 40.7837664115, -73.9470834688, 1, 10, '2013-04-06 21:25:11', '2013-04-06 17:58:03');
INSERT INTO `tracking_point` VALUES(1697, 40.7828565552, -73.9445085482, 1, 10, '2013-04-06 21:25:11', '2013-04-06 17:58:03');
INSERT INTO `tracking_point` VALUES(1698, 40.7845462785, -73.9568681673, 1, 10, '2013-04-06 21:25:12', '2013-04-06 17:58:03');
INSERT INTO `tracking_point` VALUES(1699, 40.7840263682, -73.9539499239, 1, 10, '2013-04-06 21:25:13', '2013-04-06 17:58:03');
INSERT INTO `tracking_point` VALUES(1700, 40.7820127798, -73.9506039829, 1, 10, '2013-04-06 21:25:13', '2013-04-06 17:58:03');
INSERT INTO `tracking_point` VALUES(1701, 40.7800630209, -73.9488873691, 1, 10, '2013-04-06 21:25:13', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1702, 40.7778532249, -73.9463124485, 1, 10, '2013-04-06 21:25:13', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1703, 40.7757733498, -73.9473424168, 1, 10, '2013-04-06 21:25:13', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1704, 40.7730434148, -73.9490590305, 1, 10, '2013-04-06 21:25:13', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1705, 40.7708333854, -73.9502606602, 1, 10, '2013-04-06 21:25:13', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1706, 40.7686232824, -73.9521489353, 1, 10, '2013-04-06 21:25:13', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1707, 40.7661530803, -73.9540372105, 1, 10, '2013-04-06 21:25:13', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1708, 40.7645929054, -73.9562688084, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1709, 40.7625126151, -73.9583287449, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1710, 40.7601722108, -73.9600453586, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1711, 40.7584818675, -73.9617619724, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1712, 40.7566614498, -73.9639935703, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1713, 40.7543208394, -73.9653668613, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1714, 40.7525003077, -73.9672551365, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1715, 40.7508097694, -73.9686284275, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1716, 40.7504196390, -73.9713750095, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1717, 40.7514599815, -73.9742932529, 1, 10, '2013-04-06 21:25:14', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1718, 40.7526303473, -73.9770398350, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1719, 40.7538006926, -73.9789281101, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1720, 40.7556211887, -73.9777264805, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1721, 40.7590019777, -73.9751515598, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1722, 40.7606923078, -73.9736066074, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1723, 40.7629026745, -73.9720616550, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1724, 40.7642028559, -73.9705167026, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1725, 40.7665431183, -73.9689717502, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1726, 40.7697933461, -73.9669118137, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1727, 40.7743433978, -73.9638219089, 1, 10, '2013-04-06 21:25:15', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1728, 40.7786331613, -73.9605603428, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1729, 40.7817297433, -73.9583592148, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1730, 40.7767902218, -73.9621357651, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1731, 40.7810798272, -73.9540676804, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1732, 40.7783501104, -73.9508061142, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1733, 40.7760102638, -73.9499478074, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1734, 40.7727603401, -73.9533810349, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:04');
INSERT INTO `tracking_point` VALUES(1735, 40.7691202369, -73.9552693100, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1736, 40.7661300029, -73.9581875535, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1737, 40.7639197435, -73.9612774582, 1, 10, '2013-04-06 21:25:16', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1738, 40.7606692285, -73.9640240403, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1739, 40.7580687020, -73.9660839768, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1740, 40.7557281412, -73.9674572678, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1741, 40.7536475735, -73.9710621567, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1742, 40.7542977579, -73.9741520615, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1743, 40.7570284629, -73.9724354477, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1744, 40.7589788979, -73.9700321885, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1745, 40.7607992522, -73.9683155747, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1746, 40.7635296901, -73.9672856064, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1747, 40.7645698274, -73.9660839768, 1, 10, '2013-04-06 21:25:17', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1748, 40.7673001105, -73.9653973313, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1749, 40.7676901418, -73.9623074265, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1750, 40.7697702700, -73.9580158921, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1751, 40.7717203310, -73.9631657334, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1752, 40.7738003330, -73.9612774582, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1753, 40.7767902218, -73.9592175217, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1754, 40.7749703055, -73.9571575852, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1755, 40.7728903401, -73.9588741990, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1756, 40.7712003203, -73.9621357651, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1757, 40.7782201211, -73.9544110032, 1, 10, '2013-04-06 21:25:18', '2013-04-06 17:58:05');
INSERT INTO `tracking_point` VALUES(1758, 40.7753602918, -73.9535526963, 1, 10, '2013-04-06 21:25:19', '2013-04-06 17:58:06');
INSERT INTO `tracking_point` VALUES(1759, 40.7722403376, -73.9568142624, 1, 10, '2013-04-06 21:25:19', '2013-04-06 17:58:06');
INSERT INTO `tracking_point` VALUES(1760, 40.7708103096, -73.9540676804, 1, 10, '2013-04-06 21:25:19', '2013-04-06 17:58:06');
INSERT INTO `tracking_point` VALUES(1761, 40.7751003012, -73.9446263047, 1, 10, '2013-04-06 21:25:19', '2013-04-06 17:58:06');
INSERT INTO `tracking_point` VALUES(1762, 40.7779601417, -73.9435963364, 1, 10, '2013-04-06 21:25:19', '2013-04-06 17:58:06');
INSERT INTO `tracking_point` VALUES(1763, 40.8188943556, -74.0788655015, 1, 10, '2013-04-06 21:25:19', '2013-04-06 17:58:06');
INSERT INTO `tracking_point` VALUES(1764, 40.8909770491, -74.3697137789, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:03');
INSERT INTO `tracking_point` VALUES(1765, 40.6382262844, -74.1599435763, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:03');
INSERT INTO `tracking_point` VALUES(1766, 40.6360117767, -74.1499872164, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:03');
INSERT INTO `tracking_point` VALUES(1767, 40.6382262844, -74.1391725497, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:03');
INSERT INTO `tracking_point` VALUES(1768, 40.6390078578, -74.1278428988, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:03');
INSERT INTO `tracking_point` VALUES(1769, 40.6416130364, -74.1122217135, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:04');
INSERT INTO `tracking_point` VALUES(1770, 40.6431760948, -74.0972871737, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:04');
INSERT INTO `tracking_point` VALUES(1771, 40.6426550794, -74.0856142000, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:04');
INSERT INTO `tracking_point` VALUES(1772, 40.6341880093, -74.0785760836, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:04');
INSERT INTO `tracking_point` VALUES(1773, 40.6250684253, -74.0746278719, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:04');
INSERT INTO `tracking_point` VALUES(1774, 40.6142535903, -74.0672464327, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:04');
INSERT INTO `tracking_point` VALUES(1775, 40.6072164926, -74.0655298189, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:05');
INSERT INTO `tracking_point` VALUES(1776, 40.5977022009, -74.0662164645, 1, 11, '2013-04-07 10:55:23', '2013-04-07 11:06:05');
INSERT INTO `tracking_point` VALUES(1777, 40.5935311256, -74.0734262423, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:05');
INSERT INTO `tracking_point` VALUES(1778, 40.5944435706, -74.0828676180, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:05');
INSERT INTO `tracking_point` VALUES(1779, 40.6007000006, -74.0734262423, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:05');
INSERT INTO `tracking_point` VALUES(1780, 40.6086500356, -74.0751428561, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:05');
INSERT INTO `tracking_point` VALUES(1781, 40.6184233726, -74.0785760836, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:06');
INSERT INTO `tracking_point` VALUES(1782, 40.6241563984, -74.0835542635, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:06');
INSERT INTO `tracking_point` VALUES(1783, 40.6315825410, -74.0869874911, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:06');
INSERT INTO `tracking_point` VALUES(1784, 40.6374447018, -74.0938539461, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:06');
INSERT INTO `tracking_point` VALUES(1785, 40.6366631101, -74.1065568880, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:06');
INSERT INTO `tracking_point` VALUES(1786, 40.6348393605, -74.1184015230, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:06');
INSERT INTO `tracking_point` VALUES(1787, 40.6313219885, -74.1338510470, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:07');
INSERT INTO `tracking_point` VALUES(1788, 40.6305403252, -74.1498155550, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:07');
INSERT INTO `tracking_point` VALUES(1789, 40.6327550143, -74.1626901583, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:07');
INSERT INTO `tracking_point` VALUES(1790, 40.6289769709, -74.1757364229, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:07');
INSERT INTO `tracking_point` VALUES(1791, 40.6263712992, -74.1616601900, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:07');
INSERT INTO `tracking_point` VALUES(1792, 40.6244169787, -74.1472406344, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:07');
INSERT INTO `tracking_point` VALUES(1793, 40.6238958169, -74.1314477877, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:07');
INSERT INTO `tracking_point` VALUES(1794, 40.6297586526, -74.1125650362, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:08');
INSERT INTO `tracking_point` VALUES(1795, 40.6298889320, -74.1008920626, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:08');
INSERT INTO `tracking_point` VALUES(1796, 40.6218111291, -74.0911073641, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:08');
INSERT INTO `tracking_point` VALUES(1797, 40.6143839000, -74.0902490572, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:08');
INSERT INTO `tracking_point` VALUES(1798, 40.6077377845, -74.0861291842, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:09');
INSERT INTO `tracking_point` VALUES(1799, 40.6007000006, -74.0880174593, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:09');
INSERT INTO `tracking_point` VALUES(1800, 40.5913151360, -74.0952272372, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:09');
INSERT INTO `tracking_point` VALUES(1801, 40.5842756230, -74.1041536288, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:10');
INSERT INTO `tracking_point` VALUES(1802, 40.5777568948, -74.1099901156, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:10');
INSERT INTO `tracking_point` VALUES(1803, 40.5754099972, -74.0953988985, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:10');
INSERT INTO `tracking_point` VALUES(1804, 40.5737149643, -74.1125650362, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:10');
INSERT INTO `tracking_point` VALUES(1805, 40.5742365175, -74.1221780733, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:11');
INSERT INTO `tracking_point` VALUES(1806, 40.5743669051, -74.1377992586, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:11');
INSERT INTO `tracking_point` VALUES(1807, 40.5686296081, -74.1293878512, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:11');
INSERT INTO `tracking_point` VALUES(1808, 40.5703247698, -74.1402025179, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:11');
INSERT INTO `tracking_point` VALUES(1809, 40.5668040014, -74.1450090365, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:11');
INSERT INTO `tracking_point` VALUES(1810, 40.5623701777, -74.1343660311, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:11');
INSERT INTO `tracking_point` VALUES(1811, 40.5622397666, -74.1192598299, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:11');
INSERT INTO `tracking_point` VALUES(1812, 40.5647175327, -74.1051835970, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:12');
INSERT INTO `tracking_point` VALUES(1813, 40.5877954721, -74.1312761263, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:12');
INSERT INTO `tracking_point` VALUES(1814, 40.5890990730, -74.1499872164, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:12');
INSERT INTO `tracking_point` VALUES(1815, 40.5838845173, -74.1559953646, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:12');
INSERT INTO `tracking_point` VALUES(1816, 40.5756707676, -74.1668100313, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:12');
INSERT INTO `tracking_point` VALUES(1817, 40.5845363590, -74.1692132906, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:12');
INSERT INTO `tracking_point` VALUES(1818, 40.5919669053, -74.1609735445, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:13');
INSERT INTO `tracking_point` VALUES(1819, 40.5631526385, -74.1856927828, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:13');
INSERT INTO `tracking_point` VALUES(1820, 40.5606748145, -74.1714448885, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:13');
INSERT INTO `tracking_point` VALUES(1821, 40.5618485320, -74.1585702853, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:14');
INSERT INTO `tracking_point` VALUES(1822, 40.5557188914, -74.1517038302, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:14');
INSERT INTO `tracking_point` VALUES(1823, 40.5491973810, -74.1443223910, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:15');
INSERT INTO `tracking_point` VALUES(1824, 40.5426752354, -74.1498155550, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:15');
INSERT INTO `tracking_point` VALUES(1825, 40.5357610678, -74.1534204439, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:16');
INSERT INTO `tracking_point` VALUES(1826, 40.5311947167, -74.1628618197, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:16');
INSERT INTO `tracking_point` VALUES(1827, 40.5407184679, -74.1666383700, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:16');
INSERT INTO `tracking_point` VALUES(1828, 40.5540233598, -74.1608018832, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:16');
INSERT INTO `tracking_point` VALUES(1829, 40.5530484162, -74.1669608453, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:16');
INSERT INTO `tracking_point` VALUES(1830, 40.5569611737, -74.1796637872, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:17');
INSERT INTO `tracking_point` VALUES(1831, 40.5512223845, -74.1877318719, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:17');
INSERT INTO `tracking_point` VALUES(1832, 40.5563090633, -74.1956282952, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:17');
INSERT INTO `tracking_point` VALUES(1833, 40.5529179871, -74.2126227715, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:17');
INSERT INTO `tracking_point` VALUES(1834, 40.5478310507, -74.2169143060, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:17');
INSERT INTO `tracking_point` VALUES(1835, 40.5385692256, -74.2184592584, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:17');
INSERT INTO `tracking_point` VALUES(1836, 40.5308718053, -74.2191459039, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:18');
INSERT INTO `tracking_point` VALUES(1837, 40.5161268196, -74.2423201898, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:18');
INSERT INTO `tracking_point` VALUES(1838, 40.5065995734, -74.2517615655, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:18');
INSERT INTO `tracking_point` VALUES(1839, 40.5022922918, -74.2390586236, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:18');
INSERT INTO `tracking_point` VALUES(1840, 40.5100003974, -74.2345186176, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:18');
INSERT INTO `tracking_point` VALUES(1841, 40.5068680153, -74.2295404377, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:18');
INSERT INTO `tracking_point` VALUES(1842, 40.5126106041, -74.2094560566, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:20');
INSERT INTO `tracking_point` VALUES(1843, 40.5221369963, -74.2146058979, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:20');
INSERT INTO `tracking_point` VALUES(1844, 40.5280087554, -74.2309137287, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:20');
INSERT INTO `tracking_point` VALUES(1845, 40.5334885998, -74.2055078449, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:21');
INSERT INTO `tracking_point` VALUES(1846, 40.5434033697, -74.2010446491, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:21');
INSERT INTO `tracking_point` VALUES(1847, 40.5383157105, -74.1929765644, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:21');
INSERT INTO `tracking_point` VALUES(1848, 40.5404030021, -74.1835351887, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:21');
INSERT INTO `tracking_point` VALUES(1849, 40.5482297660, -74.1737504902, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:21');
INSERT INTO `tracking_point` VALUES(1850, 40.5351846513, -74.1725488605, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:21');
INSERT INTO `tracking_point` VALUES(1851, 40.5252686652, -74.1914316120, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:21');
INSERT INTO `tracking_point` VALUES(1852, 40.5367501992, -74.1603609028, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:22');
INSERT INTO `tracking_point` VALUES(1853, 40.5467949277, -74.1593309345, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:22');
INSERT INTO `tracking_point` VALUES(1854, 40.6178476680, -74.1862817707, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:22');
INSERT INTO `tracking_point` VALUES(1855, 40.6067710159, -74.1857667866, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:22');
INSERT INTO `tracking_point` VALUES(1856, 40.5933462592, -74.1895433368, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:22');
INSERT INTO `tracking_point` VALUES(1857, 40.6143294010, -74.1957231464, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:22');
INSERT INTO `tracking_point` VALUES(1858, 40.6267076676, -74.1931482258, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:23');
INSERT INTO `tracking_point` VALUES(1859, 40.6119837868, -74.1698022785, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:23');
INSERT INTO `tracking_point` VALUES(1860, 40.6096380902, -74.1368432941, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:23');
INSERT INTO `tracking_point` VALUES(1861, 40.6183688770, -74.1377016010, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:24');
INSERT INTO `tracking_point` VALUES(1862, 40.6135475387, -74.1268869343, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:24');
INSERT INTO `tracking_point` VALUES(1863, 40.6040341484, -74.1268869343, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:24');
INSERT INTO `tracking_point` VALUES(1864, 40.5953014886, -74.1389032306, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:24');
INSERT INTO `tracking_point` VALUES(1865, 40.6024701738, -74.1481729450, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:24');
INSERT INTO `tracking_point` VALUES(1866, 40.6050767778, -74.1133256855, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:24');
INSERT INTO `tracking_point` VALUES(1867, 40.6098987272, -74.1030260029, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:24');
INSERT INTO `tracking_point` VALUES(1868, 40.5975173461, -74.1049142780, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:25');
INSERT INTO `tracking_point` VALUES(1869, 40.5831781448, -74.0906663837, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:25');
INSERT INTO `tracking_point` VALUES(1870, 40.5831781448, -74.0803667011, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:25');
INSERT INTO `tracking_point` VALUES(1871, 40.6155021773, -74.1457696857, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:25');
INSERT INTO `tracking_point` VALUES(1872, 40.6165446277, -74.1577859821, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:26');
INSERT INTO `tracking_point` VALUES(1873, 40.6248836461, -74.1673990192, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:26');
INSERT INTO `tracking_point` VALUES(1874, 40.6379112781, -74.1720338764, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:26');
INSERT INTO `tracking_point` VALUES(1875, 40.6310069497, -74.1229387226, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:26');
INSERT INTO `tracking_point` VALUES(1876, 40.6204536722, -74.1152139606, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:27');
INSERT INTO `tracking_point` VALUES(1877, 40.5925641515, -74.1119523945, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:27');
INSERT INTO `tracking_point` VALUES(1878, 40.5778327469, -74.1435380878, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:27');
INSERT INTO `tracking_point` VALUES(1879, 40.5698790472, -74.1574426594, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:27');
INSERT INTO `tracking_point` VALUES(1880, 40.5865676881, -74.1955514850, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:28');
INSERT INTO `tracking_point` VALUES(1881, 40.6012971688, -74.1840501728, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:28');
INSERT INTO `tracking_point` VALUES(1882, 40.6181082730, -74.1780420246, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:28');
INSERT INTO `tracking_point` VALUES(1883, 40.6268379529, -74.1813035908, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:28');
INSERT INTO `tracking_point` VALUES(1884, 40.6044251363, -74.0951295795, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:28');
INSERT INTO `tracking_point` VALUES(1885, 40.6109412651, -74.1143556537, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:29');
INSERT INTO `tracking_point` VALUES(1886, 40.5559251920, -74.1308351459, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:29');
INSERT INTO `tracking_point` VALUES(1887, 40.5531862435, -74.1356416645, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:29');
INSERT INTO `tracking_point` VALUES(1888, 40.5445773900, -74.1545244159, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:29');
INSERT INTO `tracking_point` VALUES(1889, 40.5456209463, -74.1655107441, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:30');
INSERT INTO `tracking_point` VALUES(1890, 40.5475775706, -74.1680856647, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:30');
INSERT INTO `tracking_point` VALUES(1891, 40.5431424735, -74.1737504902, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:30');
INSERT INTO `tracking_point` VALUES(1892, 40.5465340448, -74.1857667866, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:30');
INSERT INTO `tracking_point` VALUES(1893, 40.5444469443, -74.1929765644, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:30');
INSERT INTO `tracking_point` VALUES(1894, 40.5480993274, -74.1994996967, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:30');
INSERT INTO `tracking_point` VALUES(1895, 40.5477080102, -74.2089410724, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:31');
INSERT INTO `tracking_point` VALUES(1896, 40.5407943620, -74.2084260883, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:31');
INSERT INTO `tracking_point` VALUES(1897, 40.5387070827, -74.2032762470, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:31');
INSERT INTO `tracking_point` VALUES(1898, 40.5293135209, -74.1873117389, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:31');
INSERT INTO `tracking_point` VALUES(1899, 40.5225284629, -74.2044778766, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:32');
INSERT INTO `tracking_point` VALUES(1900, 40.5090868011, -74.2417283954, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:32');
INSERT INTO `tracking_point` VALUES(1901, 40.5346627939, -74.2334886493, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:32');
INSERT INTO `tracking_point` VALUES(1902, 40.5469253689, -74.2283388080, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:32');
INSERT INTO `tracking_point` VALUES(1903, 40.6256653757, -74.1059442463, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:33');
INSERT INTO `tracking_point` VALUES(1904, 40.6284013572, -74.1280885639, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:33');
INSERT INTO `tracking_point` VALUES(1905, 40.6422098389, -74.0760751667, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:33');
INSERT INTO `tracking_point` VALUES(1906, 40.6375204862, -74.1833635273, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:33');
INSERT INTO `tracking_point` VALUES(1907, 40.6892154106, -74.1505762043, 1, 11, '2013-04-07 10:55:24', '2013-04-07 11:06:33');
INSERT INTO `tracking_point` VALUES(1908, 40.8920151893, -74.3793268160, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:34');
INSERT INTO `tracking_point` VALUES(1909, 40.7577656066, -74.0019292788, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:34');
INSERT INTO `tracking_point` VALUES(1910, 40.7547098440, -73.9930887179, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:34');
INSERT INTO `tracking_point` VALUES(1911, 40.7560101857, -73.9973802523, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:35');
INSERT INTO `tracking_point` VALUES(1912, 40.7533444579, -73.9900846438, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:35');
INSERT INTO `tracking_point` VALUES(1913, 40.7509387094, -73.9849348025, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:35');
INSERT INTO `tracking_point` VALUES(1914, 40.7489230153, -73.9794416384, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:36');
INSERT INTO `tracking_point` VALUES(1915, 40.7470373106, -73.9750642733, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:36');
INSERT INTO `tracking_point` VALUES(1916, 40.7458018199, -73.9718885378, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:36');
INSERT INTO `tracking_point` VALUES(1917, 40.7407295650, -73.9736051516, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:36');
INSERT INTO `tracking_point` VALUES(1918, 40.7436598901, -73.9768667177, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:38');
INSERT INTO `tracking_point` VALUES(1919, 40.7450905022, -73.9802141146, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:38');
INSERT INTO `tracking_point` VALUES(1920, 40.7460008757, -73.9851922945, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:38');
INSERT INTO `tracking_point` VALUES(1921, 40.7482767550, -73.9896554903, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:39');
INSERT INTO `tracking_point` VALUES(1922, 40.7506825998, -73.9929170565, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:41');
INSERT INTO `tracking_point` VALUES(1923, 40.7515928968, -73.9976377444, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:41');
INSERT INTO `tracking_point` VALUES(1924, 40.7539336032, -74.0021009402, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:41');
INSERT INTO `tracking_point` VALUES(1925, 40.7545837848, -74.0039892153, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:41');
INSERT INTO `tracking_point` VALUES(1926, 40.7515278760, -74.0061349825, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:41');
INSERT INTO `tracking_point` VALUES(1927, 40.7484718267, -74.0054483370, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:41');
INSERT INTO `tracking_point` VALUES(1928, 40.7484068029, -73.9973802523, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:43');
INSERT INTO `tracking_point` VALUES(1929, 40.7455456905, -73.9926595644, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:43');
INSERT INTO `tracking_point` VALUES(1930, 40.7420991872, -73.9835615115, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:46');
INSERT INTO `tracking_point` VALUES(1931, 40.7392378035, -73.9771242098, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:47');
INSERT INTO `tracking_point` VALUES(1932, 40.7337097818, -73.9763517336, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:47');
INSERT INTO `tracking_point` VALUES(1933, 40.7372217547, -73.9799566225, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:49');
INSERT INTO `tracking_point` VALUES(1934, 40.7386525053, -73.9845056490, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:53');
INSERT INTO `tracking_point` VALUES(1935, 40.7386525053, -73.9845056490, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:53');
INSERT INTO `tracking_point` VALUES(1936, 40.7422292472, -73.9890975909, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:57');
INSERT INTO `tracking_point` VALUES(1937, 40.7456107172, -73.9890117602, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:57');
INSERT INTO `tracking_point` VALUES(1938, 40.7476915363, -73.9942903475, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:57');
INSERT INTO `tracking_point` VALUES(1939, 40.7454156370, -73.9954490618, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:58');
INSERT INTO `tracking_point` VALUES(1940, 40.7412537912, -73.9919300036, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:58:59');
INSERT INTO `tracking_point` VALUES(1941, 40.7425543960, -73.9974660830, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:00');
INSERT INTO `tracking_point` VALUES(1942, 40.7447978795, -74.0031738238, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:00');
INSERT INTO `tracking_point` VALUES(1943, 40.7509426859, -74.0034313158, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:01');
INSERT INTO `tracking_point` VALUES(1944, 40.7406359950, -73.9999551729, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:01');
INSERT INTO `tracking_point` VALUES(1945, 40.7396279994, -73.9936895327, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:01');
INSERT INTO `tracking_point` VALUES(1946, 40.7368965798, -73.9878530459, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:02');
INSERT INTO `tracking_point` VALUES(1947, 40.7347178671, -73.9831323580, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:02');
INSERT INTO `tracking_point` VALUES(1948, 40.7405384477, -73.9811153368, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:03');
INSERT INTO `tracking_point` VALUES(1949, 40.7340024533, -73.9800853686, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:03');
INSERT INTO `tracking_point` VALUES(1950, 40.7317260856, -73.9777250246, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:03');
INSERT INTO `tracking_point` VALUES(1951, 40.7293520763, -73.9758367495, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:03');
INSERT INTO `tracking_point` VALUES(1952, 40.7308480372, -73.9818448977, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:04');
INSERT INTO `tracking_point` VALUES(1953, 40.7329943572, -73.9873380617, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:04');
INSERT INTO `tracking_point` VALUES(1954, 40.7348154229, -73.9903850512, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:05');
INSERT INTO `tracking_point` VALUES(1955, 40.7368315446, -73.9963502840, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:06');
INSERT INTO `tracking_point` VALUES(1956, 40.7388150886, -73.9996118502, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:06');
INSERT INTO `tracking_point` VALUES(1957, 40.7407335421, -74.0036458926, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:08');
INSERT INTO `tracking_point` VALUES(1958, 40.7425869108, -74.0068645434, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:08');
INSERT INTO `tracking_point` VALUES(1959, 40.7388150886, -74.0068645434, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:08');
INSERT INTO `tracking_point` VALUES(1960, 40.7355958644, -74.0069074587, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:09');
INSERT INTO `tracking_point` VALUES(1961, 40.7366039210, -74.0013284640, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:09');
INSERT INTO `tracking_point` VALUES(1962, 40.7328642792, -74.0018863634, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:09');
INSERT INTO `tracking_point` VALUES(1963, 40.7331894738, -73.9966077761, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:10');
INSERT INTO `tracking_point` VALUES(1964, 40.7297748513, -73.9920587496, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:10');
INSERT INTO `tracking_point` VALUES(1965, 40.7310431601, -73.9869089083, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:10');
INSERT INTO `tracking_point` VALUES(1966, 40.7265226669, -73.9872093157, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:11');
INSERT INTO `tracking_point` VALUES(1967, 40.7278235598, -73.9831323580, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:12');
INSERT INTO `tracking_point` VALUES(1968, 40.7252867952, -73.9801282839, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:12');
INSERT INTO `tracking_point` VALUES(1969, 40.7232377994, -73.9763517336, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:12');
INSERT INTO `tracking_point` VALUES(1970, 40.7254494112, -73.9754934267, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:13');
INSERT INTO `tracking_point` VALUES(1971, 40.7277910377, -73.9751501040, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:13');
INSERT INTO `tracking_point` VALUES(1972, 40.7283113880, -73.9780683474, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:14');
INSERT INTO `tracking_point` VALUES(1973, 40.7305553519, -73.9786262469, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:14');
INSERT INTO `tracking_point` VALUES(1974, 40.7332545125, -73.9832611040, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:14');
INSERT INTO `tracking_point` VALUES(1975, 40.7348479415, -73.9860076861, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:15');
INSERT INTO `tracking_point` VALUES(1976, 40.7373193068, -73.9938182787, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:15');
INSERT INTO `tracking_point` VALUES(1977, 40.7344251987, -73.9933891253, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:15');
INSERT INTO `tracking_point` VALUES(1978, 40.7348804600, -73.9966936068, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:16');
INSERT INTO `tracking_point` VALUES(1979, 40.7394003854, -73.9964790301, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:16');
INSERT INTO `tracking_point` VALUES(1980, 40.7419366119, -73.9955778078, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:17');
INSERT INTO `tracking_point` VALUES(1981, 40.7428145139, -73.9864797549, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:17');
INSERT INTO `tracking_point` VALUES(1982, 40.7402132890, -73.9864797549, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:17');
INSERT INTO `tracking_point` VALUES(1983, 40.7396605156, -73.9889259295, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:18');
INSERT INTO `tracking_point` VALUES(1984, 40.7379696509, -73.9905567126, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:18');
INSERT INTO `tracking_point` VALUES(1985, 40.7362137074, -73.9903421358, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:18');
INSERT INTO `tracking_point` VALUES(1986, 40.7389776716, -73.9793558077, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:18');
INSERT INTO `tracking_point` VALUES(1987, 40.7408310891, -73.9775533633, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:19');
INSERT INTO `tracking_point` VALUES(1988, 40.7428470286, -73.9792699770, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:19');
INSERT INTO `tracking_point` VALUES(1989, 40.7442126302, -73.9824457125, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:20');
INSERT INTO `tracking_point` VALUES(1990, 40.7455294338, -73.9822740511, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:20');
INSERT INTO `tracking_point` VALUES(1991, 40.7513165579, -73.9913506464, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:21');
INSERT INTO `tracking_point` VALUES(1992, 40.7493008752, -73.9872307734, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:21');
INSERT INTO `tracking_point` VALUES(1993, 40.7481954749, -73.9841408686, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:21');
INSERT INTO `tracking_point` VALUES(1994, 40.7466999041, -73.9793343500, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:22');
INSERT INTO `tracking_point` VALUES(1995, 40.7444239708, -73.9746994929, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:22');
INSERT INTO `tracking_point` VALUES(1996, 40.7424731089, -73.9732403712, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:22');
INSERT INTO `tracking_point` VALUES(1997, 40.7439037466, -73.9989895777, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:23');
INSERT INTO `tracking_point` VALUES(1998, 40.7473501564, -74.0013070063, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:23');
INSERT INTO `tracking_point` VALUES(1999, 40.7534622175, -73.9992470698, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:23');
INSERT INTO `tracking_point` VALUES(2000, 40.7559328913, -74.0012211756, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:23');
INSERT INTO `tracking_point` VALUES(2001, 40.7591186245, -73.9987320856, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:23');
INSERT INTO `tracking_point` VALUES(2002, 40.7572332090, -73.9928097681, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:26');
INSERT INTO `tracking_point` VALUES(2003, 40.7546975659, -73.9905781702, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:26');
INSERT INTO `tracking_point` VALUES(2004, 40.7525519462, -73.9847416834, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:27');
INSERT INTO `tracking_point` VALUES(2005, 40.7508614091, -73.9797635035, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:27');
INSERT INTO `tracking_point` VALUES(2006, 40.7493008752, -73.9758152918, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:28');
INSERT INTO `tracking_point` VALUES(2007, 40.7476752802, -73.9713520960, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:28');
INSERT INTO `tracking_point` VALUES(2008, 40.7440988312, -73.9908356623, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:28');
INSERT INTO `tracking_point` VALUES(2009, 40.7366852153, -74.0035386042, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:29');
INSERT INTO `tracking_point` VALUES(2010, 40.7314821844, -73.9989037470, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:30');
INSERT INTO `tracking_point` VALUES(2011, 40.7301163214, -73.9955563502, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:31');
INSERT INTO `tracking_point` VALUES(2012, 40.7277747767, -73.9913506464, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:31');
INSERT INTO `tracking_point` VALUES(2013, 40.7290756451, -73.9865441279, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:32');
INSERT INTO `tracking_point` VALUES(2014, 40.7290756451, -73.9809651331, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:32');
INSERT INTO `tracking_point` VALUES(2015, 40.7269942435, -73.9802784876, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:32');
INSERT INTO `tracking_point` VALUES(2016, 40.7254331497, -73.9837117152, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:32');
INSERT INTO `tracking_point` VALUES(2017, 40.7462447236, -73.9979596094, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:33');
INSERT INTO `tracking_point` VALUES(2018, 40.7676348352, -74.0441365198, 1, 12, '2013-04-07 10:57:34', '2013-04-07 10:59:33');

-- --------------------------------------------------------

--
-- Table structure for table `tracking_region`
--

CREATE TABLE `tracking_region` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `lat` decimal(13,10) NOT NULL,
  `lng` decimal(13,10) NOT NULL,
  `radius` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tracking_region`
--

INSERT INTO `tracking_region` VALUES(1, 'North East Manhattan', 40.8112511934, -73.9596147494, 1);
INSERT INTO `tracking_region` VALUES(10, 'Upper East Side / Midtown East', 40.8211247423, -74.0638132052, 1);
INSERT INTO `tracking_region` VALUES(11, 'Staten Island', 40.8909770491, -74.3697137789, 1);
INSERT INTO `tracking_region` VALUES(12, 'Manhattan Chelsea', 40.8920151893, -74.3793268160, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) DEFAULT NULL,
  `first_name` varchar(128) DEFAULT NULL,
  `last_name` varchar(128) DEFAULT NULL,
  `picture_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `user`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_meta_eventbrite`
--

CREATE TABLE `user_meta_eventbrite` (
  `id` bigint(20) NOT NULL,
  `eventbrite_user_id` bigint(20) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `eventbrite_user_id` (`eventbrite_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_meta_eventbrite`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_meta_facebook`
--

CREATE TABLE `user_meta_facebook` (
  `id` bigint(20) NOT NULL,
  `facebook_user_id` bigint(20) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `facebook_user_id` (`facebook_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_meta_facebook`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_meta_foursquare`
--

CREATE TABLE `user_meta_foursquare` (
  `id` bigint(20) NOT NULL,
  `foursquare_user_id` bigint(20) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `foursquare_user_id` (`foursquare_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_meta_foursquare`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_meta_instagram`
--

CREATE TABLE `user_meta_instagram` (
  `id` bigint(20) NOT NULL,
  `instagram_user_id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `instagram_user_id` (`instagram_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_meta_instagram`
--


-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE `venue` (
  `id` int(12) NOT NULL,
  `lat` decimal(13,10) NOT NULL,
  `lng` decimal(13,10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `postalCode` varchar(32) DEFAULT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(3) DEFAULT NULL,
  `cc` varchar(3) NOT NULL,
  `region_id` int(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `region_id` (`region_id`),
  KEY `lat` (`lat`,`lng`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` VALUES(1, 40.8094770000, -73.9591410000, 'Apple Tree Supermarket', '1225 Amsterdam Ave', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(2, 40.7964230000, -73.9476260000, 'NYC Fresh Market', '1660 Madison Ave', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(3, 40.7961480000, -73.9485970000, 'Fine Fare', '1718 Madison Ave', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(4, 40.7974980000, -73.9501690000, 'Central Park Gourmet Grocery', '9 W 110th Street', '10026', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(5, 40.7951310000, -73.9454740000, 'S&D Grocery', '123 East 110th Street', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(6, 40.7945460000, -73.9438090000, 'Met Supermarket', '160 E. 110th St.', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(7, 40.7947320000, -73.9407670000, 'Food Choice', '2029 Third Ave', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(8, 40.7947840000, -73.9419380000, 'Farm Country', '-', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(9, 40.7941020000, -73.9433290000, 'Little Mexico Meat Grocery Inc', '2001 3rd Avenue', '10035', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(10, 40.7908420000, -73.9391900000, 'Pioneer Supermarket', '-', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(11, 40.7905080000, -73.9394060000, 'Mauricio''s Marketplace', '2076 1st Avenue', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(12, 40.7850480000, -73.9490210000, 'Gristedes Supermarkets #098', '202 E 96th St', '10128', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(13, 40.7870130000, -73.9474330000, 'Farmers Market', '99th & 3rd', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(14, 40.7863990000, -73.9523390000, 'Gourmet Garage', '1245 Park Ave', '10128', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(15, 40.7888310000, -73.9526730000, 'Farmers Market', 'E99th & Madison', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(16, 40.7889080000, -73.9525470000, 'Mt. Sinai Hospital Greenmarket', '99th St between Madison & Park Aves', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(17, 40.7927260000, -73.9502620000, 'Madison Deli & Grocery', '1550 Madison Avenue', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(18, 40.7902290000, -73.9524080000, 'Mount Sinai CSA', '99th', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(19, 40.7874880000, -73.9445380000, 'Associated Supermarket', '1968 2nd Ave', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(20, 40.7876160000, -73.9442400000, 'Mexican Supermarket', '1974 2nd Avenue', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(21, 40.7908650000, -73.9408990000, 'Associated Supermarket', '108th Street', '0', '-', '-', 'US', 1);
INSERT INTO `venue` VALUES(22, 40.7914680000, -73.9436600000, 'Foodtown', '235 East 106th Street', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(23, 40.7916710000, -73.9460940000, 'Associated Supermarket', '2nd Avenue', '10029', 'New York', 'New', 'US', 1);
INSERT INTO `venue` VALUES(24, 40.7916980000, -73.9469170000, 'Weird Corner Store', '-', '0', '-', '-', 'US', 1);
INSERT INTO `venue` VALUES(25, 40.7993720000, -73.9518680000, 'Fine Fare 112th/Lenox', '37 Lenox Ave.', '10026', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(26, 40.7997940000, -73.9541470000, 'Project Harmony CSA', 'West 122nd Street', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(27, 40.7995560000, -73.9519710000, 'Shop Fair', '37 Lenox Ave', '10026', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(28, 40.8017070000, -73.9573500000, 'Organic Forever', '2053 8th Ave', '10026', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(29, 40.8059960000, -73.9542960000, 'Best Yet Market', '2187 Frederick Douglass Blvd.', '10026', 'Harlem', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(30, 40.8041860000, -73.9546580000, 'C-Town Supermarkets', '238 W 116Th Street', '10026', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(31, 40.8060460000, -73.9543280000, 'Best Yet Market in Harlem', '2187 Frederick Douglass Blvd', '10026', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(32, 40.8122340000, -73.9569710000, 'Met foodmarkets', '1316 Amsterdam Ave', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(33, 40.8112210000, -73.9542670000, 'Citarella', '125th Street', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(34, 40.8120390000, -73.9548330000, 'Key Food', '421 W. 125th Street', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(35, 40.8145940000, -73.9577860000, 'C-Town Supermarkets', '560 W 125Th Street', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(36, 40.8158380000, -73.9585420000, 'Fresh Direct Delivery', '-', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(37, 40.8143120000, -73.9592670000, 'Thirfty Grocery', '3140-3176 Broadway', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(38, 40.8185760000, -73.9573500000, 'Cold Room At Fairway', '2328 12th ave', '0', 'New york', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(39, 40.8194740000, -73.9553930000, 'C-Town Supermarkets', '3320 Broadway', '10031', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(40, 40.8195320000, -73.9551520000, 'Hamilton Meat Market', '-', '10031', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(41, 40.8207530000, -73.9548470000, 'Mi Pais Market', 'Broadway', '10031', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(42, 40.8268910000, -73.9500260000, 'C-Town Supermarkets', '3550 Broadway', '10031', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(43, 40.8292920000, -73.9483610000, 'C-Town Supermarkets', '3632 Broadway', '10031', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(44, 40.8295390000, -73.9483930000, 'Silver Saddle Grocery', '3635 Broadway', '10031-2518', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(45, 40.8426130000, -73.9420650000, 'Fort Washington Greenmarket Farmers Market', 'Fort Washington Avenue', '10032', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(46, 40.8461300000, -73.9384760000, 'Bravo Supermarket', '4138 Broadway', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(47, 40.8470000000, -73.9382930000, 'La Rosa Fine Foods', '4161 Broadway', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(48, 40.8461920000, -73.9383040000, 'Farmers Market', '650-698 W 175th St', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(49, 40.8445290000, -73.9391220000, 'Washington Heights Grocery Discount', 'Broadway', '10032', 'Nyc', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(50, 40.8441390000, -73.9391680000, 'Broadway Farm Meat Warehouse', '4081 Broadway', '10032', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(51, 40.8447730000, -73.9371880000, 'Finefare', '-', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(52, 40.8434910000, -73.9382010000, 'Fine Fare', '1239 Saint Nicholas Ave.', '10032', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(53, 40.8438830000, -73.9358550000, 'la Antillana Supermercado', '1278-74 St Nicholas ave.', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(54, 40.8450520000, -73.9351080000, 'New Way Supermarket', '202 Audubon Ave', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(55, 40.8417640000, -73.9373860000, 'La Esperanza Supermarket', '97 Audubon Ave, New York, NY 10032', '10032', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(56, 40.8352010000, -73.9402790000, 'C-Town Supermarkets', '1016 St Nicholas Ave', '10032', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(57, 40.8352220000, -73.9403530000, 'Plaza Grocery', '-', '0', '-', '-', 'US', 1);
INSERT INTO `venue` VALUES(58, 40.8424710000, -73.9393660000, 'Gristedes Supermarkets #504', '4037 Broadway', '10032', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(59, 40.8423730000, -73.9419840000, 'Tuesday Fort Washington Farmers Market', '-', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(60, 40.8419850000, -73.9420760000, 'Columbia Medical School Farmers Market', '-', '0', '-', '-', 'US', 1);
INSERT INTO `venue` VALUES(61, 40.8334540000, -73.9418340000, 'J & F Meat Market', '-', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(62, 40.8323170000, -73.9360540000, 'Compare Foods', '-', '0', '-', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(63, 40.8213440000, -73.9389750000, 'Fine Fare', '2497 7th Ave', '10030', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(64, 40.8232570000, -73.9378160000, 'Associated Supermarket', '2544 7th Ave', '10039', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(65, 40.8169310000, -73.9384360000, 'Key Food', '592 Lenox Ave', '10037', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(66, 40.8042310000, -73.9368400000, 'Pathmark', '160 E 125th St.', '10035', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(67, 40.8047870000, -73.9372250000, 'triana deli & grocery', '2085 Lexington Avenue', '10035', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(68, 40.8056230000, -73.9378390000, 'Harvest Home Go Green Market', '106th St between Lexington & 3rd Ave', '10035', 'Manhattan', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(69, 40.7981270000, -73.9337290000, 'Fine Fare', '2330 1st Ave', '10035', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(70, 40.7955850000, -73.9325920000, 'Aldi', '517 East 117th Street', '10035', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(71, 40.7952670000, -73.9312490000, 'Costco Wholesale Club', '517 E 117th St', '10035', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(72, 40.7958270000, -73.9379080000, 'Compare Foods', '309 E 115th St', '10029', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(73, 40.7966760000, -73.9367430000, 'Fruit and Vegetable Truck', '116th (Outside Hudson Valley Bank)', '10029', 'Ny', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(74, 40.8009700000, -73.9374890000, 'Associated', '2212 3rd Ave', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(75, 40.7987300000, -73.9436940000, 'La Marqueta', '1607 Park Ave', '10029', 'New York,', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(76, 40.8062500000, -73.9418350000, 'Wild Olive Market', '10 E 125th St', '10035', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(77, 40.8020990000, -73.9494900000, 'Fine Fare Supermarket', '136 Lenox Ave', '10035', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(78, 40.8047790000, -73.9473870000, 'Harvest Home Mt. Morris Park Market', 'Lenox Ave.', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(79, 40.8124630000, -73.9417430000, 'Associated Supermarket', '448 Lenox Avenue', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(80, 40.8164120000, -73.9464670000, 'Corner Fruit Stand', '-', '10030', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(81, 40.8162780000, -73.9540390000, 'Associated Supermarket', '1436 Amsterdam Ave', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(82, 40.8299390000, -73.9431430000, 'Foodtown Supermarket', '-', '10031', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(83, 40.8226430000, -73.9422370000, 'Pathmark', '300 W 145th St.', '10039', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(84, 40.8154340000, -73.9441590000, 'Central Harlem CSA', '200 W.135th St.', '10030', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(85, 40.8128820000, -73.9454340000, 'C-Town Supermarkets', '2217 Adam C Powell Blvd', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(86, 40.8089090000, -73.9477470000, '125th St. Farmer''s Market', 'Adam Clayton Powell State Office Building Plaza', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(87, 40.8070860000, -73.9439540000, 'Watkins Health Foods', '54 W 125 St', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(88, 40.8056560000, -73.9427090000, 'Mount Morris - Marcus Garvey Park Farmer''s Market', '18 Mount Morris Park', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(89, 40.8074380000, -73.9441130000, 'Young Spring Farm', '62 W 125th St.', '10027', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(90, 40.7953580000, -73.9310570000, 'Target', '517 E 117th St.', '10035', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(91, 40.8233380000, -73.9375580000, 'Pioneer Supermarket', '2544 7th Avenue', '10039', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(92, 40.8200120000, -73.9404170000, 'Associated Market', 'Adam Clayton Powell', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(93, 40.8232890000, -73.9444060000, 'Farmer''s market', '-', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(94, 40.8240310000, -73.9434010000, 'Grassroots Farmer''s Market', '145th St', '10031', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(95, 40.8145660000, -73.9478330000, 'Fine Fare Supermarket', '2463 8th Ave.', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(96, 40.8295130000, -73.9374720000, 'Fine Fare Supermarket', '2927 Frederick Douglas Blvd', '10039', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(97, 40.8493980000, -73.9369900000, 'Street Fruit Market', '-', '0', '-', '-', 'US', 1);
INSERT INTO `venue` VALUES(98, 40.8538840000, -73.9339010000, 'Key Food', '4365 Broadway', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(99, 40.8580550000, -73.9325750000, 'Uptown Super Market', '4482 Broadway', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(100, 40.8701990000, -73.9155010000, 'Associated Supermarket', '5069 Broadway', '10034', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(101, 40.8697160000, -73.9174710000, 'Antillana Food Plaza', '-', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(102, 40.8637990000, -73.9181880000, 'Pathmark', '410 W 207th St.', '10034', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(103, 40.8608500000, -73.9269950000, 'La Salle', '117 Nagle Ave', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(104, 40.8615280000, -73.9278390000, 'Antillana', '-', '10040', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(105, 40.8553750000, -73.9294000000, 'Fine Fare', '191st Street', '10034', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(106, 40.8553380000, -73.9294910000, 'Deli Grocery & Convenience Store - 191 Subway', 'St. Nicholas Ave', '10040', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(107, 40.8481800000, -73.9347480000, 'Tu Pais Supermarket', '1464 St Nicholas Ave', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(108, 40.8478720000, -73.9347270000, 'California Fruit Market', '1456 W 183rd St.', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(109, 40.8480530000, -73.9348210000, 'Bridge Food', '1365 St. Nicholas Ave.', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(110, 40.8476240000, -73.9338320000, 'Rey Grocery', '288 Audubon Avenue', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(111, 40.8485660000, -73.9337120000, 'C&C Natural Nutrition', '561 W. 179th St.', '10033', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(112, 40.8549610000, -73.9367710000, 'Associated Supermarket', '592 Fort Washington Ave', 'US', 'Manhattan', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(113, 40.8552680000, -73.9372110000, 'Frank''s Market', '807 W 187th St', '10040', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(114, 40.8546250000, -73.9372190000, 'Associated Market - 187th', 'Ft. Washington', '0', 'New York', 'NY', 'US', 1);
INSERT INTO `venue` VALUES(115, 40.7858640000, -73.9509440000, 'Associated Supermarket', '1486 Lexington Ave', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(116, 40.7811440000, -73.9461630000, 'Farmers Market 93rd', '-', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(117, 40.7850390000, -73.9557490000, 'Patrick Murphy Groceries', '1307 Madison Avenue', '0', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(118, 40.7837470000, -73.9579650000, 'Community Supported Agriculture (CSA) - Carnegie Hill', '-', '0', '-', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(119, 40.7818450000, -73.9492740000, 'Key Food', '1769 2nd Ave.', '10029', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(120, 40.7828930000, -73.9508090000, 'Food For Health', '1653 Third Avenue', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(121, 40.7791400000, -73.9479370000, 'C-Town Supermarkets', '1721 First Ave, New York', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(122, 40.7782930000, -73.9486600000, 'Elm Health', '1695 1st Ave.', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(123, 40.7808180000, -73.9466510000, 'Straight From The Market', '408A E 92nd St', '10128', 'New York', 'New', 'US', 10);
INSERT INTO `venue` VALUES(124, 40.7803270000, -73.9478390000, 'Turkish Market', '-', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(125, 40.7806390000, -73.9467000000, '92nd Street Greenmarket', '1st Ave', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(126, 40.7788100000, -73.9479700000, 'C-Town Supermarkets', '1721 First Avenue', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(127, 40.7793940000, -73.9452380000, 'The Vinegar Factory', '431 East 91st Street', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(128, 40.7763730000, -73.9469200000, 'Gristedes Supermarkets #053', '1644 York Ave.', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(129, 40.7795790000, -73.9458990000, 'Eli Zabar', '91st Street', '0', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(130, 40.7758680000, -73.9495550000, 'picklesandolives', '1647 First Avenue', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(131, 40.7718270000, -73.9500830000, 'D''Agostino', '1507 York Ave.', '10075', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(132, 40.7741070000, -73.9507890000, 'Greenmarket Farmers Market', '414 East 82nd Street', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(133, 40.7740420000, -73.9501330000, '82nd Street Greenmarket', '82nd St.', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(134, 40.7719620000, -73.9508630000, 'Associated Supermarket Between 81 And 82', '-', '10021', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(135, 40.7633810000, -73.9592740000, 'Gristedes Supermarkets #512', '1208 1st Ave.', '10021', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(136, 40.7615350000, -73.9606100000, 'Space Market', '1130 1st Avenue', '10065', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(137, 40.7628990000, -73.9593020000, 'Fruit Cart', 'First Ave @ 65th St.', '10065', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(138, 40.7597980000, -73.9615750000, 'Food Emporium', '405 E 59th St', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(139, 40.7599830000, -73.9593940000, 'Grocery Store For Sale', '-', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(140, 40.7589040000, -73.9593590000, 'Grocery Store For Rent', '-', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(141, 40.7579330000, -73.9632510000, 'D''Agostino at 56th Street', '1033 1st Ave', '10022-2901', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(142, 40.7559210000, -73.9646110000, 'D''agostino Grocery Store', '1031 1st Ave, New York, NY 10022', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(143, 40.7557100000, -73.9647890000, 'D''Agostino at 53rd Street', '966 1st Ave', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(144, 40.7526290000, -73.9697030000, 'Dag Hammarskjold Greenmarket', '47th St', '10017', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(145, 40.7540010000, -73.9689160000, 'Fruit Stand 49th And 2nd', '-', '0', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(146, 40.7507500000, -73.9715790000, 'Health Harvest Health Food Store', '820 Second Ave', '10017', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(147, 40.7508540000, -73.9724190000, 'Street Market at 43rd St.', 'East 43rd St.', '0', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(148, 40.7520280000, -73.9756020000, 'Greenwich Produce', 'Grand Central Terminal', '10017', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(149, 40.7816150000, -73.9581080000, 'Food Emporium', '1211 Madison Ave', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(150, 40.7815380000, -73.9541470000, 'Gristedes Supermarkets #437', '1343 Lexington Ave.', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(151, 40.7782350000, -73.9515240000, 'Food Emporium', '1660 2nd Ave.', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(152, 40.7783740000, -73.9525570000, 'Fairway Market', '240 E 86th St.', '10128', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(153, 40.7771880000, -73.9499800000, 'Gristedes Supermarkets #050', '350 E 86th St.', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(154, 40.7779960000, -73.9521420000, 'The Vitamin Shoppe', '244 E 86th Street', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(155, 40.7723470000, -73.9526780000, 'The Vitamin Shoppe', '1513 First Ave', '10075', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(156, 40.7738040000, -73.9515300000, 'Morton Williams', '1565 1st Ave.', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(157, 40.7674160000, -73.9562310000, 'Food Emporium', '1331 1st Ave.', '10021', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(158, 40.7634480000, -73.9613740000, 'Gourmet Garage', '301 E 64th St', '10065', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(159, 40.7638190000, -73.9605530000, 'Fruit Stand 2nd Ave', '64th St', '10065', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(160, 40.7596590000, -73.9660970000, 'Whole Foods Market', '226 E 57th St', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(161, 40.7612690000, -73.9655920000, 'Katagiri', '224 E 59th St.', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(162, 40.7570840000, -73.9679460000, 'Tomiya Japanese Grocery Store', '239 East 53rd St', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(163, 40.7558090000, -73.9679000000, 'Food Emporium', '969 2nd Ave', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(164, 40.7545470000, -73.9687690000, 'Concept stand 49', '-', '10017', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(165, 40.7535400000, -73.9715590000, 'Dag Hammarskjöld Plaza', 'Dag Hammarskjöld Plaza', '10017', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(166, 40.7539620000, -73.9691450000, 'Morton Williams', '908 2nd Ave', '10017', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(167, 40.7545570000, -73.9734100000, 'Dainobu', '129 E 47th St.', '10017', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(168, 40.7547110000, -73.9734470000, 'Diamobu Japanese Deli Grocery', '129 E. 47th St.', '10017', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(169, 40.7530040000, -73.9697940000, 'Daj Hamerschold Plaza Farmers Market', 'Dag Hammarskjold Plaza', '10017', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(170, 40.7561530000, -73.9715390000, 'Tutties Grocery', '135 E. 50th St.', '0', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(171, 40.7611090000, -73.9690990000, 'The Vitamin Shoppe', '139 E 57th St', '10022', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(172, 40.7639670000, -73.9668780000, 'Smiley''s', '802 Lexington Avenue', '10065', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(173, 40.7641920000, -73.9644730000, 'Food Emporium', '1066 3rd Ave', '10065', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(174, 40.7675320000, -73.9623380000, 'Food Emporium Illy Cafe', '1175 3rd Ave.', '10021', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(175, 40.7709340000, -73.9567130000, 'Gristedes Supermarkets', '1446 2nd Ave', '10021', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(176, 40.7715700000, -73.9566730000, '#1 Farmers Market', '-', '0', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(177, 40.7714730000, -73.9593070000, 'Jowny Market', '1305 Third Ave', '10021', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(178, 40.7707180000, -73.9572410000, 'International Fine Food', '1095 2nd Ave', '0', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(179, 40.7727900000, -73.9604960000, 'D''Agostino at 76th Street', '1074 Lexington Ave', '10075', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(180, 40.7741110000, -73.9595460000, 'Butterfield Market', '1114 Lexington Ave', '10075', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(181, 40.7777290000, -73.9568700000, 'D''Agostino at 83rd Street', '1233 Lexington Ave.', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(182, 40.7754570000, -73.9564160000, 'Natural Frontier Market', '1424 3rd Ave.', '10075', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(183, 40.7733000000, -73.9580790000, 'Gristedes Supermarkets #413', '1365 3rd Ave', '10075', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(184, 40.7763520000, -73.9557890000, 'Food Emporium', '1450 3rd Ave', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(185, 40.7719140000, -73.9590090000, 'Citarella', '1313 3rd Ave.', '10021', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(186, 40.7779270000, -73.9546700000, 'Eastside Health Food', '1498 3rd Ave.', '10028', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(187, 40.7781250000, -73.9566040000, 'Fruit Stand', 'e 84 st and Lexington ave', '10021', 'New York', 'NY', 'US', 10);
INSERT INTO `venue` VALUES(188, 40.7546780000, -73.9952180000, 'Sugar Deli', '468 9th Ave', '10018', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(189, 40.7556380000, -73.9951610000, 'Long Island City Green Market', 'Vernon Blvd & 48th Ave', '11101', 'Queens', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(190, 40.7516450000, -73.9903680000, 'The Vitamin Shoppe', '460 7th Ave', '10001', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(191, 40.7514400000, -73.9898890000, 'Organic Market on 7th', '7th Avenue', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(192, 40.7495780000, -73.9836640000, 'The Vitamin Shoppe', '385 Fifth Ave.', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(193, 40.7484840000, -73.9761130000, 'D''Agostino at 38th Street', '578 3rd Ave', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(194, 40.7476520000, -73.9738110000, 'Kool Bloo', '719 2nd Ave', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(195, 40.7465880000, -73.9775360000, 'D''Agostino at 35th Street', '528 3rd Avenue', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(196, 40.7472280000, -73.9769700000, 'healthsmart of ny', '550 3rd Ave', '10016', 'New york', 'Ny', 'US', 12);
INSERT INTO `venue` VALUES(197, 40.7462790000, -73.9720900000, 'Novello Market', '333 E 38th St', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(198, 40.7435080000, -73.9768360000, 'Murray Hill Farmers Market', '2nd Ave.', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(199, 40.7424590000, -73.9775480000, 'Fairway Market', '550 Second Ave.', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(200, 40.7449480000, -73.9765780000, 'CVS/pharmacy', '222 E 34th St', '10016-4842', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(201, 40.7425800000, -73.9774670000, 'Rite Aid', '542-576 Second Avenue', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(202, 40.7445150000, -73.9791360000, 'Gristedes Supermarkets', '460 3rd Ave', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(203, 40.7442420000, -73.9793210000, 'Food Emporium', '200 E 32nd St', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(204, 40.7449480000, -73.9783340000, 'fruit stand at 34st & 3rd ave', '-', '0', '-', '-', 'US', 12);
INSERT INTO `venue` VALUES(205, 40.7434890000, -73.9763200000, 'Sunday Market', '-', '0', '-', '-', 'US', 12);
INSERT INTO `venue` VALUES(206, 40.7463200000, -73.9796770000, 'Murray Hill Market', '243 Lexington Ave.', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(207, 40.7432200000, -73.9805090000, 'Fruit Cart', '33rd and 2nd Avenue', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(208, 40.7475260000, -73.9862480000, 'Han Au Mart', '25 w 35th Street', '10001', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(209, 40.7443380000, -73.9861030000, 'Prince George CSA', '14 E. 28th St.', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(210, 40.7479040000, -73.9870630000, 'Hanahreum Asian Mart', '25 W 32nd St.', '10001', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(211, 40.7508120000, -73.9919470000, 'A&H Food Plaza', '7th Ave', '10119', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(212, 40.7517340000, -73.9925010000, 'Cafe ''N'' More', '1 Penn Plaza', '10122', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(213, 40.7499160000, -73.9986960000, 'NSA Markets', '317 9th Avenue', '10001', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(214, 40.7505420000, -73.9984510000, 'cooking up a new birthday cake', '-', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(215, 40.7473260000, -73.9976920000, 'Gristedes Supermarkets #562', '307 W 26th St', '10001', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(216, 40.7448180000, -73.9951520000, 'Whole Foods Market', '250 7th Ave', '10001', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(217, 40.7452920000, -73.9947480000, 'Whole Foods Market', '252 7th Ave', '10001', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(218, 40.7428700000, -73.9824380000, 'Kalustyan''s', '123 Lexington Ave.', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(219, 40.7427440000, -73.9825930000, 'Foods of India', '121 Lexington Ave', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(220, 40.7426230000, -73.9831490000, 'Vestal Farmers Market', 'Library parking lot near museum 320 Vestal Pkwy E', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(221, 40.7393730000, -73.9771090000, 'Harvest Home Farmer''s Market', '445-461 1st Ave', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(222, 40.7376770000, -73.9804290000, 'Morton Williams', '311 E 23rd St.', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(223, 40.7354370000, -73.9797170000, 'Gristedes Supermarkets', '355 1st Ave.', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(224, 40.7395260000, -73.9871170000, 'Morton Williams', '278 Park Ave. S', '10010-6126', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(225, 40.7397110000, -73.9825180000, 'Natural Frontier Market', '325 3rd Ave', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(226, 40.7397000000, -73.9825520000, 'Natural Health Food', '-', '0', '-', '-', 'US', 12);
INSERT INTO `venue` VALUES(227, 40.7422650000, -73.9889110000, 'UnSq Greenmarket @ Madison Sq', 'Madison Sq Park', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(228, 40.7423150000, -73.9891010000, 'Flatiron Farmer''s Market', '1 W 25th St', '10010', 'New York', 'ny', 'US', 12);
INSERT INTO `venue` VALUES(229, 40.7429980000, -73.9906850000, 'Sixth Ave Street Fair', '675 6th Ave', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(230, 40.7439410000, -73.9950440000, 'Garden of Eden', '162 W 23rd St.', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(231, 40.7417400000, -73.9936500000, 'Trader Joe''s', '675 6th Ave', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(232, 40.7415500000, -73.9937640000, 'The Vitamin Shoppe', '655 6th Ave', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(233, 40.7426080000, -73.9926410000, 'Fruit Dealer', '6th Ave.', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(234, 40.7420000000, -73.9971290000, 'Merci Market', '168 7th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(235, 40.7441510000, -73.9991040000, 'Grostedes', '-', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(236, 40.7432850000, -74.0045610000, 'Famous Deli and Grocery', '9th Ave', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(237, 40.7445420000, -74.0009670000, 'PS 11 Farm Market', '21st St.', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(238, 40.7390220000, -73.9993040000, 'Westside Market', '77 7th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(239, 40.7383740000, -73.9998290000, 'Elm Health', '56 7th Ave.', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(240, 40.7385060000, -73.9995640000, 'The Vitamin Shoppe', '154 W 14th St', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(241, 40.7386890000, -73.9886280000, 'Eataly HQ', '45 E 20th St.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(242, 40.7357460000, -73.9896000000, 'The Vitamin Shoppe', '24-30 Union Square E', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(243, 40.7377730000, -73.9883030000, 'Union Market', '7th Avenue', '0', 'Brooklyn', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(244, 40.7363480000, -73.9901160000, 'Knoll Krest Farm', 'Union Square Greenmarket Stand', '10003', 'Manhattan', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(245, 40.7369900000, -73.9902310000, 'Pulaski Farmers Market', 'South Park center of village', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(246, 40.7364450000, -73.9902600000, 'Tremblay Apiaries', '-', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(247, 40.7366470000, -73.9902830000, 'Tello''s Green Farm', '-', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(248, 40.7366920000, -73.9901810000, 'Three Corner Field Farm Stand', '-', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(249, 40.7403440000, -73.9820530000, 'D''Agostino Supermarket', '341 3rd Ave.', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(250, 40.7341280000, -73.9804460000, 'Gracefully', '320 1st Ave', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(251, 40.7313660000, -73.9781910000, 'Stuyvesant Town Greenmarket', 'Stuyvesant Oval', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(252, 40.7309500000, -73.9813700000, 'Associated Supermarket', '435 14th St', '10009-2700', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(253, 40.7299330000, -73.9807330000, 'Zaragoza Mexican Deli-Grocery', '215 Ave. A', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(254, 40.7313480000, -73.9827990000, 'The Vitamin Shoppe', '237 1st Avenue', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(255, 40.7301960000, -73.9807790000, 'Johnny Air Mart', '214 Ave A', '10009-3709', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(256, 40.7306860000, -73.9805490000, 'Stuyvesant Convenience Deli & Grocery', '14th St Loop', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(257, 40.7336230000, -73.9877690000, 'Trader Joe''s', '142 East 14th Street', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(258, 40.7338790000, -73.9881850000, 'Trader Joe''s Wine Shop', '138 E. 14th St.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(259, 40.7312410000, -73.9886470000, 'M2M Mart', '200 E 11th St', '10003-7320', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(260, 40.7330210000, -73.9879540000, 'Paffenroth Farms', 'Union Square Greenmarket', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(261, 40.7347330000, -73.9863570000, 'Health Food Store', '162 3rd ave', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(262, 40.7325890000, -73.9853250000, 'C&B Convenience Store', '248 E 14th St', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(263, 40.7348520000, -73.9910850000, 'Whole Foods Market', '4 Union Square', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(264, 40.7344380000, -73.9895250000, 'Food Emporium', '10 Union Sq E', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(265, 40.7365270000, -73.9905600000, 'Union Square Greenmarket', '1 Union Square W', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(266, 40.7357880000, -73.9910630000, 'Farmer''s Market', '64 W 9th St.', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(267, 40.7349990000, -73.9919330000, 'Sarah''s Fruit Stand', 'University Place', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(268, 40.7364130000, -73.9904090000, 'Breezy Hill Orchards @ Union Sq Greenmarket', 'Union Sq West', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(269, 40.7366010000, -73.9905710000, 'Martin''s Pretzels', '-', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(270, 40.7362180000, -73.9908550000, 'Valley Shepherd Creamery', '-', '0', 'New York City', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(271, 40.7363850000, -73.9908530000, 'Paffenroth Gardens', 'Union Squares', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(272, 40.7368440000, -73.9903830000, 'Tundra Brewery', '-', '0', 'New York City', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(273, 40.7360000000, -73.9908910000, 'Milk Thistle Stand', 'Union Square W.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(274, 40.7361460000, -73.9905230000, 'Rick''s Picks @ Union Square Greenmarket', '1 Union Square West', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(275, 40.7368370000, -73.9904320000, 'Berkshire Berries Stand', '-', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(276, 40.7355840000, -73.9909890000, 'Locust Grove Fruit', 'Union Square W.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(277, 40.7331370000, -73.9915250000, 'Max Delivery', '51 White Street', '10013', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(278, 40.7370370000, -73.9969460000, 'GustOrganics', '519 6th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(279, 40.7368750000, -73.9971080000, 'The Vitamin Shoppe', '509 6th Ave. (13th Street)', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(280, 40.7358820000, -73.9979500000, 'Food Emporium', '475 6th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(281, 40.7384920000, -74.0016340000, 'Integral Yoga Foods', '227 W 13th street', '10014', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(282, 40.7420050000, -74.0048190000, 'Chelsea Market', '75 9th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(283, 40.7395510000, -74.0022750000, 'Associated Supermarket', 'W 14th St', '10014', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(284, 40.7408440000, -74.0050850000, '14 Organic Gourmet Foods', '350 W 14th St', '10014', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(285, 40.7409980000, -74.0051580000, 'french market', '9th Ave', '10014', 'new york', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(286, 40.7424050000, -74.0063970000, 'Buon Italia', '75 9th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(287, 40.7426730000, -74.0061380000, 'Manhattan Fruit Exchange', '75 9th Ave.', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(288, 40.7423320000, -74.0062810000, 'Nut Box - Chelsea Market', '75 9th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(289, 40.7429330000, -74.0056280000, 'Western Beef', '431 W. 16th St.', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(290, 40.7370590000, -74.0064880000, 'D''Agostino at Greenwich Village', '790 Greenwich St', '10014-1879', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(291, 40.7371290000, -74.0055580000, 'Abingdon Square Greenmarket', 'Abigdon Square', '10014', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(292, 40.7330530000, -74.0023290000, 'Gristedes Supermarkets', '3 Sheridan Square', '10014', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(293, 40.7342140000, -74.0025120000, 'Gourmet Garage', '117 7th Ave S', '10014', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(294, 40.7337800000, -73.9995570000, 'Lifethyme Natural Market', '410 Ave of Americas', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(295, 40.7329260000, -74.0001300000, 'The Vitamin Shoppe', '375A Ave of the Americas', '10014', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(296, 40.7336470000, -74.0013970000, 'Corrado''s', '35 Christopher St', '10014', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(297, 40.7326960000, -73.9973650000, 'Eva''s Vitamin Shop', '9 W 8th St', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(298, 40.7341840000, -73.9991320000, 'Citarella', '424 6th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(299, 40.7322520000, -73.9941220000, 'Epicurian', '-', '0', '-', '-', 'US', 12);
INSERT INTO `venue` VALUES(300, 40.7339220000, -73.9987160000, '9th St Farmers Market', '64 W 9th St', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(301, 40.7315600000, -73.9963490000, 'Eva''s Vitamin Shoppe', '11 W. 8th St.', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(302, 40.7281530000, -73.9912890000, 'hy-vee', '36 Cooper Square', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(303, 40.7307340000, -73.9863120000, 'Open Pantry Food Mart', '184 2nd Ave', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(304, 40.7291830000, -73.9870980000, 'Village Farm & Grocery', '146 2nd Ave.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(305, 40.7299580000, -73.9869550000, 'St. Mark''s Church Greenmarket', 'E. 10th St. & Second Ave.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(306, 40.7260860000, -73.9862000000, 'Dual Specialty', '91 1st Ave.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(307, 40.7277210000, -73.9882970000, 'Metropolitan Citymarket', '107 2nd Ave.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(308, 40.7262540000, -73.9894470000, 'East Village Farm & Grocery', '69 2nd Ave', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(309, 40.7259330000, -73.9887400000, 'Healthfully Organic Food Market', '98 E 4th St.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(310, 40.7275000000, -73.9863800000, 'The Met', '-', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(311, 40.7269430000, -73.9886700000, '2nd Avenue Grocery', '89 2nd Ave.', '10003-8334', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(312, 40.7290400000, -73.9844280000, 'Commodities Natural Market', '165 1st Ave', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(313, 40.7262160000, -73.9833330000, 'Tompkins Square Greenmarket', 'Avenue A', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(314, 40.7246320000, -73.9785980000, 'Associated Supermarket', '123 Avenue C', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(315, 40.7249700000, -73.9813720000, 'Anwar Grocery', '106 Ave. B', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(316, 40.7224970000, -73.9770710000, 'Compare Foods', 'Avenue D', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(317, 40.7267990000, -73.9766980000, 'C-Town Supermarkets', '188 AVENUE C', '10009', 'NEW YORK', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(318, 40.7265380000, -73.9773760000, 'new york healthy choice', '177 Avenue C', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(319, 40.7349340000, -73.9861820000, 'Met Food', '180 3rd Ave', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(320, 40.7358260000, -73.9930550000, 'Garden of Eden', '7 E 14th St.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(321, 40.7373540000, -73.9912780000, 'Westside supermarket', '-', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(322, 40.7329750000, -73.9936570000, 'Agata & Valentina', '64 University Pl.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(323, 40.7329700000, -73.9930380000, 'Agata & Valentina Market', '64 University Street', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(324, 40.7350580000, -73.9985160000, 'Jefferson Market Catering', '450 Avenue of The Americas', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(325, 40.7408050000, -73.9860630000, '24th Street Fruit Stand', 'Park Ave. S.', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(326, 40.7401950000, -73.9864720000, 'The Vitamin Shoppe', '100 E 23rd St (on Park South)', '10010', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(327, 40.7415700000, -73.9782310000, 'Gristedes Supermarkets #421', '512 2nd Ave', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(328, 40.7442610000, -73.9834940000, 'Health 4-U Natures Market', '432 Park Ave. S', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(329, 40.7443450000, -73.9991720000, 'Gristedes Supermarkets #597', '221 8th Ave.', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(330, 40.7446980000, -73.9991150000, 'Foragers City Grocer', '300 W 22nd St.', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(331, 40.7451420000, -73.9985810000, 'The Vitamin Shoppe', '257 8th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(332, 40.7469680000, -74.0011690000, 'Gristedes Supermarkets #545', '225 9th Ave', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(333, 40.7468020000, -74.0020610000, 'Health Food & Vitamin City', '-', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(334, 40.7472300000, -74.0005500000, 'Chelsea Terrace Supermarketl', '-', '10011', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(335, 40.7572940000, -73.9932210000, 'International Grocery', '529 Ninth Avenue', '10018', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(336, 40.7581590000, -73.9921190000, 'Merci Market', '350 W 42nd St.', '10036', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(337, 40.7567500000, -73.9937780000, 'Big Apple Meat Market', '529 9th Ave', '10036', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(338, 40.7573300000, -73.9908450000, 'Port Authority Green Market', 'Port Authority Bus Terminal', '10036', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(339, 40.7558070000, -73.9906020000, 'Dean & Deluca', '620 8th Ave.', '10018', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(340, 40.7558900000, -73.9905800000, 'Stop Shop - Port Authority', '8th ave and 40th st', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(341, 40.7532730000, -73.9839880000, 'C Town Markets', 'Broadway', '0', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(342, 40.7520090000, -73.9811520000, 'Marche Madison', '9 E 40th St.', '10016', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(343, 40.7486880000, -73.9731400000, 'Gristedes Supermarkets', '748 2nd Ave.', '10017', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(344, 40.7319170000, -73.9945490000, 'Gristedes Supermarkets', '25 University Pl', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(345, 40.7282800000, -73.9957220000, 'Gristedes Supermarkets', '246 Mercer St', '10012', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(346, 40.7267680000, -73.9906960000, '4th Street Food Co-op', '58 E 4th St', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(347, 40.7290070000, -73.9886390000, 'St. Mark''s Market', '21 Saint Marks Pl', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(348, 40.7288170000, -73.9881950000, 'JAS Mart', '35 St. Marks Pl.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(349, 40.7290630000, -73.9886260000, 'Indomart, Muncul.', 'Jl. Raya puspiptek, Tangerang.', '10003', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(350, 40.7241070000, -73.9848540000, 'Key Food', '52 Avenue A', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(351, 40.7235180000, -73.9834140000, 'Supermercado Tiele', '-', '10009', 'New York', 'NY', 'US', 12);
INSERT INTO `venue` VALUES(352, 40.6385710000, -74.1369420000, 'C-Town Supermarkets', '107-09 Port Richmond Ave', '10302', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(353, 40.6305320000, -74.0890720000, 'ShopRite', '32 Forest Ave', '0', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(354, 40.6231220000, -74.1488100000, 'ShopRite', '985 Richmond Ave.', '10314', 'New York', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(355, 40.5866500000, -74.1045160000, 'Hillside Market', '1789 Richmond Road', '10306', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(356, 40.5639970000, -74.1336390000, 'Pathmark- Amboy Rd', 'Amboy', '10306', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(357, 40.5764630000, -74.1658990000, 'Super Stop & Shop', '2795 Richmond Ave', '10314-5857', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(358, 40.5740820000, -74.1676070000, 'Pathmark', '2875 Richmond Ave', '10314', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(359, 40.5480220000, -74.1426540000, 'Shop & Save Superette', 'Hylan blvd', '0', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(360, 40.5514320000, -74.2123980000, 'Mignosi''s Supermarket', '1006 Rossville Ave.', '10309', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(361, 40.5164770000, -74.2436760000, 'La Bella Marketplace', '99 Ellis St, Staten Island, NY 10307', '10307', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(362, 40.5218220000, -74.2156430000, 'Waldbaum''s', '6400 Amboy Rd.', '10309', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(363, 40.5459040000, -74.1606810000, 'Stop & Shop', '4343 Amboy Rd', '10312', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(364, 40.6315470000, -74.1234430000, 'grocery store :)', '-', '0', '-', '-', 'US', 11);
INSERT INTO `venue` VALUES(365, 40.5447060000, -74.1655380000, 'De Monte''s - Eltingville', 'Richmond Avenue', '0', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(366, 40.5426010000, -74.2077900000, 'Christopher''s Food Mart', '645 Rossville Ave.', '10309', 'Staten Island', 'NY', 'US', 11);
INSERT INTO `venue` VALUES(367, 40.6421190000, -74.0779590000, 'St George Farmers Market', '-', '10301', 'Staten Island', 'NY', 'US', 11);

-- --------------------------------------------------------

--
-- Table structure for table `venue_meta_common`
--

CREATE TABLE `venue_meta_common` (
  `id` int(12) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `venue_meta_common`
--

INSERT INTO `venue_meta_common` VALUES(1, NULL);
INSERT INTO `venue_meta_common` VALUES(2, NULL);
INSERT INTO `venue_meta_common` VALUES(3, NULL);
INSERT INTO `venue_meta_common` VALUES(4, NULL);
INSERT INTO `venue_meta_common` VALUES(5, NULL);
INSERT INTO `venue_meta_common` VALUES(6, NULL);
INSERT INTO `venue_meta_common` VALUES(7, NULL);
INSERT INTO `venue_meta_common` VALUES(8, NULL);
INSERT INTO `venue_meta_common` VALUES(9, NULL);
INSERT INTO `venue_meta_common` VALUES(10, NULL);
INSERT INTO `venue_meta_common` VALUES(11, NULL);
INSERT INTO `venue_meta_common` VALUES(12, NULL);
INSERT INTO `venue_meta_common` VALUES(13, NULL);
INSERT INTO `venue_meta_common` VALUES(14, NULL);
INSERT INTO `venue_meta_common` VALUES(15, NULL);
INSERT INTO `venue_meta_common` VALUES(16, NULL);
INSERT INTO `venue_meta_common` VALUES(17, NULL);
INSERT INTO `venue_meta_common` VALUES(18, NULL);
INSERT INTO `venue_meta_common` VALUES(19, NULL);
INSERT INTO `venue_meta_common` VALUES(20, NULL);
INSERT INTO `venue_meta_common` VALUES(21, NULL);
INSERT INTO `venue_meta_common` VALUES(22, NULL);
INSERT INTO `venue_meta_common` VALUES(23, NULL);
INSERT INTO `venue_meta_common` VALUES(24, NULL);
INSERT INTO `venue_meta_common` VALUES(25, NULL);
INSERT INTO `venue_meta_common` VALUES(26, NULL);
INSERT INTO `venue_meta_common` VALUES(27, NULL);
INSERT INTO `venue_meta_common` VALUES(28, NULL);
INSERT INTO `venue_meta_common` VALUES(29, NULL);
INSERT INTO `venue_meta_common` VALUES(30, NULL);
INSERT INTO `venue_meta_common` VALUES(31, NULL);
INSERT INTO `venue_meta_common` VALUES(32, NULL);
INSERT INTO `venue_meta_common` VALUES(33, NULL);
INSERT INTO `venue_meta_common` VALUES(34, NULL);
INSERT INTO `venue_meta_common` VALUES(35, NULL);
INSERT INTO `venue_meta_common` VALUES(36, NULL);
INSERT INTO `venue_meta_common` VALUES(37, NULL);
INSERT INTO `venue_meta_common` VALUES(38, NULL);
INSERT INTO `venue_meta_common` VALUES(39, NULL);
INSERT INTO `venue_meta_common` VALUES(40, NULL);
INSERT INTO `venue_meta_common` VALUES(41, NULL);
INSERT INTO `venue_meta_common` VALUES(42, NULL);
INSERT INTO `venue_meta_common` VALUES(43, NULL);
INSERT INTO `venue_meta_common` VALUES(44, NULL);
INSERT INTO `venue_meta_common` VALUES(45, NULL);
INSERT INTO `venue_meta_common` VALUES(46, NULL);
INSERT INTO `venue_meta_common` VALUES(47, NULL);
INSERT INTO `venue_meta_common` VALUES(48, NULL);
INSERT INTO `venue_meta_common` VALUES(49, NULL);
INSERT INTO `venue_meta_common` VALUES(50, NULL);
INSERT INTO `venue_meta_common` VALUES(51, NULL);
INSERT INTO `venue_meta_common` VALUES(52, NULL);
INSERT INTO `venue_meta_common` VALUES(53, NULL);
INSERT INTO `venue_meta_common` VALUES(54, NULL);
INSERT INTO `venue_meta_common` VALUES(55, NULL);
INSERT INTO `venue_meta_common` VALUES(56, NULL);
INSERT INTO `venue_meta_common` VALUES(57, NULL);
INSERT INTO `venue_meta_common` VALUES(58, NULL);
INSERT INTO `venue_meta_common` VALUES(59, NULL);
INSERT INTO `venue_meta_common` VALUES(60, NULL);
INSERT INTO `venue_meta_common` VALUES(61, NULL);
INSERT INTO `venue_meta_common` VALUES(62, NULL);
INSERT INTO `venue_meta_common` VALUES(63, NULL);
INSERT INTO `venue_meta_common` VALUES(64, NULL);
INSERT INTO `venue_meta_common` VALUES(65, NULL);
INSERT INTO `venue_meta_common` VALUES(66, NULL);
INSERT INTO `venue_meta_common` VALUES(67, NULL);
INSERT INTO `venue_meta_common` VALUES(68, NULL);
INSERT INTO `venue_meta_common` VALUES(69, NULL);
INSERT INTO `venue_meta_common` VALUES(70, NULL);
INSERT INTO `venue_meta_common` VALUES(71, NULL);
INSERT INTO `venue_meta_common` VALUES(72, NULL);
INSERT INTO `venue_meta_common` VALUES(73, NULL);
INSERT INTO `venue_meta_common` VALUES(74, NULL);
INSERT INTO `venue_meta_common` VALUES(75, NULL);
INSERT INTO `venue_meta_common` VALUES(76, NULL);
INSERT INTO `venue_meta_common` VALUES(77, NULL);
INSERT INTO `venue_meta_common` VALUES(78, NULL);
INSERT INTO `venue_meta_common` VALUES(79, NULL);
INSERT INTO `venue_meta_common` VALUES(80, NULL);
INSERT INTO `venue_meta_common` VALUES(81, NULL);
INSERT INTO `venue_meta_common` VALUES(82, NULL);
INSERT INTO `venue_meta_common` VALUES(83, NULL);
INSERT INTO `venue_meta_common` VALUES(84, NULL);
INSERT INTO `venue_meta_common` VALUES(85, NULL);
INSERT INTO `venue_meta_common` VALUES(86, NULL);
INSERT INTO `venue_meta_common` VALUES(87, NULL);
INSERT INTO `venue_meta_common` VALUES(88, NULL);
INSERT INTO `venue_meta_common` VALUES(89, NULL);
INSERT INTO `venue_meta_common` VALUES(90, NULL);
INSERT INTO `venue_meta_common` VALUES(91, NULL);
INSERT INTO `venue_meta_common` VALUES(92, NULL);
INSERT INTO `venue_meta_common` VALUES(93, NULL);
INSERT INTO `venue_meta_common` VALUES(94, NULL);
INSERT INTO `venue_meta_common` VALUES(95, NULL);
INSERT INTO `venue_meta_common` VALUES(96, NULL);
INSERT INTO `venue_meta_common` VALUES(97, NULL);
INSERT INTO `venue_meta_common` VALUES(98, NULL);
INSERT INTO `venue_meta_common` VALUES(99, NULL);
INSERT INTO `venue_meta_common` VALUES(100, NULL);
INSERT INTO `venue_meta_common` VALUES(101, NULL);
INSERT INTO `venue_meta_common` VALUES(102, NULL);
INSERT INTO `venue_meta_common` VALUES(103, NULL);
INSERT INTO `venue_meta_common` VALUES(104, NULL);
INSERT INTO `venue_meta_common` VALUES(105, NULL);
INSERT INTO `venue_meta_common` VALUES(106, NULL);
INSERT INTO `venue_meta_common` VALUES(107, NULL);
INSERT INTO `venue_meta_common` VALUES(108, NULL);
INSERT INTO `venue_meta_common` VALUES(109, NULL);
INSERT INTO `venue_meta_common` VALUES(110, NULL);
INSERT INTO `venue_meta_common` VALUES(111, NULL);
INSERT INTO `venue_meta_common` VALUES(112, NULL);
INSERT INTO `venue_meta_common` VALUES(113, NULL);
INSERT INTO `venue_meta_common` VALUES(114, NULL);
INSERT INTO `venue_meta_common` VALUES(115, NULL);
INSERT INTO `venue_meta_common` VALUES(116, NULL);
INSERT INTO `venue_meta_common` VALUES(117, NULL);
INSERT INTO `venue_meta_common` VALUES(118, NULL);
INSERT INTO `venue_meta_common` VALUES(119, NULL);
INSERT INTO `venue_meta_common` VALUES(120, NULL);
INSERT INTO `venue_meta_common` VALUES(121, NULL);
INSERT INTO `venue_meta_common` VALUES(122, NULL);
INSERT INTO `venue_meta_common` VALUES(123, NULL);
INSERT INTO `venue_meta_common` VALUES(124, NULL);
INSERT INTO `venue_meta_common` VALUES(125, NULL);
INSERT INTO `venue_meta_common` VALUES(126, NULL);
INSERT INTO `venue_meta_common` VALUES(127, NULL);
INSERT INTO `venue_meta_common` VALUES(128, NULL);
INSERT INTO `venue_meta_common` VALUES(129, NULL);
INSERT INTO `venue_meta_common` VALUES(130, NULL);
INSERT INTO `venue_meta_common` VALUES(131, NULL);
INSERT INTO `venue_meta_common` VALUES(132, NULL);
INSERT INTO `venue_meta_common` VALUES(133, NULL);
INSERT INTO `venue_meta_common` VALUES(134, NULL);
INSERT INTO `venue_meta_common` VALUES(135, NULL);
INSERT INTO `venue_meta_common` VALUES(136, NULL);
INSERT INTO `venue_meta_common` VALUES(137, NULL);
INSERT INTO `venue_meta_common` VALUES(138, NULL);
INSERT INTO `venue_meta_common` VALUES(139, NULL);
INSERT INTO `venue_meta_common` VALUES(140, NULL);
INSERT INTO `venue_meta_common` VALUES(141, NULL);
INSERT INTO `venue_meta_common` VALUES(142, NULL);
INSERT INTO `venue_meta_common` VALUES(143, NULL);
INSERT INTO `venue_meta_common` VALUES(144, NULL);
INSERT INTO `venue_meta_common` VALUES(145, NULL);
INSERT INTO `venue_meta_common` VALUES(146, NULL);
INSERT INTO `venue_meta_common` VALUES(147, NULL);
INSERT INTO `venue_meta_common` VALUES(148, NULL);
INSERT INTO `venue_meta_common` VALUES(149, NULL);
INSERT INTO `venue_meta_common` VALUES(150, NULL);
INSERT INTO `venue_meta_common` VALUES(151, NULL);
INSERT INTO `venue_meta_common` VALUES(152, NULL);
INSERT INTO `venue_meta_common` VALUES(153, NULL);
INSERT INTO `venue_meta_common` VALUES(154, NULL);
INSERT INTO `venue_meta_common` VALUES(155, NULL);
INSERT INTO `venue_meta_common` VALUES(156, NULL);
INSERT INTO `venue_meta_common` VALUES(157, NULL);
INSERT INTO `venue_meta_common` VALUES(158, NULL);
INSERT INTO `venue_meta_common` VALUES(159, NULL);
INSERT INTO `venue_meta_common` VALUES(160, NULL);
INSERT INTO `venue_meta_common` VALUES(161, NULL);
INSERT INTO `venue_meta_common` VALUES(162, NULL);
INSERT INTO `venue_meta_common` VALUES(163, NULL);
INSERT INTO `venue_meta_common` VALUES(164, NULL);
INSERT INTO `venue_meta_common` VALUES(165, NULL);
INSERT INTO `venue_meta_common` VALUES(166, NULL);
INSERT INTO `venue_meta_common` VALUES(167, NULL);
INSERT INTO `venue_meta_common` VALUES(168, NULL);
INSERT INTO `venue_meta_common` VALUES(169, NULL);
INSERT INTO `venue_meta_common` VALUES(170, NULL);
INSERT INTO `venue_meta_common` VALUES(171, NULL);
INSERT INTO `venue_meta_common` VALUES(172, NULL);
INSERT INTO `venue_meta_common` VALUES(173, NULL);
INSERT INTO `venue_meta_common` VALUES(174, NULL);
INSERT INTO `venue_meta_common` VALUES(175, NULL);
INSERT INTO `venue_meta_common` VALUES(176, NULL);
INSERT INTO `venue_meta_common` VALUES(177, NULL);
INSERT INTO `venue_meta_common` VALUES(178, NULL);
INSERT INTO `venue_meta_common` VALUES(179, NULL);
INSERT INTO `venue_meta_common` VALUES(180, NULL);
INSERT INTO `venue_meta_common` VALUES(181, NULL);
INSERT INTO `venue_meta_common` VALUES(182, NULL);
INSERT INTO `venue_meta_common` VALUES(183, NULL);
INSERT INTO `venue_meta_common` VALUES(184, NULL);
INSERT INTO `venue_meta_common` VALUES(185, NULL);
INSERT INTO `venue_meta_common` VALUES(186, NULL);
INSERT INTO `venue_meta_common` VALUES(187, NULL);
INSERT INTO `venue_meta_common` VALUES(188, NULL);
INSERT INTO `venue_meta_common` VALUES(189, NULL);
INSERT INTO `venue_meta_common` VALUES(190, NULL);
INSERT INTO `venue_meta_common` VALUES(191, NULL);
INSERT INTO `venue_meta_common` VALUES(192, NULL);
INSERT INTO `venue_meta_common` VALUES(193, NULL);
INSERT INTO `venue_meta_common` VALUES(194, NULL);
INSERT INTO `venue_meta_common` VALUES(195, NULL);
INSERT INTO `venue_meta_common` VALUES(196, NULL);
INSERT INTO `venue_meta_common` VALUES(197, NULL);
INSERT INTO `venue_meta_common` VALUES(198, NULL);
INSERT INTO `venue_meta_common` VALUES(199, NULL);
INSERT INTO `venue_meta_common` VALUES(200, NULL);
INSERT INTO `venue_meta_common` VALUES(201, NULL);
INSERT INTO `venue_meta_common` VALUES(202, NULL);
INSERT INTO `venue_meta_common` VALUES(203, NULL);
INSERT INTO `venue_meta_common` VALUES(204, NULL);
INSERT INTO `venue_meta_common` VALUES(205, NULL);
INSERT INTO `venue_meta_common` VALUES(206, NULL);
INSERT INTO `venue_meta_common` VALUES(207, NULL);
INSERT INTO `venue_meta_common` VALUES(208, NULL);
INSERT INTO `venue_meta_common` VALUES(209, NULL);
INSERT INTO `venue_meta_common` VALUES(210, NULL);
INSERT INTO `venue_meta_common` VALUES(211, NULL);
INSERT INTO `venue_meta_common` VALUES(212, NULL);
INSERT INTO `venue_meta_common` VALUES(213, NULL);
INSERT INTO `venue_meta_common` VALUES(214, NULL);
INSERT INTO `venue_meta_common` VALUES(215, NULL);
INSERT INTO `venue_meta_common` VALUES(216, NULL);
INSERT INTO `venue_meta_common` VALUES(217, NULL);
INSERT INTO `venue_meta_common` VALUES(218, NULL);
INSERT INTO `venue_meta_common` VALUES(219, NULL);
INSERT INTO `venue_meta_common` VALUES(220, NULL);
INSERT INTO `venue_meta_common` VALUES(221, NULL);
INSERT INTO `venue_meta_common` VALUES(222, NULL);
INSERT INTO `venue_meta_common` VALUES(223, NULL);
INSERT INTO `venue_meta_common` VALUES(224, NULL);
INSERT INTO `venue_meta_common` VALUES(225, NULL);
INSERT INTO `venue_meta_common` VALUES(226, NULL);
INSERT INTO `venue_meta_common` VALUES(227, NULL);
INSERT INTO `venue_meta_common` VALUES(228, NULL);
INSERT INTO `venue_meta_common` VALUES(229, NULL);
INSERT INTO `venue_meta_common` VALUES(230, NULL);
INSERT INTO `venue_meta_common` VALUES(231, NULL);
INSERT INTO `venue_meta_common` VALUES(232, NULL);
INSERT INTO `venue_meta_common` VALUES(233, NULL);
INSERT INTO `venue_meta_common` VALUES(234, NULL);
INSERT INTO `venue_meta_common` VALUES(235, NULL);
INSERT INTO `venue_meta_common` VALUES(236, NULL);
INSERT INTO `venue_meta_common` VALUES(237, NULL);
INSERT INTO `venue_meta_common` VALUES(238, NULL);
INSERT INTO `venue_meta_common` VALUES(239, NULL);
INSERT INTO `venue_meta_common` VALUES(240, NULL);
INSERT INTO `venue_meta_common` VALUES(241, NULL);
INSERT INTO `venue_meta_common` VALUES(242, NULL);
INSERT INTO `venue_meta_common` VALUES(243, NULL);
INSERT INTO `venue_meta_common` VALUES(244, NULL);
INSERT INTO `venue_meta_common` VALUES(245, NULL);
INSERT INTO `venue_meta_common` VALUES(246, NULL);
INSERT INTO `venue_meta_common` VALUES(247, NULL);
INSERT INTO `venue_meta_common` VALUES(248, NULL);
INSERT INTO `venue_meta_common` VALUES(249, NULL);
INSERT INTO `venue_meta_common` VALUES(250, NULL);
INSERT INTO `venue_meta_common` VALUES(251, NULL);
INSERT INTO `venue_meta_common` VALUES(252, NULL);
INSERT INTO `venue_meta_common` VALUES(253, NULL);
INSERT INTO `venue_meta_common` VALUES(254, NULL);
INSERT INTO `venue_meta_common` VALUES(255, NULL);
INSERT INTO `venue_meta_common` VALUES(256, NULL);
INSERT INTO `venue_meta_common` VALUES(257, NULL);
INSERT INTO `venue_meta_common` VALUES(258, NULL);
INSERT INTO `venue_meta_common` VALUES(259, NULL);
INSERT INTO `venue_meta_common` VALUES(260, NULL);
INSERT INTO `venue_meta_common` VALUES(261, NULL);
INSERT INTO `venue_meta_common` VALUES(262, NULL);
INSERT INTO `venue_meta_common` VALUES(263, NULL);
INSERT INTO `venue_meta_common` VALUES(264, NULL);
INSERT INTO `venue_meta_common` VALUES(265, NULL);
INSERT INTO `venue_meta_common` VALUES(266, NULL);
INSERT INTO `venue_meta_common` VALUES(267, NULL);
INSERT INTO `venue_meta_common` VALUES(268, NULL);
INSERT INTO `venue_meta_common` VALUES(269, NULL);
INSERT INTO `venue_meta_common` VALUES(270, NULL);
INSERT INTO `venue_meta_common` VALUES(271, NULL);
INSERT INTO `venue_meta_common` VALUES(272, NULL);
INSERT INTO `venue_meta_common` VALUES(273, NULL);
INSERT INTO `venue_meta_common` VALUES(274, NULL);
INSERT INTO `venue_meta_common` VALUES(275, NULL);
INSERT INTO `venue_meta_common` VALUES(276, NULL);
INSERT INTO `venue_meta_common` VALUES(277, NULL);
INSERT INTO `venue_meta_common` VALUES(278, NULL);
INSERT INTO `venue_meta_common` VALUES(279, NULL);
INSERT INTO `venue_meta_common` VALUES(280, NULL);
INSERT INTO `venue_meta_common` VALUES(281, NULL);
INSERT INTO `venue_meta_common` VALUES(282, NULL);
INSERT INTO `venue_meta_common` VALUES(283, NULL);
INSERT INTO `venue_meta_common` VALUES(284, NULL);
INSERT INTO `venue_meta_common` VALUES(285, NULL);
INSERT INTO `venue_meta_common` VALUES(286, NULL);
INSERT INTO `venue_meta_common` VALUES(287, NULL);
INSERT INTO `venue_meta_common` VALUES(288, NULL);
INSERT INTO `venue_meta_common` VALUES(289, NULL);
INSERT INTO `venue_meta_common` VALUES(290, NULL);
INSERT INTO `venue_meta_common` VALUES(291, NULL);
INSERT INTO `venue_meta_common` VALUES(292, NULL);
INSERT INTO `venue_meta_common` VALUES(293, NULL);
INSERT INTO `venue_meta_common` VALUES(294, NULL);
INSERT INTO `venue_meta_common` VALUES(295, NULL);
INSERT INTO `venue_meta_common` VALUES(296, NULL);
INSERT INTO `venue_meta_common` VALUES(297, NULL);
INSERT INTO `venue_meta_common` VALUES(298, NULL);
INSERT INTO `venue_meta_common` VALUES(299, NULL);
INSERT INTO `venue_meta_common` VALUES(300, NULL);
INSERT INTO `venue_meta_common` VALUES(301, NULL);
INSERT INTO `venue_meta_common` VALUES(302, NULL);
INSERT INTO `venue_meta_common` VALUES(303, NULL);
INSERT INTO `venue_meta_common` VALUES(304, NULL);
INSERT INTO `venue_meta_common` VALUES(305, NULL);
INSERT INTO `venue_meta_common` VALUES(306, NULL);
INSERT INTO `venue_meta_common` VALUES(307, NULL);
INSERT INTO `venue_meta_common` VALUES(308, NULL);
INSERT INTO `venue_meta_common` VALUES(309, NULL);
INSERT INTO `venue_meta_common` VALUES(310, NULL);
INSERT INTO `venue_meta_common` VALUES(311, NULL);
INSERT INTO `venue_meta_common` VALUES(312, NULL);
INSERT INTO `venue_meta_common` VALUES(313, NULL);
INSERT INTO `venue_meta_common` VALUES(314, NULL);
INSERT INTO `venue_meta_common` VALUES(315, NULL);
INSERT INTO `venue_meta_common` VALUES(316, NULL);
INSERT INTO `venue_meta_common` VALUES(317, NULL);
INSERT INTO `venue_meta_common` VALUES(318, NULL);
INSERT INTO `venue_meta_common` VALUES(319, NULL);
INSERT INTO `venue_meta_common` VALUES(320, NULL);
INSERT INTO `venue_meta_common` VALUES(321, NULL);
INSERT INTO `venue_meta_common` VALUES(322, NULL);
INSERT INTO `venue_meta_common` VALUES(323, NULL);
INSERT INTO `venue_meta_common` VALUES(324, NULL);
INSERT INTO `venue_meta_common` VALUES(325, NULL);
INSERT INTO `venue_meta_common` VALUES(326, NULL);
INSERT INTO `venue_meta_common` VALUES(327, NULL);
INSERT INTO `venue_meta_common` VALUES(328, NULL);
INSERT INTO `venue_meta_common` VALUES(329, NULL);
INSERT INTO `venue_meta_common` VALUES(330, NULL);
INSERT INTO `venue_meta_common` VALUES(331, NULL);
INSERT INTO `venue_meta_common` VALUES(332, NULL);
INSERT INTO `venue_meta_common` VALUES(333, NULL);
INSERT INTO `venue_meta_common` VALUES(334, NULL);
INSERT INTO `venue_meta_common` VALUES(335, NULL);
INSERT INTO `venue_meta_common` VALUES(336, NULL);
INSERT INTO `venue_meta_common` VALUES(337, NULL);
INSERT INTO `venue_meta_common` VALUES(338, NULL);
INSERT INTO `venue_meta_common` VALUES(339, NULL);
INSERT INTO `venue_meta_common` VALUES(340, NULL);
INSERT INTO `venue_meta_common` VALUES(341, NULL);
INSERT INTO `venue_meta_common` VALUES(342, NULL);
INSERT INTO `venue_meta_common` VALUES(343, NULL);
INSERT INTO `venue_meta_common` VALUES(344, NULL);
INSERT INTO `venue_meta_common` VALUES(345, NULL);
INSERT INTO `venue_meta_common` VALUES(346, NULL);
INSERT INTO `venue_meta_common` VALUES(347, NULL);
INSERT INTO `venue_meta_common` VALUES(348, NULL);
INSERT INTO `venue_meta_common` VALUES(349, NULL);
INSERT INTO `venue_meta_common` VALUES(350, NULL);
INSERT INTO `venue_meta_common` VALUES(351, NULL);
INSERT INTO `venue_meta_common` VALUES(352, NULL);
INSERT INTO `venue_meta_common` VALUES(353, NULL);
INSERT INTO `venue_meta_common` VALUES(354, NULL);
INSERT INTO `venue_meta_common` VALUES(355, NULL);
INSERT INTO `venue_meta_common` VALUES(356, NULL);
INSERT INTO `venue_meta_common` VALUES(357, NULL);
INSERT INTO `venue_meta_common` VALUES(358, NULL);
INSERT INTO `venue_meta_common` VALUES(359, NULL);
INSERT INTO `venue_meta_common` VALUES(360, NULL);
INSERT INTO `venue_meta_common` VALUES(361, NULL);
INSERT INTO `venue_meta_common` VALUES(362, NULL);
INSERT INTO `venue_meta_common` VALUES(363, NULL);
INSERT INTO `venue_meta_common` VALUES(364, NULL);
INSERT INTO `venue_meta_common` VALUES(365, NULL);
INSERT INTO `venue_meta_common` VALUES(366, NULL);
INSERT INTO `venue_meta_common` VALUES(367, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `venue_meta_foursquare`
--

CREATE TABLE `venue_meta_foursquare` (
  `id` int(12) NOT NULL,
  `venue_foursquare_id` varchar(32) NOT NULL,
  `canonicalUrl` varchar(500) DEFAULT NULL,
  `price_tier` int(1) DEFAULT NULL,
  `price_message` varchar(255) DEFAULT NULL,
  `menu_url` varchar(255) DEFAULT NULL,
  `menu_type` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `venue_foursquare_id` (`venue_foursquare_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `venue_meta_foursquare`
--

INSERT INTO `venue_meta_foursquare` VALUES(1, '4b27c75af964a520c78924e3', 'https://foursquare.com/v/apple-tree-supermarket/4b27c75af964a520c78924e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(2, '4f2ffa5ce4b007725d09b674', 'https://foursquare.com/v/nyc-fresh-market/4f2ffa5ce4b007725d09b674', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(3, '4be49fafcf200f47283e123c', 'https://foursquare.com/v/fine-fare/4be49fafcf200f47283e123c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(4, '5069f91be4b033d3594050ea', 'https://foursquare.com/v/central-park-gourmet-grocery/5069f91be4b033d3594050ea', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(5, '4d265440888af04d4255b2af', 'https://foursquare.com/v/sd-grocery/4d265440888af04d4255b2af', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(6, '4e24918b3151306f892983f7', 'https://foursquare.com/v/met-supermarket/4e24918b3151306f892983f7', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(7, '4bf1cc193fa220a1ceb91820', 'https://foursquare.com/v/food-choice/4bf1cc193fa220a1ceb91820', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(8, '4ecd87c202d5feaa190a10c6', 'https://foursquare.com/v/farm-country/4ecd87c202d5feaa190a10c6', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(9, '4c6433a32a58c9b658823461', 'https://foursquare.com/v/little-mexico-meat-grocery-inc/4c6433a32a58c9b658823461', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(10, '4cb3127bdb32f04d896ad44d', 'https://foursquare.com/v/pioneer-supermarket/4cb3127bdb32f04d896ad44d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(11, '4d61ab96338bb60cd4f636bd', 'https://foursquare.com/v/mauricios-marketplace/4d61ab96338bb60cd4f636bd', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(12, '4a907b5ff964a520231820e3', 'https://foursquare.com/v/gristedes-supermarkets-098/4a907b5ff964a520231820e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(13, '4c6ed39bd97fa143491cf1ca', 'https://foursquare.com/v/farmers-market/4c6ed39bd97fa143491cf1ca', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(14, '4a8716a3f964a520820220e3', 'https://foursquare.com/v/gourmet-garage/4a8716a3f964a520820220e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(15, '50ad3959e4b0e250d631c57a', 'https://foursquare.com/v/farmers-market/50ad3959e4b0e250d631c57a', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(16, '4c99328f9f259eb065f64885', 'https://foursquare.com/v/mt-sinai-hospital-greenmarket/4c99328f9f259eb065f64885', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(17, '4bfea42e34ced13ab9f237b3', 'https://foursquare.com/v/madison-deli--grocery/4bfea42e34ced13ab9f237b3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(18, '4fd637ebe4b098b0837c1de6', 'https://foursquare.com/v/mount-sinai-csa/4fd637ebe4b098b0837c1de6', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(19, '4b00a9cdf964a5205d4022e3', 'https://foursquare.com/v/associated-supermarket/4b00a9cdf964a5205d4022e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(20, '4da62e8af7b192b48667ccdb', 'https://foursquare.com/v/mexican-supermarket/4da62e8af7b192b48667ccdb', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(21, '4d1144396360a35da23b8988', 'https://foursquare.com/v/associated-supermarket/4d1144396360a35da23b8988', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(22, '4e0a000818a8382643c622e0', 'https://foursquare.com/v/foodtown/4e0a000818a8382643c622e0', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(23, '4d3444c5c6cba35d8fef317a', 'https://foursquare.com/v/associated-supermarket/4d3444c5c6cba35d8fef317a', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(24, '4d350feb72a8b1f7df56b6d0', 'https://foursquare.com/v/weird-corner-store/4d350feb72a8b1f7df56b6d0', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(25, '4d475cf7c3e5a35d70ac924f', 'https://foursquare.com/v/fine-fare-112thlenox/4d475cf7c3e5a35d70ac924f', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(26, '4fd11200e4b0e33b6e843793', 'https://foursquare.com/v/project-harmony-csa/4fd11200e4b0e33b6e843793', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(27, '4af61cc7f964a520520122e3', 'https://foursquare.com/v/shop-fair/4af61cc7f964a520520122e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(28, '4b3aa546f964a520d66b25e3', 'https://foursquare.com/v/organic-forever/4b3aa546f964a520d66b25e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(29, '4b6b2501f964a520a5f52be3', 'https://foursquare.com/v/best-yet-market/4b6b2501f964a520a5f52be3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(30, '4b4e9edaf964a520c8f226e3', 'https://foursquare.com/v/ctown-supermarkets/4b4e9edaf964a520c8f226e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(31, '51259fda183f1220e7ac6d72', 'https://foursquare.com/v/best-yet-market-in-harlem/51259fda183f1220e7ac6d72', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(32, '4bdf4e126198c9b68cb416ff', 'https://foursquare.com/v/met-foodmarkets/4bdf4e126198c9b68cb416ff', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(33, '4b771494f964a5204f7b2ee3', 'https://foursquare.com/v/citarella/4b771494f964a5204f7b2ee3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(34, '51083e4490e766ba9bfb41d5', 'https://foursquare.com/v/key-food/51083e4490e766ba9bfb41d5', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(35, '4b6ffdd8f964a52093022de3', 'https://foursquare.com/v/ctown-supermarkets/4b6ffdd8f964a52093022de3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(36, '4f4f759ee4b03cdd7a111222', 'https://foursquare.com/v/fresh-direct-delivery/4f4f759ee4b03cdd7a111222', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(37, '4c430e28520fa593fa08ccac', 'https://foursquare.com/v/thirfty-grocery/4c430e28520fa593fa08ccac', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(38, '4e5d41dbfa76a4cf1490de5c', 'https://foursquare.com/v/cold-room-at-fairway/4e5d41dbfa76a4cf1490de5c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(39, '4bd49ad97b1876b090658986', 'https://foursquare.com/v/ctown-supermarkets/4bd49ad97b1876b090658986', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(40, '50e356c0e4b0b93ef971a4a7', 'https://foursquare.com/v/hamilton-meat-market/50e356c0e4b0b93ef971a4a7', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(41, '4f0f7a96e4b0ad0889531a4d', 'https://foursquare.com/v/mi-pais-market/4f0f7a96e4b0ad0889531a4d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(42, '4b9830a5f964a520c73235e3', 'https://foursquare.com/v/ctown-supermarkets/4b9830a5f964a520c73235e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(43, '4c6d3338e6b7b1f717f8a88e', 'https://foursquare.com/v/ctown-supermarkets/4c6d3338e6b7b1f717f8a88e', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(44, '4c75d5aadb52b1f7a2117adc', 'https://foursquare.com/v/silver-saddle-grocery/4c75d5aadb52b1f7a2117adc', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(45, '4e416857d164f2d277c2922a', 'https://foursquare.com/v/fort-washington-greenmarket-farmers-market/4e416857d164f2d277c2922a', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(46, '4cb21600aef16dcb55a9be54', 'https://foursquare.com/v/bravo-supermarket/4cb21600aef16dcb55a9be54', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(47, '4b8689cdf964a520908e31e3', 'https://foursquare.com/v/la-rosa-fine-foods/4b8689cdf964a520908e31e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(48, '4c3f4141ff711b8d1ba10e05', 'https://foursquare.com/v/farmers-market/4c3f4141ff711b8d1ba10e05', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(49, '4e00db961495692a4bb72262', 'https://foursquare.com/v/washington-heights-grocery-discount/4e00db961495692a4bb72262', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(50, '4e6ce2acd1649db799ce10fb', 'https://foursquare.com/v/broadway-farm-meat-warehouse/4e6ce2acd1649db799ce10fb', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(51, '4efbafaf8b81729522005ff5', 'https://foursquare.com/v/finefare/4efbafaf8b81729522005ff5', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(52, '4ac10f70f964a520a49520e3', 'https://foursquare.com/v/fine-fare/4ac10f70f964a520a49520e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(53, '4aef945ff964a5205dd921e3', 'https://foursquare.com/v/la-antillana-supermercado/4aef945ff964a5205dd921e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(54, '4e26072f628436bf4d65245b', 'https://foursquare.com/v/new-way-supermarket/4e26072f628436bf4d65245b', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(55, '4f10dd7ce4b0960dfe2ddaf3', 'https://foursquare.com/v/la-esperanza-supermarket/4f10dd7ce4b0960dfe2ddaf3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(56, '4d6955bc1a88b1f771ed295d', 'https://foursquare.com/v/ctown-supermarkets/4d6955bc1a88b1f771ed295d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(57, '50308a69e4b01a4fc2156500', 'https://foursquare.com/v/plaza-grocery/50308a69e4b01a4fc2156500', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(58, '4ac10f33f964a520a19520e3', 'https://foursquare.com/v/gristedes-supermarkets-504/4ac10f33f964a520a19520e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(59, '4c8fd3725fdf6dcb599d2b91', 'https://foursquare.com/v/tuesday-fort-washington-farmers-market/4c8fd3725fdf6dcb599d2b91', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(60, '4e4a7017aeb7de71b3962a7f', 'https://foursquare.com/v/columbia-medical-school-farmers-market/4e4a7017aeb7de71b3962a7f', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(61, '4dfd53c4e4cdbe059c3c68fd', 'https://foursquare.com/v/j--f-meat-market/4dfd53c4e4cdbe059c3c68fd', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(62, '4e35adc1483bf3839a31863b', 'https://foursquare.com/v/compare-foods/4e35adc1483bf3839a31863b', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(63, '4c0fef627c49b713fdb63606', 'https://foursquare.com/v/fine-fare/4c0fef627c49b713fdb63606', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(64, '4b60dd87f964a52086fe29e3', 'https://foursquare.com/v/associated-supermarket/4b60dd87f964a52086fe29e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(65, '4bfb2a08565f76b0394305db', 'https://foursquare.com/v/key-food/4bfb2a08565f76b0394305db', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(66, '4b76b394f964a5204f592ee3', 'https://foursquare.com/v/pathmark/4b76b394f964a5204f592ee3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(67, '50780a75e4b07204c02ab355', 'https://foursquare.com/v/triana-deli--grocery/50780a75e4b07204c02ab355', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(68, '4c9932109f259eb0ccf54885', 'https://foursquare.com/v/harvest-home-go-green-market/4c9932109f259eb0ccf54885', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(69, '4bd8b43fe914a593f42254fa', 'https://foursquare.com/v/fine-fare/4bd8b43fe914a593f42254fa', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(70, '506a8e9fe889a4d6a388a7ba', 'https://foursquare.com/v/aldi/506a8e9fe889a4d6a388a7ba', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(71, '4afcad9ff964a520052522e3', 'https://foursquare.com/v/costco-wholesale-club/4afcad9ff964a520052522e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(72, '4bb632b92ea195218049ab2f', 'https://foursquare.com/v/compare-foods/4bb632b92ea195218049ab2f', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(73, '4f89bf16e4b0e6f348d4e794', 'https://foursquare.com/v/fruit-and-vegetable-truck/4f89bf16e4b0e6f348d4e794', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(74, '4c4347bee26920a1a23e61e7', 'https://foursquare.com/v/associated/4c4347bee26920a1a23e61e7', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(75, '4c5d9815857ca5938844cdcb', 'https://foursquare.com/v/la-marqueta/4c5d9815857ca5938844cdcb', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(76, '4bf81fae5ec320a1bf2b88d3', 'https://foursquare.com/v/wild-olive-market/4bf81fae5ec320a1bf2b88d3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(77, '4ae04c29f964a5208a7e21e3', 'https://foursquare.com/v/fine-fare-supermarket/4ae04c29f964a5208a7e21e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(78, '4ffc85561648c9b3aab42f3c', 'https://foursquare.com/v/harvest-home-mt-morris-park-market/4ffc85561648c9b3aab42f3c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(79, '4bd6d09d6f649521a75771ec', 'https://foursquare.com/v/associated-supermarket/4bd6d09d6f649521a75771ec', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(80, '4fb3db86e4b083029dab3510', 'https://foursquare.com/v/corner-fruit-stand/4fb3db86e4b083029dab3510', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(81, '4bcccbbefb84c9b66d0b213e', 'https://foursquare.com/v/associated-supermarket/4bcccbbefb84c9b66d0b213e', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(82, '5015a0afe4b00c78e4e96d68', 'https://foursquare.com/v/foodtown-supermarket/5015a0afe4b00c78e4e96d68', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(83, '4b43ecaef964a52021ee25e3', 'https://foursquare.com/v/pathmark/4b43ecaef964a52021ee25e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(84, '4c76ddea923ba143eb4865e6', 'https://foursquare.com/v/central-harlem-csa/4c76ddea923ba143eb4865e6', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(85, '4c606164cd522d7f81fdcd3f', 'https://foursquare.com/v/ctown-supermarkets/4c606164cd522d7f81fdcd3f', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(86, '4c6aae3a2c29d13a44580e41', 'https://foursquare.com/v/125th-st-farmers-market/4c6aae3a2c29d13a44580e41', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(87, '4c55cf3df5f3d13a2a8567fc', 'https://foursquare.com/v/watkins-health-foods/4c55cf3df5f3d13a2a8567fc', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(88, '4c3892d118e72d7fc68518f5', 'https://foursquare.com/v/mount-morris--marcus-garvey-park-farmers-market/4c3892d118e72d7fc68518f5', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(89, '4b16ee79f964a520a6bf23e3', 'https://foursquare.com/v/young-spring-farm/4b16ee79f964a520a6bf23e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(90, '4c34d4e46f1fef3b6ff1ec3d', 'https://foursquare.com/v/target/4c34d4e46f1fef3b6ff1ec3d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(91, '50192593e4b0a3660311df1d', 'https://foursquare.com/v/pioneer-supermarket/50192593e4b0a3660311df1d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(92, '4bf48800cad2c9282f179c99', 'https://foursquare.com/v/associated-market/4bf48800cad2c9282f179c99', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(93, '4c41d09eff711b8d03761205', 'https://foursquare.com/v/farmers-market/4c41d09eff711b8d03761205', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(94, '4e25a405a80967678ca689df', 'https://foursquare.com/v/grassroots-farmers-market/4e25a405a80967678ca689df', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(95, '4c0e8f2c98102d7f8cdce306', 'https://foursquare.com/v/fine-fare-supermarket/4c0e8f2c98102d7f8cdce306', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(96, '4ca8ea1d97c8a1cd3dca89a5', 'https://foursquare.com/v/fine-fare-supermarket/4ca8ea1d97c8a1cd3dca89a5', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(97, '4e8de97fb63445c4a55338bb', 'https://foursquare.com/v/street-fruit-market/4e8de97fb63445c4a55338bb', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(98, '4b131758f964a520fd9323e3', 'https://foursquare.com/v/key-food/4b131758f964a520fd9323e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(99, '4c2abd5fae6820a186dc1643', 'https://foursquare.com/v/uptown-super-market/4c2abd5fae6820a186dc1643', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(100, '4e4df13fb3ad1a69ac160244', 'https://foursquare.com/v/associated-supermarket/4e4df13fb3ad1a69ac160244', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(101, '4e4ff944e4cdc76dc9b8bd5d', 'https://foursquare.com/v/antillana-food-plaza/4e4ff944e4cdc76dc9b8bd5d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(102, '4b646d00f964a5202ab22ae3', 'https://foursquare.com/v/pathmark/4b646d00f964a5202ab22ae3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(103, '4bebe8226295c9b63f308808', 'https://foursquare.com/v/la-salle/4bebe8226295c9b63f308808', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(104, '4eb70cb9469073bbc6d892fd', 'https://foursquare.com/v/antillana/4eb70cb9469073bbc6d892fd', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(105, '4c828ea4dc018cfaf57cd06c', 'https://foursquare.com/v/fine-fare/4c828ea4dc018cfaf57cd06c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(106, '4e2b428c14955dbf7ad8f006', 'https://foursquare.com/v/deli-grocery--convenience-store--191-subway/4e2b428c14955dbf7ad8f006', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(107, '4ce827fe948f224b9caaee5d', 'https://foursquare.com/v/tu-pais-supermarket/4ce827fe948f224b9caaee5d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(108, '4e8212b1b8035e19f84710ab', 'https://foursquare.com/v/california-fruit-market/4e8212b1b8035e19f84710ab', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(109, '4c1464a9b7b9c9283f63ab37', 'https://foursquare.com/v/bridge-food/4c1464a9b7b9c9283f63ab37', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(110, '4c5aa6d56407d13a2a11b528', 'https://foursquare.com/v/rey-grocery/4c5aa6d56407d13a2a11b528', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(111, '4c1544e9127f952180ff2425', 'https://foursquare.com/v/cc-natural-nutrition/4c1544e9127f952180ff2425', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(112, '4c39f3786ec69c74471605a9', 'https://foursquare.com/v/associated-supermarket/4c39f3786ec69c74471605a9', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(113, '4a61fbe8f964a520c5c21fe3', 'https://foursquare.com/v/franks-market/4a61fbe8f964a520c5c21fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(114, '4b080702f964a520820223e3', 'https://foursquare.com/v/associated-market--187th/4b080702f964a520820223e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(115, '4b256ab7f964a5209e7124e3', 'https://foursquare.com/v/associated-supermarket/4b256ab7f964a5209e7124e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(116, '4ec919e461af9e1431a596c3', 'https://foursquare.com/v/farmers-market-93rd/4ec919e461af9e1431a596c3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(117, '4b6c88eef964a52070412ce3', 'https://foursquare.com/v/patrick-murphy-groceries/4b6c88eef964a52070412ce3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(118, '4e541d547d8b96cd060945aa', 'https://foursquare.com/v/community-supported-agriculture-csa--carnegie-hill/4e541d547d8b96cd060945aa', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(119, '4b4cc100f964a52061bd26e3', 'https://foursquare.com/v/key-food/4b4cc100f964a52061bd26e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(120, '4a7f0decf964a52099f21fe3', 'https://foursquare.com/v/food-for-health/4a7f0decf964a52099f21fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(121, '4a81c425f964a52083f71fe3', 'https://foursquare.com/v/ctown-supermarkets/4a81c425f964a52083f71fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(122, '4a81f12ff964a5200df81fe3', 'https://foursquare.com/v/elm-health/4a81f12ff964a5200df81fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(123, '4b9fa326f964a520993037e3', 'https://foursquare.com/v/straight-from-the-market/4b9fa326f964a520993037e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(124, '5042a6bee4b08d9f59487cd4', 'https://foursquare.com/v/turkish-market/5042a6bee4b08d9f59487cd4', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(125, '4c55b154479fc928c17e4c95', 'https://foursquare.com/v/92nd-street-greenmarket/4c55b154479fc928c17e4c95', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(126, '515c8e99b0b968b3c850e9c5', 'https://foursquare.com/v/ctown-supermarkets/515c8e99b0b968b3c850e9c5', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(127, '4ad9d4f4f964a520191b21e3', 'https://foursquare.com/v/the-vinegar-factory/4ad9d4f4f964a520191b21e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(128, '4b08a2f7f964a520fc0f23e3', 'https://foursquare.com/v/gristedes-supermarkets-053/4b08a2f7f964a520fc0f23e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(129, '4a7eef20f964a52052f21fe3', 'https://foursquare.com/v/eli-zabar/4a7eef20f964a52052f21fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(130, '4faa1abfe4b07c46549af990', 'https://foursquare.com/v/picklesandolives/4faa1abfe4b07c46549af990', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(131, '4b413414f964a5202ac325e3', 'https://foursquare.com/v/dagostino/4b413414f964a5202ac325e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(132, '5070581fe4b04d0cabd210d2', 'https://foursquare.com/v/greenmarket-farmers-market/5070581fe4b04d0cabd210d2', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(133, '4ffc8c1d1648c9b3aab4c59b', 'https://foursquare.com/v/82nd-street-greenmarket/4ffc8c1d1648c9b3aab4c59b', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(134, '4f88a4bce4b05ae8882076f4', 'https://foursquare.com/v/associated-supermarket-between-81-and-82/4f88a4bce4b05ae8882076f4', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(135, '4b2c3426f964a520b5c324e3', 'https://foursquare.com/v/gristedes-supermarkets-512/4b2c3426f964a520b5c324e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(136, '4be9f89462c0c9288b5ce0d4', 'https://foursquare.com/v/space-market/4be9f89462c0c9288b5ce0d4', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(137, '4cb8c54c7148f04de87bd2ab', 'https://foursquare.com/v/fruit-cart/4cb8c54c7148f04de87bd2ab', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(138, '4d6d0aef8a4541bddd658ae5', 'https://foursquare.com/v/food-emporium/4d6d0aef8a4541bddd658ae5', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(139, '5004cc8ee4b023056eec4c12', 'https://foursquare.com/v/grocery-store-for-sale/5004cc8ee4b023056eec4c12', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(140, '5004cae4e4b0029cc237c921', 'https://foursquare.com/v/grocery-store-for-rent/5004cae4e4b0029cc237c921', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(141, '4b60f2daf964a52005032ae3', 'https://foursquare.com/v/dagostino-at-56th-street/4b60f2daf964a52005032ae3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(142, '4eaeb70f02d5cf33faf1ab08', 'https://foursquare.com/v/dagostino-grocery-store/4eaeb70f02d5cf33faf1ab08', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(143, '4f10622c754a8b5556455915', 'https://foursquare.com/v/dagostino-at-53rd-street/4f10622c754a8b5556455915', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(144, '4defa40c31515b40632cee7d', 'https://foursquare.com/v/dag-hammarskjold-greenmarket/4defa40c31515b40632cee7d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(145, '5152b7d1e4b0c498f0ea7925', 'https://foursquare.com/v/fruit-stand-49th-and-2nd/5152b7d1e4b0c498f0ea7925', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(146, '4babfbb0f964a52089db3ae3', 'https://foursquare.com/v/health-harvest-health-food-store/4babfbb0f964a52089db3ae3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(147, '4dc44cb752b1e8f9f7b745dd', 'https://foursquare.com/v/street-market-at-43rd-st/4dc44cb752b1e8f9f7b745dd', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(148, '4ba22037f964a52089dd37e3', 'https://foursquare.com/v/greenwich-produce/4ba22037f964a52089dd37e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(149, '4abd24a1f964a520b68820e3', 'https://foursquare.com/v/food-emporium/4abd24a1f964a520b68820e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(150, '4b564121f964a520a50728e3', 'https://foursquare.com/v/gristedes-supermarkets-437/4b564121f964a520a50728e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(151, '4a81ea98f964a520f6f71fe3', 'https://foursquare.com/v/food-emporium/4a81ea98f964a520f6f71fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(152, '4e18c6f6d4c062b044ebf5d8', 'https://foursquare.com/v/fairway-market/4e18c6f6d4c062b044ebf5d8', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(153, '4b1725a5f964a52001c323e3', 'https://foursquare.com/v/gristedes-supermarkets-050/4b1725a5f964a52001c323e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(154, '4b5df7a5f964a520917629e3', 'https://foursquare.com/v/the-vitamin-shoppe/4b5df7a5f964a520917629e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(155, '4bd9b9110115c9b6e05e7880', 'https://foursquare.com/v/the-vitamin-shoppe/4bd9b9110115c9b6e05e7880', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(156, '4ad22d6df964a520dfdf20e3', 'https://foursquare.com/v/morton-williams/4ad22d6df964a520dfdf20e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(157, '4ad26cc4f964a5208fe120e3', 'https://foursquare.com/v/food-emporium/4ad26cc4f964a5208fe120e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(158, '3fd66200f964a52013e91ee3', 'https://foursquare.com/v/gourmet-garage/3fd66200f964a52013e91ee3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(159, '4bdc40822a3a0f473902b2b6', 'https://foursquare.com/v/fruit-stand-2nd-ave/4bdc40822a3a0f473902b2b6', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(160, '4f2ad1fa6b74bfbf8bb98162', 'https://foursquare.com/v/whole-foods-market/4f2ad1fa6b74bfbf8bb98162', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(161, '4a9af345f964a520bb3320e3', 'https://foursquare.com/v/katagiri/4a9af345f964a520bb3320e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(162, '4f288350e4b0f210ab88b761', 'https://foursquare.com/v/tomiya-japanese-grocery-store/4f288350e4b0f210ab88b761', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(163, '4b806e10f964a5209e7130e3', 'https://foursquare.com/v/food-emporium/4b806e10f964a5209e7130e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(164, '508b2782e4b0a1c847058008', 'https://foursquare.com/v/concept-stand-49/508b2782e4b0a1c847058008', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(165, '4a673d8ef964a52007c91fe3', 'https://foursquare.com/v/dag-hammarskj%C3%B6ld-plaza/4a673d8ef964a52007c91fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(166, '4a836c2ef964a52019fb1fe3', 'https://foursquare.com/v/morton-williams/4a836c2ef964a52019fb1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(167, '4a48fad7f964a520e2aa1fe3', 'https://foursquare.com/v/dainobu/4a48fad7f964a520e2aa1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(168, '4bd1a1f4046076b0721e7271', 'https://foursquare.com/v/diamobu-japanese-deli-grocery/4bd1a1f4046076b0721e7271', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(169, '4eba81d0be7b1e56202b33ae', 'https://foursquare.com/v/daj-hamerschold-plaza-farmers-market/4eba81d0be7b1e56202b33ae', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(170, '4ea0b087be7b643965275c4d', 'https://foursquare.com/v/tutties-grocery/4ea0b087be7b643965275c4d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(171, '4b6c7fe6f964a520043f2ce3', 'https://foursquare.com/v/the-vitamin-shoppe/4b6c7fe6f964a520043f2ce3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(172, '4c0939313c70b7131ac7275b', 'https://foursquare.com/v/smileys/4c0939313c70b7131ac7275b', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(173, '4c02bdc0187ec928b1aab47b', 'https://foursquare.com/v/food-emporium/4c02bdc0187ec928b1aab47b', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(174, '4b111995f964a520107823e3', 'https://foursquare.com/v/food-emporium-illy-cafe/4b111995f964a520107823e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(175, '4b0aa231f964a520cd2523e3', 'https://foursquare.com/v/gristedes-supermarkets/4b0aa231f964a520cd2523e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(176, '4baf634cf964a5202ffc3be3', 'https://foursquare.com/v/1-farmers-market/4baf634cf964a5202ffc3be3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(177, '4bc5c94a5935c9b6d657a6d2', 'https://foursquare.com/v/jowny-market/4bc5c94a5935c9b6d657a6d2', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(178, '4e4161ea1495c3b7024916b5', 'https://foursquare.com/v/international-fine-food/4e4161ea1495c3b7024916b5', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(179, '4b09a2bdf964a520bd1a23e3', 'https://foursquare.com/v/dagostino-at-76th-street/4b09a2bdf964a520bd1a23e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(180, '4ace59d0f964a5200ad020e3', 'https://foursquare.com/v/butterfield-market/4ace59d0f964a5200ad020e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(181, '4bd70ff36f6495215dd571ec', 'https://foursquare.com/v/dagostino-at-83rd-street/4bd70ff36f6495215dd571ec', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(182, '4b844ad7f964a520e12c31e3', 'https://foursquare.com/v/natural-frontier-market/4b844ad7f964a520e12c31e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(183, '4b3cc616f964a5201b8725e3', 'https://foursquare.com/v/gristedes-supermarkets-413/4b3cc616f964a5201b8725e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(184, '4af5d51cf964a5207cfd21e3', 'https://foursquare.com/v/food-emporium/4af5d51cf964a5207cfd21e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(185, '4c2fa71309a99c7413e30a2a', 'https://foursquare.com/v/citarella/4c2fa71309a99c7413e30a2a', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(186, '4b54b803f964a520c9c827e3', 'https://foursquare.com/v/eastside-health-food/4b54b803f964a520c9c827e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(187, '4bb67230ef159c743af875f7', 'https://foursquare.com/v/fruit-stand/4bb67230ef159c743af875f7', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(188, '4a8345d5f964a5209afa1fe3', 'https://foursquare.com/v/sugar-deli/4a8345d5f964a5209afa1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(189, '4c99323c9f259eb0fdf54885', 'https://foursquare.com/v/long-island-city-green-market/4c99323c9f259eb0fdf54885', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(190, '4c924676ae96a0934173aa46', 'https://foursquare.com/v/the-vitamin-shoppe/4c924676ae96a0934173aa46', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(191, '4bbe5dafb083a593ece5a1e9', 'https://foursquare.com/v/organic-market-on-7th/4bbe5dafb083a593ece5a1e9', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(192, '4beadb5861aca5938b418400', 'https://foursquare.com/v/the-vitamin-shoppe/4beadb5861aca5938b418400', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(193, '4ba90328f964a5207d033ae3', 'https://foursquare.com/v/dagostino-at-38th-street/4ba90328f964a5207d033ae3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(194, '4b5f3fe6f964a520f7af29e3', 'https://foursquare.com/v/kool-bloo/4b5f3fe6f964a520f7af29e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(195, '4b3fe657f964a52098b125e3', 'https://foursquare.com/v/dagostino-at-35th-street/4b3fe657f964a52098b125e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(196, '4b47997bf964a520eb3626e3', 'https://foursquare.com/v/healthsmart-of-ny/4b47997bf964a520eb3626e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(197, '4bba52b2935e9521de002890', 'https://foursquare.com/v/novello-market/4bba52b2935e9521de002890', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(198, '4d2a032e068e8cfa4a92d54c', 'https://foursquare.com/v/murray-hill-farmers-market/4d2a032e068e8cfa4a92d54c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(199, '50c4d618e4b0dee5440160a3', 'https://foursquare.com/v/fairway-market/50c4d618e4b0dee5440160a3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(200, '4b3a79aff964a520296825e3', 'https://foursquare.com/v/cvspharmacy/4b3a79aff964a520296825e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(201, '4a92cb16f964a520b81d20e3', 'https://foursquare.com/v/rite-aid/4a92cb16f964a520b81d20e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(202, '4b6f3a0ff964a52074e52ce3', 'https://foursquare.com/v/gristedes-supermarkets/4b6f3a0ff964a52074e52ce3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(203, '4a9d4430f964a520103820e3', 'https://foursquare.com/v/food-emporium/4a9d4430f964a520103820e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(204, '4f610651e4b0233fb2db9501', 'https://foursquare.com/v/fruit-stand-at-34st--3rd-ave/4f610651e4b0233fb2db9501', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(205, '4e91ad5d5c5c4562f07439a0', 'https://foursquare.com/v/sunday-market/4e91ad5d5c5c4562f07439a0', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(206, '4a8212abf964a5207af81fe3', 'https://foursquare.com/v/murray-hill-market/4a8212abf964a5207af81fe3', NULL, NULL, 'https://foursquare.com/v/murray-hill-market/4a8212abf964a5207af81fe3/menu', 'foodAndBeverage');
INSERT INTO `venue_meta_foursquare` VALUES(207, '4e053a45483b98d417027510', 'https://foursquare.com/v/fruit-cart/4e053a45483b98d417027510', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(208, '4b929832f964a520ef0734e3', 'https://foursquare.com/v/han-au-mart/4b929832f964a520ef0734e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(209, '4a84bfebf964a52086fd1fe3', 'https://foursquare.com/v/prince-george-csa/4a84bfebf964a52086fd1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(210, '4ac4f9c1f964a520c99f20e3', 'https://foursquare.com/v/hanahreum-asian-mart/4ac4f9c1f964a520c99f20e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(211, '4ff1faeae4b099c410ded43c', 'https://foursquare.com/v/ah-food-plaza/4ff1faeae4b099c410ded43c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(212, '4e8ca4d69adf4a7ef329cb7f', 'https://foursquare.com/v/cafe-n-more/4e8ca4d69adf4a7ef329cb7f', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(213, '4a78d49ef964a52087e61fe3', 'https://foursquare.com/v/nsa-markets/4a78d49ef964a52087e61fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(214, '5151cb06e4b0cacc496a3298', 'https://foursquare.com/v/cooking-up-a-new-birthday-cake/5151cb06e4b0cacc496a3298', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(215, '4b0dfe8df964a520a55323e3', 'https://foursquare.com/v/gristedes-supermarkets-562/4b0dfe8df964a520a55323e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(216, '460d4b66f964a52005451fe3', 'https://foursquare.com/v/whole-foods-market/460d4b66f964a52005451fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(217, '49d7d332f964a520675d1fe3', 'https://foursquare.com/v/whole-foods-market/49d7d332f964a520675d1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(218, '45940e37f964a52055401fe3', 'https://foursquare.com/v/kalustyans/45940e37f964a52055401fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(219, '4a8b32eef964a520c00b20e3', 'https://foursquare.com/v/foods-of-india/4a8b32eef964a520c00b20e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(220, '4c99326f9f259eb03df64885', 'https://foursquare.com/v/vestal-farmers-market/4c99326f9f259eb03df64885', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(221, '4c409775d7fad13ab43506da', 'https://foursquare.com/v/harvest-home-farmers-market/4c409775d7fad13ab43506da', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(222, '4b01c0b3f964a520254522e3', 'https://foursquare.com/v/morton-williams/4b01c0b3f964a520254522e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(223, '4b008389f964a520123f22e3', 'https://foursquare.com/v/gristedes-supermarkets/4b008389f964a520123f22e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(224, '4b4ff774f964a5207f1a27e3', 'https://foursquare.com/v/morton-williams/4b4ff774f964a5207f1a27e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(225, '4bdb4bf54b1f952169ac670b', 'https://foursquare.com/v/natural-frontier-market/4bdb4bf54b1f952169ac670b', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(226, '4f5ab688e4b086681a733a3d', 'https://foursquare.com/v/natural-health-food/4f5ab688e4b086681a733a3d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(227, '50982274e4b0ad0d975363f1', 'https://foursquare.com/v/unsq-greenmarket--madison-sq/50982274e4b0ad0d975363f1', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(228, '50953f7de4b09d8b5e8bf14c', 'https://foursquare.com/v/flatiron-farmers-market/50953f7de4b09d8b5e8bf14c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(229, '4dd7e27352b1a5c64457661a', 'https://foursquare.com/v/sixth-ave-street-fair/4dd7e27352b1a5c64457661a', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(230, '3fd66200f964a5209de51ee3', 'https://foursquare.com/v/garden-of-eden/3fd66200f964a5209de51ee3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(231, '4c225ae47e85c9283ee5bb21', 'https://foursquare.com/v/trader-joes/4c225ae47e85c9283ee5bb21', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(232, '4b040d2af964a5201f5122e3', 'https://foursquare.com/v/the-vitamin-shoppe/4b040d2af964a5201f5122e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(233, '4c24dedf905a0f4736796060', 'https://foursquare.com/v/fruit-dealer/4c24dedf905a0f4736796060', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(234, '49bfb395f964a52018551fe3', 'https://foursquare.com/v/merci-market/49bfb395f964a52018551fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(235, '507b6a24e4b08aa6bf6a0c24', 'https://foursquare.com/v/grostedes/507b6a24e4b08aa6bf6a0c24', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(236, '4c4e23c7d667d13a3d9ceb9f', 'https://foursquare.com/v/famous-deli-and-grocery/4c4e23c7d667d13a3d9ceb9f', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(237, '4ffc7d131648574e020d0872', 'https://foursquare.com/v/ps-11-farm-market/4ffc7d131648574e020d0872', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(238, '49b80795f964a52034531fe3', 'https://foursquare.com/v/westside-market/49b80795f964a52034531fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(239, '4cdd66934006a143be17e5b2', 'https://foursquare.com/v/elm-health/4cdd66934006a143be17e5b2', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(240, '4b55f1adf964a520f2f727e3', 'https://foursquare.com/v/the-vitamin-shoppe/4b55f1adf964a520f2f727e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(241, '4e55583b814d6ce5cc846dfb', 'https://foursquare.com/v/eataly-hq/4e55583b814d6ce5cc846dfb', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(242, '4b69feebf964a52098c02be3', 'https://foursquare.com/v/the-vitamin-shoppe/4b69feebf964a52098c02be3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(243, '4e9b201c29c27d6ad6dcaff6', 'https://foursquare.com/v/union-market/4e9b201c29c27d6ad6dcaff6', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(244, '4ee3b3e893adf8e1a6ed3b5d', 'https://foursquare.com/v/knoll-krest-farm/4ee3b3e893adf8e1a6ed3b5d', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(245, '4c99329c9f259eb079f64885', 'https://foursquare.com/v/pulaski-farmers-market/4c99329c9f259eb079f64885', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(246, '4fa3f3e5e4b0bcbb45e89629', 'https://foursquare.com/v/tremblay-apiaries/4fa3f3e5e4b0bcbb45e89629', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(247, '4f511789e4b0b71c79c0d4c6', 'https://foursquare.com/v/tellos-green-farm/4f511789e4b0b71c79c0d4c6', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(248, '4c94f76503413704c10c77ef', 'https://foursquare.com/v/three-corner-field-farm-stand/4c94f76503413704c10c77ef', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(249, '4b2eb792f964a52092e524e3', 'https://foursquare.com/v/dagostino-supermarket/4b2eb792f964a52092e524e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(250, '4aabbb05f964a520df5920e3', 'https://foursquare.com/v/gracefully/4aabbb05f964a520df5920e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(251, '4c9f88e1542b224b453ffe9f', 'https://foursquare.com/v/stuyvesant-town-greenmarket/4c9f88e1542b224b453ffe9f', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(252, '4b146cbef964a520f2a223e3', 'https://foursquare.com/v/associated-supermarket/4b146cbef964a520f2a223e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(253, '49e80026f964a52037651fe3', 'https://foursquare.com/v/zaragoza-mexican-deligrocery/49e80026f964a52037651fe3', NULL, NULL, 'https://foursquare.com/v/zaragoza-mexican-deligrocery/49e80026f964a52037651fe3/menu', 'foodAndBeverage');
INSERT INTO `venue_meta_foursquare` VALUES(254, '4c8e7d8914fdb713caec30c4', 'https://foursquare.com/v/the-vitamin-shoppe/4c8e7d8914fdb713caec30c4', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(255, '4b8448f5f964a5206f2c31e3', 'https://foursquare.com/v/johnny-air-mart/4b8448f5f964a5206f2c31e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(256, '4b675803f964a52051492be3', 'https://foursquare.com/v/stuyvesant-convenience-deli--grocery/4b675803f964a52051492be3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(257, '441a8599f964a52036311fe3', 'https://foursquare.com/v/trader-joes/441a8599f964a52036311fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(258, '4a319883f964a520fc991fe3', 'https://foursquare.com/v/trader-joes-wine-shop/4a319883f964a520fc991fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(259, '4a723953f964a520a2da1fe3', 'https://foursquare.com/v/m2m-mart/4a723953f964a520a2da1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(260, '51041ecde4b026c3c0269957', 'https://foursquare.com/v/paffenroth-farms/51041ecde4b026c3c0269957', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(261, '4bf97ea55317a593cc5f017f', 'https://foursquare.com/v/health-food-store/4bf97ea55317a593cc5f017f', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(262, '4b401178f964a52033b525e3', 'https://foursquare.com/v/cb-convenience-store/4b401178f964a52033b525e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(263, '43bba61df964a520eb2c1fe3', 'https://foursquare.com/v/whole-foods-market/43bba61df964a520eb2c1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(264, '45b3d761f964a520b1411fe3', 'https://foursquare.com/v/food-emporium/45b3d761f964a520b1411fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(265, '49c27575f964a520f1551fe3', 'https://foursquare.com/v/union-square-greenmarket/49c27575f964a520f1551fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(266, '4c58cebc04f9be9a3f01ee60', 'https://foursquare.com/v/farmers-market/4c58cebc04f9be9a3f01ee60', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(267, '4be305122ff376b024444fed', 'https://foursquare.com/v/sarahs-fruit-stand/4be305122ff376b024444fed', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(268, '4ccad653d7538cfa3eb4f578', 'https://foursquare.com/v/breezy-hill-orchards--union-sq-greenmarket/4ccad653d7538cfa3eb4f578', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(269, '4c530c114623be9ab08e7bf0', 'https://foursquare.com/v/martins-pretzels/4c530c114623be9ab08e7bf0', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(270, '513b9bcbe4b09b144d838438', 'https://foursquare.com/v/valley-shepherd-creamery/513b9bcbe4b09b144d838438', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(271, '513232f1e4b090129650d1f9', 'https://foursquare.com/v/paffenroth-gardens/513232f1e4b090129650d1f9', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(272, '513b9e53e4b02ba20cec4d97', 'https://foursquare.com/v/tundra-brewery/513b9e53e4b02ba20cec4d97', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(273, '4bae3c92f964a5207a963be3', 'https://foursquare.com/v/milk-thistle-stand/4bae3c92f964a5207a963be3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(274, '4c59aadfd3aee21ee2c96855', 'https://foursquare.com/v/ricks-picks--union-square-greenmarket/4c59aadfd3aee21ee2c96855', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(275, '4df3d26a1f6e818dae0230a3', 'https://foursquare.com/v/berkshire-berries-stand/4df3d26a1f6e818dae0230a3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(276, '4b92c291f964a5202a1934e3', 'https://foursquare.com/v/locust-grove-fruit/4b92c291f964a5202a1934e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(277, '5059b1ee8302b8a619d49f3b', 'https://foursquare.com/v/max-delivery/5059b1ee8302b8a619d49f3b', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(278, '4a06192ff964a520b7721fe3', 'https://foursquare.com/v/gustorganics/4a06192ff964a520b7721fe3', NULL, NULL, 'https://foursquare.com/v/gustorganics/4a06192ff964a520b7721fe3/menu', 'foodAndBeverage');
INSERT INTO `venue_meta_foursquare` VALUES(279, '4ced2c70840a9eb01cb79f13', 'https://foursquare.com/v/the-vitamin-shoppe/4ced2c70840a9eb01cb79f13', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(280, '4c461ce23f0276b0625b52e7', 'https://foursquare.com/v/food-emporium/4c461ce23f0276b0625b52e7', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(281, '4bbcb3cbf57ba5936918adb9', 'https://foursquare.com/v/integral-yoga-foods/4bbcb3cbf57ba5936918adb9', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(282, '41390580f964a520dc1a1fe3', 'https://foursquare.com/v/chelsea-market/41390580f964a520dc1a1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(283, '4ad25b7df964a5201ee120e3', 'https://foursquare.com/v/associated-supermarket/4ad25b7df964a5201ee120e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(284, '4b0340a0f964a520f74d22e3', 'https://foursquare.com/v/14-organic-gourmet-foods/4b0340a0f964a520f74d22e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(285, '4fedf89ce4b0d96619623162', 'https://foursquare.com/v/french-market/4fedf89ce4b0d96619623162', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(286, '4a7dbcc3f964a5206bef1fe3', 'https://foursquare.com/v/buon-italia/4a7dbcc3f964a5206bef1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(287, '49d375a6f964a520f95b1fe3', 'https://foursquare.com/v/manhattan-fruit-exchange/49d375a6f964a520f95b1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(288, '4afefaeff964a520743222e3', 'https://foursquare.com/v/nut-box--chelsea-market/4afefaeff964a520743222e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(289, '4ac92677f964a520dfbe20e3', 'https://foursquare.com/v/western-beef/4ac92677f964a520dfbe20e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(290, '4aa1c2fcf964a5208f4120e3', 'https://foursquare.com/v/dagostino-at-greenwich-village/4aa1c2fcf964a5208f4120e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(291, '4a970fd1f964a5203a2820e3', 'https://foursquare.com/v/abingdon-square-greenmarket/4a970fd1f964a5203a2820e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(292, '4b5c75ecf964a520f83029e3', 'https://foursquare.com/v/gristedes-supermarkets/4b5c75ecf964a520f83029e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(293, '4ad3ed2af964a520f8e620e3', 'https://foursquare.com/v/gourmet-garage/4ad3ed2af964a520f8e620e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(294, '3fd66200f964a52015e71ee3', 'https://foursquare.com/v/lifethyme-natural-market/3fd66200f964a52015e71ee3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(295, '4c7c2cb7a141b1f7806f6a79', 'https://foursquare.com/v/the-vitamin-shoppe/4c7c2cb7a141b1f7806f6a79', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(296, '4af95f55f964a5207d1122e3', 'https://foursquare.com/v/corrados/4af95f55f964a5207d1122e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(297, '4b7d7343f964a5201dbf2fe3', 'https://foursquare.com/v/evas-vitamin-shop/4b7d7343f964a5201dbf2fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(298, '4a3cf74ff964a520b3a11fe3', 'https://foursquare.com/v/citarella/4a3cf74ff964a520b3a11fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(299, '4e10079a1838f8ad814f004a', 'https://foursquare.com/v/epicurian/4e10079a1838f8ad814f004a', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(300, '4f32a41219836c91c7eb7f4e', 'https://foursquare.com/v/9th-st-farmers-market/4f32a41219836c91c7eb7f4e', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(301, '5154b4a9e4b0e61759d0d30c', 'https://foursquare.com/v/evas-vitamin-shoppe/5154b4a9e4b0e61759d0d30c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(302, '4e986e517bebb3605ac8d716', 'https://foursquare.com/v/hyvee/4e986e517bebb3605ac8d716', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(303, '4a60f44cf964a5208bc11fe3', 'https://foursquare.com/v/open-pantry-food-mart/4a60f44cf964a5208bc11fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(304, '4b1462d3f964a52057a223e3', 'https://foursquare.com/v/village-farm--grocery/4b1462d3f964a52057a223e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(305, '4c9931c29f259eb077f54885', 'https://foursquare.com/v/st-marks-church-greenmarket/4c9931c29f259eb077f54885', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(306, '4a91d265f964a520fd1b20e3', 'https://foursquare.com/v/dual-specialty/4a91d265f964a520fd1b20e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(307, '4b2415fdf964a520c26024e3', 'https://foursquare.com/v/metropolitan-citymarket/4b2415fdf964a520c26024e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(308, '4a6fc118f964a520f4d61fe3', 'https://foursquare.com/v/east-village-farm--grocery/4a6fc118f964a520f4d61fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(309, '4b80815cf964a520477830e3', 'https://foursquare.com/v/healthfully-organic-food-market/4b80815cf964a520477830e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(310, '4f4e94f6e4b07dc4ef4594f7', 'https://foursquare.com/v/the-met/4f4e94f6e4b07dc4ef4594f7', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(311, '4baa45e4f964a520e0593ae3', 'https://foursquare.com/v/2nd-avenue-grocery/4baa45e4f964a520e0593ae3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(312, '4aa6fe31f964a520ba4b20e3', 'https://foursquare.com/v/commodities-natural-market/4aa6fe31f964a520ba4b20e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(313, '4ab65b0af964a520b87620e3', 'https://foursquare.com/v/tompkins-square-greenmarket/4ab65b0af964a520b87620e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(314, '4a7610dbf964a52018e21fe3', 'https://foursquare.com/v/associated-supermarket/4a7610dbf964a52018e21fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(315, '4feb37eae4b0cb016209edfc', 'https://foursquare.com/v/anwar-grocery/4feb37eae4b0cb016209edfc', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(316, '4c890d3197828cfad0f4a0aa', 'https://foursquare.com/v/compare-foods/4c890d3197828cfad0f4a0aa', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(317, '4be6d5c92457a593632cad15', 'https://foursquare.com/v/ctown-supermarkets/4be6d5c92457a593632cad15', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(318, '50d610dce4b00d641e49a493', 'https://foursquare.com/v/new-york-healthy-choice/50d610dce4b00d641e49a493', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(319, '4add1db0f964a520286421e3', 'https://foursquare.com/v/met-food/4add1db0f964a520286421e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(320, '4a381289f964a520ad9e1fe3', 'https://foursquare.com/v/garden-of-eden/4a381289f964a520ad9e1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(321, '4be30dd91dd22d7f279595bd', 'https://foursquare.com/v/westside-supermarket/4be30dd91dd22d7f279595bd', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(322, '4fc61afbe4b0b0e32c9e1e50', 'https://foursquare.com/v/agata--valentina/4fc61afbe4b0b0e32c9e1e50', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(323, '4fd1535fe4b0d4674d1a101b', 'https://foursquare.com/v/agata--valentina-market/4fd1535fe4b0d4674d1a101b', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(324, '4e4e4d78bd4101d0d7a73ae6', 'https://foursquare.com/v/jefferson-market-catering/4e4e4d78bd4101d0d7a73ae6', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(325, '4bd838ab09ecb7131d4b487c', 'https://foursquare.com/v/24th-street-fruit-stand/4bd838ab09ecb7131d4b487c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(326, '4bd981c62e6f0f47abc50a08', 'https://foursquare.com/v/the-vitamin-shoppe/4bd981c62e6f0f47abc50a08', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(327, '4aa6d0a0f964a520154b20e3', 'https://foursquare.com/v/gristedes-supermarkets-421/4aa6d0a0f964a520154b20e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(328, '4b854983f964a520b75431e3', 'https://foursquare.com/v/health-4u-natures-market/4b854983f964a520b75431e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(329, '4bd47598637ba59336aef470', 'https://foursquare.com/v/gristedes-supermarkets-597/4bd47598637ba59336aef470', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(330, '4f592ed2e4b0abc30cd81ccd', 'https://foursquare.com/v/foragers-city-grocer/4f592ed2e4b0abc30cd81ccd', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(331, '4ba7ef65f964a520fabf39e3', 'https://foursquare.com/v/the-vitamin-shoppe/4ba7ef65f964a520fabf39e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(332, '4b4e252cf964a520d9e226e3', 'https://foursquare.com/v/gristedes-supermarkets-545/4b4e252cf964a520d9e226e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(333, '4bbd185af57ba5932cb3adb9', 'https://foursquare.com/v/health-food--vitamin-city/4bbd185af57ba5932cb3adb9', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(334, '4c157c24a5eb76b0ab7ac3b7', 'https://foursquare.com/v/chelsea-terrace-supermarketl/4c157c24a5eb76b0ab7ac3b7', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(335, '3fd66200f964a5208be71ee3', 'https://foursquare.com/v/international-grocery/3fd66200f964a5208be71ee3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(336, '4f356173e4b0c9801de68080', 'https://foursquare.com/v/merci-market/4f356173e4b0c9801de68080', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(337, '4b521627f964a520b86627e3', 'https://foursquare.com/v/big-apple-meat-market/4b521627f964a520b86627e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(338, '4bd0af56a8b3a5934666645f', 'https://foursquare.com/v/port-authority-green-market/4bd0af56a8b3a5934666645f', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(339, '4a5237b2f964a52067b11fe3', 'https://foursquare.com/v/dean--deluca/4a5237b2f964a52067b11fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(340, '4b15b73af964a52020b323e3', 'https://foursquare.com/v/stop-shop--port-authority/4b15b73af964a52020b323e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(341, '4bcc596bcc8cd13a5cb7c0cf', 'https://foursquare.com/v/c-town-markets/4bcc596bcc8cd13a5cb7c0cf', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(342, '4a50dcf5f964a5202db01fe3', 'https://foursquare.com/v/marche-madison/4a50dcf5f964a5202db01fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(343, '4b79dc8bf964a520bb162fe3', 'https://foursquare.com/v/gristedes-supermarkets/4b79dc8bf964a520bb162fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(344, '4b8d2319f964a520c8e932e3', 'https://foursquare.com/v/gristedes-supermarkets/4b8d2319f964a520c8e932e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(345, '4b22a53ff964a520fd4a24e3', 'https://foursquare.com/v/gristedes-supermarkets/4b22a53ff964a520fd4a24e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(346, '4b67635df964a520db4b2be3', 'https://foursquare.com/v/4th-street-food-coop/4b67635df964a520db4b2be3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(347, '4a7322baf964a520a5db1fe3', 'https://foursquare.com/v/st-marks-market/4a7322baf964a520a5db1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(348, '4206af80f964a520731f1fe3', 'https://foursquare.com/v/jas-mart/4206af80f964a520731f1fe3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(349, '4db66ff2cda1c57c828363cb', 'https://foursquare.com/v/indomart-muncul/4db66ff2cda1c57c828363cb', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(350, '4b2f244df964a520bae924e3', 'https://foursquare.com/v/key-food/4b2f244df964a520bae924e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(351, '50e06306e4b05f459eaa8c77', 'https://foursquare.com/v/supermercado-tiele/50e06306e4b05f459eaa8c77', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(352, '506a1270e4b0ab992581b981', 'https://foursquare.com/v/ctown-supermarkets/506a1270e4b0ab992581b981', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(353, '4b453cabf964a520c40826e3', 'https://foursquare.com/v/shoprite/4b453cabf964a520c40826e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(354, '4b90306af964a5202b7b33e3', 'https://foursquare.com/v/shoprite/4b90306af964a5202b7b33e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(355, '4bb62dff1344b713dd189d04', 'https://foursquare.com/v/hillside-market/4bb62dff1344b713dd189d04', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(356, '4b06e5e4f964a5207ef222e3', 'https://foursquare.com/v/pathmark-amboy-rd/4b06e5e4f964a5207ef222e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(357, '4b5362f1f964a5202d9a27e3', 'https://foursquare.com/v/super-stop--shop/4b5362f1f964a5202d9a27e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(358, '4b8029f6f964a5203e5830e3', 'https://foursquare.com/v/pathmark/4b8029f6f964a5203e5830e3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(359, '4d6ac28d92f6b60c6bed98e0', 'https://foursquare.com/v/shop--save-superette/4d6ac28d92f6b60c6bed98e0', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(360, '4c090c3bffb8c9b6b42a6961', 'https://foursquare.com/v/mignosis-supermarket/4c090c3bffb8c9b6b42a6961', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(361, '4eb7ed7db8f786e2763f7adb', 'https://foursquare.com/v/la-bella-marketplace/4eb7ed7db8f786e2763f7adb', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(362, '4c0d64c6c700c9b65c56a2dd', 'https://foursquare.com/v/waldbaums/4c0d64c6c700c9b65c56a2dd', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(363, '4f197bffe4b0b7e25669cf2c', 'https://foursquare.com/v/stop--shop/4f197bffe4b0b7e25669cf2c', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(364, '4f6a301ce4b0f629e0db08e7', 'https://foursquare.com/v/grocery-store-/4f6a301ce4b0f629e0db08e7', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(365, '4d98a8380caaa14367ebb1b3', 'https://foursquare.com/v/de-montes--eltingville/4d98a8380caaa14367ebb1b3', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(366, '4e125f4cd1647a0fff8969bb', 'https://foursquare.com/v/christophers-food-mart/4e125f4cd1647a0fff8969bb', NULL, NULL, NULL, NULL);
INSERT INTO `venue_meta_foursquare` VALUES(367, '4be577812468c92844070043', 'https://foursquare.com/v/st-george-farmers-market/4be577812468c92844070043', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `venue_meta_healthyfood`
--

CREATE TABLE `venue_meta_healthyfood` (
  `id` int(12) NOT NULL,
  `price_score` int(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `venue_meta_healthyfood`
--

INSERT INTO `venue_meta_healthyfood` VALUES(70, 45);
INSERT INTO `venue_meta_healthyfood` VALUES(141, 100);
INSERT INTO `venue_meta_healthyfood` VALUES(231, 65);
INSERT INTO `venue_meta_healthyfood` VALUES(257, 65);

-- --------------------------------------------------------

--
-- Table structure for table `venue_meta_instagram`
--

CREATE TABLE `venue_meta_instagram` (
  `id` int(12) NOT NULL,
  `venue_instagram_id` varchar(32) NOT NULL,
  `canonicalUrl` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `venue_instagram_id` (`venue_instagram_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `venue_meta_instagram`
--


-- --------------------------------------------------------

--
-- Table structure for table `venue_meta_twitter`
--

CREATE TABLE `venue_meta_twitter` (
  `id` int(12) NOT NULL,
  `mentions` int(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `venue_meta_twitter`
--


-- --------------------------------------------------------

--
-- Table structure for table `venue_record`
--

CREATE TABLE `venue_record` (
  `id` int(12) NOT NULL,
  `checkin` int(8) DEFAULT '0',
  `checkin_unique` int(8) DEFAULT '0',
  `comment` int(8) DEFAULT '0',
  `like` int(8) DEFAULT '0',
  `review` int(8) DEFAULT '0',
  `image` int(8) DEFAULT '0',
  `rating` int(4) DEFAULT NULL,
  `photos` int(8) DEFAULT NULL,
  `specials` int(6) DEFAULT NULL,
  `herenow` int(8) DEFAULT NULL,
  `mayor` int(6) DEFAULT NULL,
  `price` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `venue_record`
--

INSERT INTO `venue_record` VALUES(1, 3846, NULL, NULL, 0, 21, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(2, 288, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(3, 415, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(4, 22, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(5, 24, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(6, 568, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(7, 33, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(8, 5, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(9, 8, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(10, 89, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(11, 350, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(12, 1257, NULL, NULL, 0, 13, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(13, 33, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(14, 2345, NULL, NULL, 0, 12, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(15, 2, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(16, 29, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(17, 383, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(18, 9, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(19, 475, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(20, 3, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(21, 5, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(22, 29, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(23, 8, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(24, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(25, 786, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(26, 22, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(27, 118, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(28, 427, NULL, NULL, 0, 10, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(29, 8255, NULL, NULL, 0, 83, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(30, 284, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(31, 5, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(32, 390, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(33, 92, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(34, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(35, 501, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(36, 8, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(37, 17, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(38, 29, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(39, 310, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(40, 7, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(41, 27, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(42, 861, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(43, 687, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(44, 82, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(45, 95, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(46, 895, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(47, 208, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(48, 77, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(49, 95, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(50, 75, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(51, 5, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(52, 491, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(53, 15, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(54, 8, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(55, 19, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(56, 549, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(57, 25, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(58, 1826, NULL, NULL, 0, 13, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(59, 42, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(60, 4, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(61, 31, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(62, 44, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(63, 409, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(64, 145, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(65, 693, NULL, NULL, 0, 10, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(66, 3090, NULL, NULL, 0, 43, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(67, 23, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(68, 5, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(69, 366, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(70, 346, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(71, 10062, NULL, NULL, 0, 63, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(72, 125, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(73, 2, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(74, 239, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(75, 543, NULL, NULL, 0, 9, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(76, 1181, NULL, NULL, 0, 17, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(77, 1732, NULL, NULL, 0, 14, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(78, 1, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(79, 494, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(80, 55, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(81, 256, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(82, 12, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(83, 3890, NULL, NULL, 0, 29, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(84, 67, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(85, 111, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(86, 138, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(87, 217, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(88, 76, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(89, 13, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(90, 15042, NULL, NULL, 0, 48, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(91, 48, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(92, 39, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(93, 50, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(94, 15, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(95, 387, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(96, 262, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(97, 13, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(98, 933, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(99, 445, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(100, 516, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(101, 229, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(102, 1003, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(103, 69, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(104, 4, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(105, 641, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(106, 68, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(107, 165, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(108, 55, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(109, 159, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(110, 5, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(111, 14, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(112, 752, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(113, 1848, NULL, NULL, 0, 11, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(114, 107, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(115, 1097, NULL, NULL, 0, 10, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(116, 16, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(117, 184, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(118, 2, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(119, 2135, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(120, 666, NULL, NULL, 0, 9, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(121, 2618, NULL, NULL, 0, 12, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(122, 658, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(123, 373, NULL, NULL, 0, 11, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(124, 6, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(125, 117, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(126, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(127, 1264, NULL, NULL, 0, 8, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(128, 652, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(129, 173, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(130, 12, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(131, 2366, NULL, NULL, 0, 12, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(132, 34, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(133, 19, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(134, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(135, 1411, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(136, 779, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(137, 25, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(138, 3865, NULL, NULL, 0, 21, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(139, 5, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(140, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(141, 1036, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(142, 334, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(143, 183, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(144, 334, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(145, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(146, 111, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(147, 4, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(148, 69, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(149, 504, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(150, 875, NULL, NULL, 0, 9, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(151, 2135, NULL, NULL, 0, 27, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(152, 17461, NULL, NULL, 0, 96, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(153, 1555, NULL, NULL, 0, 9, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(154, 157, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(155, 197, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(156, 1625, NULL, NULL, 0, 14, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(157, 2581, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(158, 1339, NULL, NULL, 0, 10, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(159, 61, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(160, 6224, NULL, NULL, 0, 33, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(161, 1447, NULL, NULL, 0, 10, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(162, 91, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(163, 1691, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(164, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(165, 2524, NULL, NULL, 0, 18, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(166, 2789, NULL, NULL, 0, 16, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(167, 2754, NULL, NULL, 0, 15, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(168, 48, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(169, 97, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(170, 9, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(171, 160, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(172, 274, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(173, 1262, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(174, 2864, NULL, NULL, 0, 13, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(175, 1300, NULL, NULL, 0, 10, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(176, 278, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(177, 36, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(178, 6, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(179, 804, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(180, 1662, NULL, NULL, 0, 20, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(181, 522, NULL, NULL, 0, 8, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(182, 451, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(183, 1100, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(184, 1889, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(185, 2111, NULL, NULL, 0, 21, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(186, 409, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(187, 39, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(188, 1017, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(189, 8, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(190, 173, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(191, 8, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(192, 170, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(193, 1046, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(194, 259, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(195, 1498, NULL, NULL, 0, 8, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(196, 514, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(197, 530, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(198, 120, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(199, 3680, NULL, NULL, 0, 22, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(200, 2807, NULL, NULL, 0, 10, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(201, 1517, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(202, 1902, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(203, 1641, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(204, 16, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(205, 5, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(206, 2410, NULL, NULL, 0, 16, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(207, 4, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(208, 45, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(209, 149, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(210, 3878, NULL, NULL, 0, 18, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(211, 3, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(212, 16, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(213, 1382, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(214, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(215, 1432, NULL, NULL, 0, 8, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(216, 28890, NULL, NULL, 0, 110, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(217, 2531, NULL, NULL, 0, 8, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(218, 2607, NULL, NULL, 0, 50, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(219, 23, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(220, 4, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(221, 41, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(222, 2540, NULL, NULL, 0, 17, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(223, 2662, NULL, NULL, 0, 12, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(224, 2627, NULL, NULL, 0, 16, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(225, 808, NULL, NULL, 0, 11, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(226, 10, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(227, 16, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(228, 11, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(229, 279, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(230, 3543, NULL, NULL, 0, 23, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(231, 44966, NULL, NULL, 0, 176, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(232, 433, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(233, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(234, 1785, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(235, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(236, 9, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(237, 1, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(238, 10288, NULL, NULL, 0, 64, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(239, 1157, NULL, NULL, 0, 14, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(240, 410, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(241, 369, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(242, 416, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(243, 3, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(244, 31, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(245, 24, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(246, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(247, 2, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(248, 2, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(249, 2403, NULL, NULL, 0, 13, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(250, 3424, NULL, NULL, 0, 19, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(251, 408, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(252, 4264, NULL, NULL, 0, 13, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(253, 2543, NULL, NULL, 0, 50, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(254, 244, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(255, 195, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(256, 29, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(257, 40568, NULL, NULL, 0, 185, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(258, 15841, NULL, NULL, 0, 61, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(259, 4950, NULL, NULL, 0, 28, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(260, 2, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(261, 66, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(262, 16, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(263, 62225, NULL, NULL, 0, 254, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(264, 6175, NULL, NULL, 0, 22, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(265, 64539, NULL, NULL, 0, 269, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(266, 468, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(267, 94, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(268, 113, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(269, 63, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(270, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(271, 2, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(272, 1, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(273, 17, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(274, 47, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(275, 9, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(276, 14, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(277, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(278, 3412, NULL, NULL, 0, 55, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(279, 218, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(280, 964, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(281, 791, NULL, NULL, 0, 11, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(282, 81155, NULL, NULL, 0, 323, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(283, 1402, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(284, 281, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(285, 13, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(286, 1120, NULL, NULL, 0, 19, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(287, 2869, NULL, NULL, 0, 20, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(288, 313, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(289, 995, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(290, 1680, NULL, NULL, 0, 9, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(291, 1093, NULL, NULL, 0, 17, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(292, 1214, NULL, NULL, 0, 12, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(293, 2652, NULL, NULL, 0, 19, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(294, 2727, NULL, NULL, 0, 40, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(295, 189, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(296, 865, NULL, NULL, 0, 12, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(297, 133, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(298, 3884, NULL, NULL, 0, 27, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(299, 17, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(300, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(301, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(302, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(303, 672, NULL, NULL, 0, 8, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(304, 1459, NULL, NULL, 0, 10, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(305, 146, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(306, 610, NULL, NULL, 0, 15, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(307, 1034, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(308, 719, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(309, 201, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(310, 32, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(311, 30, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(312, 1269, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(313, 1530, NULL, NULL, 0, 16, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(314, 1534, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(315, 13, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(316, 383, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(317, 456, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(318, 22, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(319, 963, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(320, 3048, NULL, NULL, 0, 22, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(321, 9, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(322, 1421, NULL, NULL, 0, 15, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(323, 173, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(324, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(325, 142, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(326, 433, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(327, 1460, NULL, NULL, 0, 5, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(328, 574, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(329, 1086, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(330, 1669, NULL, NULL, 0, 20, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(331, 570, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(332, 938, NULL, NULL, 0, 9, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(333, 48, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(334, 263, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(335, 179, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(336, 1331, NULL, NULL, 0, 9, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(337, 1409, NULL, NULL, 0, 18, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(338, 49, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(339, 7588, NULL, NULL, 0, 49, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(340, 8, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(341, 7, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(342, 3107, NULL, NULL, 0, 16, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(343, 1665, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(344, 1323, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(345, 1094, NULL, NULL, 0, 9, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(346, 220, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(347, 4411, NULL, NULL, 0, 36, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(348, 386, NULL, NULL, 0, 7, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(349, 1, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(350, 3997, NULL, NULL, 0, 17, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(351, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(352, 10, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(353, 23, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(354, 3906, NULL, NULL, 0, 11, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(355, 118, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(356, 43, NULL, NULL, 0, 1, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(357, 3245, NULL, NULL, 0, 11, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(358, 1410, NULL, NULL, 0, 4, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(359, 7, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(360, 536, NULL, NULL, 0, 6, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(361, 314, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(362, 2072, NULL, NULL, 0, 2, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(363, 502, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(364, 8, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(365, 31, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(366, 766, NULL, NULL, 0, 3, NULL, NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO `venue_record` VALUES(367, 189, NULL, NULL, 0, 9, NULL, NULL, NULL, NULL, 0, NULL, NULL);
